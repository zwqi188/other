﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApp.Controllers
{
    public class APIController : Controller
    {

        /// <summary>
        /// 进行授权时调用
        /// </summary>
        /// <param name="filterContext"></param>
        protected override void OnAuthorization(AuthorizationContext filterContext)
        {
            //判断是否已经登陆
            if (!Lib.WeChat.IsLogOn)
            {
                filterContext.Result = "非法操作".ToJsonResult();
                return;
            }
        }

        /// <summary>
        /// 接口异常时调用
        /// </summary>
        /// <param name="filterContext"></param>
        protected override void OnException(ExceptionContext filterContext)
        {
            filterContext.ExceptionHandled = true;
            filterContext.Result = ("异常:" + filterContext.Exception.Message).ToJsonResult();
            //filterContext.Result = "异常错误".ToJsonResult();
        }

        /// <summary>
        /// 更新用户所属部门
        /// </summary>
        /// <param name="department">部门</param>
        /// <returns></returns>
        public JsonResult UpdateDepartment(string department)
        {
           var result=  new EntityService().Update(new Models.UserInfo() { department = department, LastUpdateDate = DateTime.Now }, new Models.UserInfo() { WeChatUserID = Lib.WeChat.UserID });

           return result.ToJsonResult();
        }

        /// <summary>
        /// 获取用户信息
        /// </summary>
        /// <returns></returns>
        public JsonResult GetUserInfo()
        {
            var result = new EntityService().GetObject(new Models.UserInfo() { WeChatUserID = Lib.WeChat.UserID });

            var quest = new EntityService().GetExist(new Models.UserQuestionnaire() { WeChatUserID = Lib.WeChat.UserID });

            return new
            {
                id=result.ID,
                department = result.department,
                quest = quest,
            }.ToJsonResult();
        }

        /// <summary>
        /// 提交投票结果
        /// </summary>
        /// <param name="data1">不重要</param>
        /// <param name="data2">重要但印象不深</param>
        /// <param name="data3">重要但不满意有待改进</param>
        /// <param name="data4">重要并较满意继续提高</param>
        /// <param name="data5">重要并很满意继续保持</param>
        /// <param name="data6">与我无关</param>
        /// <returns></returns>
        public JsonResult QuestionnaireResult(string department, List<string> data1 = null, List<string> data2 = null, List<string> data3 = null, List<string> data4 = null, List<string> data5 = null, List<string> data6 = null)
        {
            //判断是否已经完成调研
            if (new EntityService().GetExist(new Models.UserQuestionnaire() { WeChatUserID = Lib.WeChat.UserID }))
            {
                return true.ToJsonResult();
                //return "你已完成本次调研，请勿重复提交".ToJsonResult();
            }

            var result = new EntityService().Update(new Models.UserInfo() { department = department, LastUpdateDate = DateTime.Now }, new Models.UserInfo() { WeChatUserID = Lib.WeChat.UserID });
            if (!result)
            {
                return "提交失败，请重试...".ToJsonResult();
            }

            var list = new Dictionary<string, List<string>>()
            {
                {"不重要",data1},
                {"重要但印象不深",data2},
                {"重要但不满意有待改进",data3},
                {"重要并较满意继续提高",data4},
                {"重要并很满意继续保持",data5},
                {"与我无关",data6},
            };

            foreach (var item in list)
            {
                if (item.Value != null && item.Value.Count > 0)
                {
                    foreach (var Tag in item.Value)
                    {
                        if (!Tag.IsNullOrBlank())
                        {
                            new EntityService().Create(new Models.UserQuestionnaire()
                            {
                                IsDeleted = false,
                                CreateDate = DateTime.Now,
                                WeChatUserID = Lib.WeChat.UserID,
                                Type = item.Key,
                                Tag = Tag
                            });
                        }
                    }
                }
            }

            return true.ToJsonResult();
        }

        /// <summary>
        /// 删除数据
        /// </summary>
        /// <returns></returns>
        public JsonResult DeleteData()
        {
            new EntityService().Update(new Models.UserInfo() { department = string.Empty }, new Models.UserInfo() { WeChatUserID = Lib.WeChat.UserID });

            return new EntityService().Delete(new Models.UserQuestionnaire() { WeChatUserID = Lib.WeChat.UserID }).ToJsonResult();
        }


    }
}
