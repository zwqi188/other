﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApp.Controllers
{
    public class WeChatController : Controller
    {
        /// <summary>
        /// 获取code
        /// </summary>
        /// <returns></returns>
        public ActionResult Authorize()
        {
            var callback = Common.UrlHelper.HostUrl + "/WeChat/GetUserInfo?ticket=";

            return Redirect(new Dxy.Call().GetOAuthUrl(callback));
            //return View();
        }

        /// <summary>
        /// 根据code获取成员信息
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        public ActionResult GetUserInfo(string ticket)
        {
            if (new Lib.WeChat().GetUserInfo(ticket))
            {
                return Redirect("~/");
            }
            else
            {
                return Redirect("~/404.html");
            }
        }

        /// <summary>
        /// 获取微信JSSDK配置
        /// </summary>        
        /// <param name="url"></param>        
        /// <returns></returns>
        public ActionResult JSConfig(string url)
        {
            Response.ContentType = "application/json";
            return Content(new Dxy.Call().GetJsSDKConfig(url));
        }

        /// <summary>
        /// 微信端测试免授权入口
        /// </summary>
        /// <returns></returns>
        public ActionResult Test(string UserID)
        {
            new Lib.WeChat().Test(UserID);

            return Redirect("~/");
        }

    }
}
