﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApp.Controllers
{
    public class HomeController : Controller
    {

        /// <summary>
        /// 进行授权时调用
        /// </summary>
        /// <param name="filterContext"></param>
        protected override void OnAuthorization(AuthorizationContext filterContext)
        {
            //判断是否已经登陆
            if (!Lib.WeChat.IsLogOn)
            {
                filterContext.Result = Redirect("~/WeChat/Authorize");
                return;
            }
        }

        /// <summary>
        /// 接口异常时调用
        /// </summary>
        /// <param name="filterContext"></param>
        protected override void OnException(ExceptionContext filterContext)
        {
            filterContext.ExceptionHandled = true;
            //filterContext.Result = ("异常:" + filterContext.Exception.Message).ToJsonResult();
            filterContext.Result = Redirect("~/503.html");
        }

        /// <summary>
        /// 首页
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            //var user = new EntityService().GetObject(new Models.UserInfo() { WeChatUserID = Lib.WeChat.UserID });
            return View("~/Views/Index.cshtml");
        }


    }
}
