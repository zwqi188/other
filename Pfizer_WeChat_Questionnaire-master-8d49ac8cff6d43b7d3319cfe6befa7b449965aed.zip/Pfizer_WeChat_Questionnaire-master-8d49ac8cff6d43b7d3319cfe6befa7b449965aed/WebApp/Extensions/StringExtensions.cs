﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Globalization;
using System.Security.Cryptography;

internal static class StringExtensions
{
    /// <summary>
    /// 判断字符串是否为空
    /// </summary>
    /// <param name="value"></param>
    /// <returns></returns>
    public static bool IsNullOrBlank(this string value)
    {
        return string.IsNullOrEmpty(value) ||
               (!string.IsNullOrEmpty(value) && value.Trim() == string.Empty);
    }

    /// <summary>
    /// 字符比较大小
    /// </summary>
    /// <param name="left"></param>
    /// <param name="right"></param>
    /// <returns></returns>
    public static bool EqualsIgnoreCase(this string left, string right)
    {
        return string.Compare(left, right, StringComparison.OrdinalIgnoreCase) == 0;
    }

    /// <summary>
    /// 判断字符串是否存在数组
    /// </summary>
    /// <param name="input"></param>
    /// <param name="args"></param>
    /// <returns></returns>
    public static bool EqualsAny(this string input, params string[] args)
    {
        return args.Aggregate(false, (current, arg) => current | input.Equals(arg));
    }


    public static string FormatWith(this string format, params object[] args)
    {
        return string.Format(format, args);
    }

    public static string FormatWithInvariantCulture(this string format, params object[] args)
    {
        return string.Format(CultureInfo.InvariantCulture, format, args);
    }

    /// <summary>
    /// 连接字符串
    /// </summary>
    /// <param name="input"></param>
    /// <param name="value"></param>
    /// <returns></returns>
    public static string Then(this string input, string value)
    {
        return string.Concat(input, value);
    }

    /// <summary>
    /// 字符串Url转义
    /// </summary>
    /// <param name="value"></param>
    /// <returns></returns>
    public static string UrlEncode(this string value)
    {
        return Uri.EscapeDataString(value);
    }
    /// <summary>
    /// 字体串Url解义
    /// </summary>
    /// <param name="value"></param>
    /// <returns></returns>
    public static string UrlDecode(this string value)
    {
        return Uri.UnescapeDataString(value);
    }

    /// <summary>
    /// 字节转Base64位编码字符串
    /// </summary>
    /// <param name="input"></param>
    /// <returns></returns>
    public static string ToBase64String(this byte[] input)
    {
        return Convert.ToBase64String(input);
    }
    /// <summary>
    /// 字符串转字节
    /// </summary>
    /// <param name="input"></param>
    /// <returns></returns>
    public static byte[] GetBytes(this string input)
    {
        return Encoding.UTF8.GetBytes(input);
    }

    /// <summary>
    /// 百分号编码字符串
    /// </summary>
    /// <param name="s"></param>
    /// <returns></returns>
    public static string PercentEncode(this string s)
    {
        byte[] bytes = s.GetBytes();
        StringBuilder sb = new StringBuilder();

        foreach (byte b in bytes)
        {
            sb.Append(string.Format("%{0:X2}", b));
        }

        return sb.ToString();
    }
    /// <summary>
    /// 解析查询字符串
    /// </summary>
    /// <param name="query"></param>
    /// <returns></returns>
    public static IDictionary<string, string> ParseQueryString(this string query)
    {
        if (query.StartsWith("?"))
        {
            query = query.Substring(1);
        }

        if (query.Equals(string.Empty))
        {
            return new Dictionary<string, string>();
        }

        string[] parts = query.Split('&');

        return parts.Select(part => part.Split('=')).ToDictionary(pair => pair[0], pair => pair[1]);
    }

    /// <summary>
    /// 字符串MD5加密 
    /// </summary>
    /// <param name="input"></param>
    /// <returns></returns>
    public static string HashMD5Password(this string input)
    {
        if (input.IsNullOrBlank()) return string.Empty;

        return System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(input.Trim(), "MD5");
    }

    /// <summary>
    /// Base64 编码
    /// </summary>
    /// <param name="input"></param>
    /// <returns></returns>
    public static string EncryBase64(this string input)
    {
        byte[] bytes = Encoding.UTF8.GetBytes(input);
        try
        {
            return Convert.ToBase64String(bytes);
        }
        catch
        {
            return null;
        }
    }
    /// <summary>
    /// Base64 解码
    /// </summary>
    /// <param name="input"></param>
    /// <returns></returns>
    public static string DecodeBase64(this string input)
    {
        byte[] bytes = Convert.FromBase64String(input);
        try
        {
            return Encoding.UTF8.GetString(bytes);
        }
        catch
        {
            return null;
        }
    }

    /// <summary>
    /// DES 加密
    /// </summary>
    public static string EncryDes(this string value, string keyVal, string ivVal)
    {
        try
        {
            byte[] data = Encoding.UTF8.GetBytes(value);
            var des = new DESCryptoServiceProvider { Key = Encoding.ASCII.GetBytes(keyVal.Length > 8 ? keyVal.Substring(0, 8) : keyVal), IV = Encoding.ASCII.GetBytes(ivVal.Length > 8 ? ivVal.Substring(0, 8) : ivVal) };
            var desencrypt = des.CreateEncryptor();
            byte[] result = desencrypt.TransformFinalBlock(data, 0, data.Length);
            return BitConverter.ToString(result);
        }
        catch(Exception)
        {
            throw new Exception("DES加密异常");
            //return null;
        }
    }

    /// <summary>
    /// DES 解密
    /// </summary>
    public static string DecodeDes(this string value, string keyVal, string ivVal)
    {
        try
        {
            string[] sInput = value.Split("-".ToCharArray());
            byte[] data = new byte[sInput.Length];
            for (int i = 0; i < sInput.Length; i++)
            {
                data[i] = byte.Parse(sInput[i], NumberStyles.HexNumber);
            }
            var des = new DESCryptoServiceProvider { Key = Encoding.ASCII.GetBytes(keyVal.Length > 8 ? keyVal.Substring(0, 8) : keyVal), IV = Encoding.ASCII.GetBytes(ivVal.Length > 8 ? ivVal.Substring(0, 8) : ivVal) };
            var desencrypt = des.CreateDecryptor();
            byte[] result = desencrypt.TransformFinalBlock(data, 0, data.Length);
            return Encoding.UTF8.GetString(result);
        }
        catch (Exception)
        {
            throw new Exception("DES解密异常");
            //return null;
        }
    }


    /// <summary>
    /// 防止sql参数注入
    /// </summary>
    /// <param name="input"></param>
    /// <returns></returns>
    public static string ToSqlParameter(this string input)
    {
        if (input.IsNullOrBlank())
        {
            return input;
        }
        else
        {
            return input.Replace("'", "''");
        }
    }



}

