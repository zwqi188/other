﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;


using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using NPOI.HSSF.Util;

using System.IO;

internal static class DataTableExtensions
{

    /// <summary>
    /// 导出Excel
    /// </summary>
    /// <param name="value"></param>
    /// <param name="filePath"></param>
    public static void ExportExcel(this DataTable value, string filePath)
    {
        var workbook = new HSSFWorkbook();//创建Workbook对象

        //表名
        var sheetName = value.TableName;
        if (sheetName.IsNullOrBlank())
        {
            sheetName = "sheet1";
        }

        //创建工作表
        ISheet sheet = workbook.CreateSheet(sheetName);

        //表头-------在工作表中添加一行
        IRow firstRow = sheet.CreateRow(0);
        for (int i = 0; i < value.Columns.Count; i++)
        {
            ICell cell = firstRow.CreateCell(i);
            cell.SetCellValue(value.Columns[i].ColumnName);
        }

        //表内容-----------
        for (int i = 0; i < value.Rows.Count; i++)
        {
            //在工作表1中添加一行
            IRow row = sheet.CreateRow(i + 1);
            for (int j = 0; j < value.Columns.Count; j++)
            {

                if (value.Rows[i][j] != null)
                {
                    var targetType = value.Rows[i][j].GetType();

                    switch (targetType.Name.ToLower())
                    {
                        case "int16":
                        case "uint16":
                        case "int32":
                        case "uint32":
                        case "int64":
                        case "uint64":
                            row.CreateCell(j).SetCellValue(Convert.ToInt64(value.Rows[i][j]));

                            break;
                        case "double":
                        case "decimal":
                            row.CreateCell(j).SetCellValue(Convert.ToDouble(value.Rows[i][j]));
                            break;

                        case "byte":
                        case "sbyte":
                        case "char":
                        case "boolean":
                        case "guid":
                        case "timespan":
                        case "single":
                        case "datetime":
                        default:
                            row.CreateCell(j).SetCellValue(Convert.ToString(value.Rows[i][j]));
                            break;
                    }
                }
            }
        }

        //写入文件流
        MemoryStream ms = new MemoryStream();
        workbook.Write(ms);
        ms.Position = 0;

        //写入本地文件
        var fileContent = ms.ToArray();
        using (var fs = File.Create(filePath))
        {
            fs.Write(fileContent, 0, fileContent.Length);
            fs.Flush();
        }
    }

}
