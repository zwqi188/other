﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApp.Dxy
{
    public class UserInfo
    {

        
        //"birthday": 1451448000000,
        //"englishName": "英文名",
        //"gender": "女",
        //"wxid": "zhaoxiaoyun0925",
        //"departmentList": [
        //{
        //"id": 1637,
        //"parent": 0,
        //"level": 1,
        //"name": "WeChat项目测试",
        //"editable": false,
        //"hide": false
        //}
        //],
        //"modifyTime": 1483464781000,
        //"unfollowTime": null,
        //"contactNumber": "联系电话",
        //"hrcode": "ZHAOX86",
        //"id": 19994,
        //"NTID": "ZHAOX86",
        //"email": "zora.zhao@edoctor.cn",
        //"superior": "上级领导",
        //"staffStatus": 0,
        //"uid": "UID",
        //"mobile": "15921322542",
        //"avatar": "/imgqn/upload_files/2016/12/23/19994.jpg",
        //"departmentType": "部门类型",
        //"userId": "ID1456796797692593543",
        //"tagList": [],
        //"deleted": false,
        //"followTime": null, 
        //"createTime": 1456796797000,
        //"teamId": 136,
        //"name": "赵晓赟(ZHAOX86)",
        //"publicAvatarPath": "https://sim-image.dxycdn.com/imgqn/upload_files/2016/12/23/19994.jpg!160",
        //"position": "职位",
        //"status": 2


        //"birthday": 55440000000,
        //"englishName": "ZENG,Yong Ming",
        //"gender": "女",
        //"officeSeat": "",
        //"wxid": "wengzeng0321",
        //"departmentList": [
        //{
        //"id": 2727,
        //"parent": 2726,
        //"level": 4,
        //"name": "全国销售培训及发展一组",
        //"editable": false,
        //"hide": false
        //}
        //],
        //"modifyTime": 1505063724000,
        //"unfollowTime": null,
        //"graduationTime": null,
        //"contactNumber": "18621666308",
        //"hrcode": "ZENGY01",
        //"id": 8724,
        //"46823a8b65c15c761225cc7ce7a03521": "ZENGY01",
        //"email": "yongming.zeng@pfizer.com",
        //"37ce475f32f2d14c5e5bc4725d959c3d": "陶瑞萍(TAOR)",
        //"staffStatus": 0,
        //"e7d22294bdcb7133967c3548ece982e5": "0462554d-3b17-4b0f-aef2-a12e719768df",
        //"mobile": "18621666308",
        //"degree": "未知",
        //"avatar": "/imgqn/upload_files/2015/08/27/8724.jpg",
        //"6e950fda789cdb125b850019c818f16f": "Other",
        //"userId": "ID1440666393554627103",
        //"tagList": [],
        //"registerAddress": "",
        //"entryTime": null,
        //"deleted": false,
        //"followTime": null,
        //"createTime": 1440666393000,
        //"teamId": 136,
        //"name": "曾永铭(ZENGY01)",
        //"publicAvatarPath": "https://sim-image.dxycdn.com/imgqn/upload_files/2015/08/27/8724.jpg!160",
        //"position": "Trainer",
        //"status": 2,
        //"applications": "185,254,233,283,316,331,320,329,304,332,343,345,408,422,455,458,406,457"

        public int id { set; get; }

        public int? teamId { set; get; }

        public string userId { set; get; }

        public string name { set; get; }

        public string englishName { set; get; }

        public string position { set; get; }

        public string mobile { set; get; }

        public string gender { set; get; }

        public string email { set; get; }

        public string wxid { set; get; }

        public string uid { set; get; }

        public string NTID { set; get; }

        public string departmentType { set; get; }

        public string superior { set; get; }

        public string avatar { set; get; }

        public string publicAvatarPath { set; get; }

        public string hrcode { set; get; }

        public string status { set; get; }

        public long createTime { set; get; }



    }
}