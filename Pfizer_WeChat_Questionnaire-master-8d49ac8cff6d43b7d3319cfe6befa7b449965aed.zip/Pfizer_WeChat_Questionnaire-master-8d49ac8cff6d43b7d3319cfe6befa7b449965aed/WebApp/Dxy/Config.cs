﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApp.Dxy
{
    public class Config
    {
        public const string AppID = "1042394345";

        public const string SignKey = "kuByklLuADXnqsufBY873G5vNzxDk7q4uWr70nP0f0UTRXA0FVxum9F0ixEui5eOvvEpTmfFQQD1f5gcol0RmdTs5wflvZTpI4RzztwsoNoRoS0atr85CsVvpbeTqNnJ";

        public const string Server = "https://sim.dxy.cn";
    }
}