﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApp.Dxy
{
    public class ResMsg<T>
    {
        public bool success { set; get; }

        public string message { set; get; }

        public T item { set; get; }
    }
}