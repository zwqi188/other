﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Security.Cryptography;

namespace WebApp.Dxy
{
    public class Call
    {
        /// <summary>
        /// 编码
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        private string EncryptBase64(string code)
        {
            string encode = "";
            byte[] bytes = Encoding.UTF8.GetBytes(code);
            try
            {
                encode = Convert.ToBase64String(bytes);
            }
            catch
            {
                encode = code;
            }
            return encode;
        }

        /// <summary>
        /// 生成制定长度的随机数
        /// </summary>
        /// <param name="type">all:包括数字、大小写字母；num：0~9数字；lower：小写字母；upper：大写字母；lower&upper:大小写字母</param>
        /// <param name="length"></param>
        /// <returns></returns>
        private string RandomString(string type, int length)
        {
            string allChar = "";
            if (type == "all")
                allChar = "0,1,2,3,4,5,6,7,8,9,a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z";
            else if (type == "num")
                allChar = "0,1,2,3,4,5,6,7,8,9";
            else if (type == "lower")
                allChar = "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z";
            else if (type == "upper")
                allChar = "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z";
            else if (type == "lower&upper")
                allChar = "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z";
            string[] allCharArray = allChar.Split(',');
            string RandomCode = "";
            int temp = -1;

            Random rand = new Random();
            for (int i = 0; i < length; i++)
            {
                if (temp != -1)
                {
                    rand = new Random(temp * i * ((int)DateTime.Now.Ticks));
                }

                int t = rand.Next(allCharArray.Length);

                while (temp == t)
                {
                    t = rand.Next(allCharArray.Length);
                }

                temp = t;
                RandomCode += allCharArray[t];
            }

            return RandomCode;
        }

        /// <summary>
        /// SHA1加密
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        private string EncryptToSHA1(string str)
        {
            var buffer = Encoding.UTF8.GetBytes(str);
            var data = SHA1.Create().ComputeHash(buffer);

            var sb = new StringBuilder();
            foreach (var t in data)
            {
                sb.Append(t.ToString("X2"));
            }

            return sb.ToString();
        }

        /// <summary>
        /// 获取授权地址
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        public string GetOAuthUrl(string callback)
        {
            var url = Config.Server + "/japi/qiye/oauth/ticket/185/";

            //Base64编码
            callback = this.EncryptBase64(callback);

            //替换特殊字符
            callback = callback.Replace('+', '-').Replace('/', '_').TrimEnd('=');

            return url + callback;
        }


        /// <summary>
        /// 获取用户信息
        /// </summary>
        /// <param name="ticket"></param>
        /// <returns></returns>
        public ResMsg<UserInfo> GetUserInfo(string ticket)
        {
            string nonce = this.RandomString("all", 16);

            //long ticks = DateTime.UtcNow.Ticks - DateTime.Parse("01/01/1970").Ticks;
            //ticks /= 10000000;
            var timestamp = ((DateTime.UtcNow.Ticks - DateTime.Parse("01/01/1970").Ticks) / 10000000).ToString();

            var sign = this.EncryptToSHA1("appId=" + Config.AppID + "&appSignKey=" + Config.SignKey + "&nonce=" + nonce + "&ticket=" + ticket + "&timestamp=" + timestamp);

            var url = Config.Server + "/japi/open/qiye/contact/getbyticket";

            var req = new eDoctor.SDK.Http.HttpGet(url);

            //记录日志
            var log = new Models.DxyAPILog() { CreateDate = DateTime.Now, IsDeleted = false, Url = url };
            try
            {
                req.Params.Add("appId", Config.AppID);
                req.Params.Add("nonce", nonce);
                req.Params.Add("ticket", ticket);
                req.Params.Add("timestamp", timestamp);
                req.Params.Add("sign", sign);

                //POST数据---记录日志
                log.PostData = new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(req.Params);

                var res = req.Request();

                //响应数据---记录日志
                log.RespData = res;

                res = res.Replace("e7d22294bdcb7133967c3548ece982e5", "uid");
                res = res.Replace("46823a8b65c15c761225cc7ce7a03521", "NTID");
                res = res.Replace("6e950fda789cdb125b850019c818f16f", "departmentType");
                res = res.Replace("37ce475f32f2d14c5e5bc4725d959c3d", "superior");

                //返回数据实例化对象
                var obj = new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<ResMsg<UserInfo>>(res);
                return obj;
            }
            catch (Exception ex)
            {
                //错误信息---记录日志
                log.ErrorMsg = ex.Message;
                return null;
            }
            finally
            {
                new EntityService().Create(log);
            }
        }

        /// <summary>
        /// 获取微信JSSDK配置
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public string GetJsSDKConfig(string webUrl)
        {
            var url = Config.Server + "/japi/js/sign/136";

            var req = new eDoctor.SDK.Http.HttpGet(url);       

            //记录日志
            var log = new Models.DxyAPILog() { CreateDate = DateTime.Now, IsDeleted = false, Url = url };
            try
            {
                req.Params.Add("url", webUrl);

                //POST数据---记录日志
                log.PostData = new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(req.Params);

                var res = req.Request();

                //响应数据---记录日志
                log.RespData = res;

                return res;
            }
            catch (Exception ex)
            {
                //错误信息---记录日志
                log.ErrorMsg = ex.Message;
                return null;
            }
            finally
            {
                new EntityService().Create(log);
            }

        }


    }
}