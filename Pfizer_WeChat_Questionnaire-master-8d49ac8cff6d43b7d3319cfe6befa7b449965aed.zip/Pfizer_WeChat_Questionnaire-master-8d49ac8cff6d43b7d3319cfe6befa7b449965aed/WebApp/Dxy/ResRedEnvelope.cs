﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApp.Dxy
{
    public class ResRedEnvelope
    {
        public bool success { set; get; }

        public string message { set; get; }

        public int errorCode { set; get; }

        public string amount { set; get; }
    }
}