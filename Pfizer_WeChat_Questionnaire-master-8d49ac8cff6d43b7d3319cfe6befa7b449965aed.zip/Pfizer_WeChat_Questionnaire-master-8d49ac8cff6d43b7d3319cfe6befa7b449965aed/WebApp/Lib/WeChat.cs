﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApp.Lib
{
    public class WeChat
    {


        /// <summary>
        /// （cookie&session）Key值 
        /// </summary>
        private const string Prefix = "Current-WeChat-";
        private const string Encry = "d9b06293eed30f026d76e3b2fa78963";

        /// <summary>
        /// 登录用户ID
        /// </summary>
        public static string UserID
        {
            get
            {
                if (System.Web.HttpContext.Current.Request.Cookies[Prefix + "UserID"] != null && !string.IsNullOrEmpty(System.Web.HttpContext.Current.Request.Cookies[Prefix + "UserID"].Value))
                {
                    return System.Web.HttpContext.Current.Request.Cookies[Prefix + "UserID"].Value.DecodeDes(Encry, Encry);
                }
                else
                {
                    return string.Empty;
                }

            }
        }
        /// <summary>
        /// 判断是否已经登陆
        /// </summary>
        public static bool IsLogOn
        {
            get
            {
                if (UserID.IsNullOrBlank())
                {
                    return false;
                }
                if (System.Web.HttpContext.Current.Request.Cookies[Prefix + "encry"] != null)
                {
                    return (Prefix + Encry + UserID).HashMD5Password() == System.Web.HttpContext.Current.Request.Cookies[Prefix + "encry"].Value;
                }
                else
                {
                    return false;
                }
            }
        }

        /// <summary>
        /// 获取成员信息
        /// </summary>
        /// <param name="userid"></param>
        public bool GetUserInfo(string ticket)
        {
            var obj = new Dxy.Call().GetUserInfo(ticket);
            if (obj == null || !obj.success || obj.item==null)
            {
                return false;
            }

            //判断成员是否已经存在数据库，并保存用户至数据库            
            var exist=new EntityService().GetExist(new Models.UserInfo(){WeChatUserID=obj.item.userId});
            if (!exist)
            {

                //图片保存路径&文件名
                var imgPath = System.Web.HttpContext.Current.Server.MapPath("~/Upload/Images/");
                var imgName = DateTime.Now.ToString("yyyyMMdd-") + Guid.NewGuid().ToString("n") + ".jpg";
                if (!System.IO.Directory.Exists(imgPath))
                {
                    System.IO.Directory.CreateDirectory(imgPath);
                }

                //头像地址
                var Avatar = "/Upload/Images/" + imgName;
                try
                {
                    using (System.Net.WebClient client = new System.Net.WebClient())
                    {
                        client.DownloadFile(obj.item.publicAvatarPath, imgPath + imgName);
                    }
                }
                catch (Exception)
                {
                    Avatar = obj.item.publicAvatarPath;
                }

                var name = obj.item.name.IndexOf("(") > 0 ? obj.item.name.Substring(0, obj.item.name.IndexOf("(")) : obj.item.name;

                if (!new EntityService().Create(new Models.UserInfo()
                {
                    CreateDate = DateTime.Now,
                    IsDeleted = false,
                    WeChatUserID = obj.item.userId,
                    Name = name,
                    EnglishName = obj.item.englishName,
                    Mobile = obj.item.mobile,
                    Avatar = Avatar,//obj.item.publicAvatarPath,
                    email=obj.item.email,
                    wxid=obj.item.wxid,
                    hrcode=obj.item.hrcode,
                }))
                {
                    return false;
                }
            }

            
            //保存Cookie---UserID
            System.Web.HttpCookie cookie = new System.Web.HttpCookie(Prefix + "UserID");
            cookie.Value = obj.item.userId.EncryDes(Encry, Encry); 
            cookie.Expires = DateTime.Now.AddDays(15);
            System.Web.HttpContext.Current.Response.AppendCookie(cookie);


            //保存Cookie---encryption
            System.Web.HttpCookie cookieencry = new System.Web.HttpCookie(Prefix + "encry");
            cookieencry.Value = (Prefix + Encry + obj.item.userId).HashMD5Password();
            cookieencry.Expires = DateTime.Now.AddDays(7);
            System.Web.HttpContext.Current.Response.AppendCookie(cookieencry);

            return true;
        }

        /// <summary>
        /// 测试入口
        /// </summary>
        public void Test(string UserId)
        {
            if (UserId.IsNullOrBlank())
            {
                UserId = "ID1456796797692593543";
            }

            //保存Cookie---UserID
            System.Web.HttpCookie cookie = new System.Web.HttpCookie(Prefix + "UserID");
            cookie.Value = UserId.EncryDes(Encry, Encry);
            cookie.Expires = DateTime.Now.AddHours(24);
            System.Web.HttpContext.Current.Response.AppendCookie(cookie);

            //保存Cookie---encryption
            System.Web.HttpCookie cookieencry = new System.Web.HttpCookie(Prefix + "encry");
            cookieencry.Value = (Prefix + Encry + UserId).HashMD5Password();
            cookieencry.Expires = DateTime.Now.AddHours(24);
            System.Web.HttpContext.Current.Response.AppendCookie(cookieencry);

        }
    }
}