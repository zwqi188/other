var alasql = require('alasql');
var sql = require('mssql');
var moment = require('moment');
var nodemailer = require('nodemailer');

//配置
var packageConfig = require('./package.json');

//查询用户表
async function selectUserInfo() {
    // console.log('开始查询', packageConfig.sqlserve)
    const pool = await new sql.ConnectionPool(packageConfig.sqlserve).connect();
    const result = await pool
        .request()
        // .input('ID', sql.Int, 10)
        .query(`       
            SELECT 
                ID,IsDeleted,CreateDate,LastUpdateDate,WeChatUserID,Name,EnglishName,Mobile,Avatar,department,wxid,email,hrcode
            FROM [UserInfo] Where IsDeleted=0;`);
    pool.close();
    console.log('查询结果', result.recordset.length + '条')
    return result.recordset;
}

//查询调研表
async function selectQuestionnaire() {
    const pool = await new sql.ConnectionPool(packageConfig.sqlserve).connect();
    const result = await pool
        .request()
        // .input('ID', sql.Int, 10)
        .query(`       
            SELECT 
                ID,CreateDate,WeChatUserID,Type,Tag
            FROM [UserQuestionnaire] Where IsDeleted=0;`);
    pool.close();
    console.log('查询结果', result.recordset.length + '条')
    console.log('1条', result.recordset[0])
    console.log('2条', result.recordset[1])
    return result.recordset;
}

//导出excel
async function exportExcel(sheet, data, fileName) {
    console.log('开始导出Excel')
    let result = await alasql.promise('SELECT * INTO XLSX("' + fileName + '",?) FROM ?', [sheet, data]);
    console.log('导出完成', fileName)

    return result;
}

//发送邮件
async function sendMail(to, fileName) {
    let transporter = await nodemailer.createTransport(packageConfig.mail);

    console.log('开始发送邮件')
    let result = await transporter.sendMail({
        from: packageConfig.mail.auth.user, // sender address
        to: to, // list of receivers
        subject: '调研数据', // Subject line
        html: `
        <p>

        </p>

        <p><br/><br/><br/>
        谭青亮<br/>
        M:(+86)17091959740<br/>
        翼多.eDoctor Healthcare Communications<br/>
        上海市长宁区天山路310号海益商务大厦12层, 200336<br/>
        <p>
        `, // html body
        attachments: [{
            filename: fileName,
            path: './' + fileName
        }, ]
    });

    console.log('发送完毕', result)

}



(async() => {

    //文件名
    var fileName = moment().format("YYYYMMDDHHmmss") + '.xlsx'

    //数据库查询 
    var users = await selectUserInfo();
    var data = await selectQuestionnaire();

    // //导出Excel
    await exportExcel([{ sheetid: 'user', header: true }, { sheetid: 'quiz', header: true }], [users, data], fileName);

    // //发送邮件
    await sendMail('Ron.liu@edoctor.cn', fileName);
    // await sendMail('qingliang.tan@edoctor.cn', fileName);
})();