
## 辉瑞调查问卷

### 测试入口
```
http://pfize_quest.test.vhdong.com:18880/WeChat/Test?userid=ID1456796797692593543
```


### 删除测试数据    
```
http://pfize_quest.test.vhdong.com:18880/API/DeleteData

```