﻿using System;
using System.Collections.Generic;
using System.Text;
using DbUtility;

namespace Models
{
    public partial class DxyAPILog: EntityBase
    {

		        /// <summary>
        ///
        /// </summary>
        private DateTime? _CreateDate;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("CreateDate", false, false, true)]
        public DateTime? CreateDate { get { return _CreateDate;} set{_CreateDate = value;OnPropertyChanged("CreateDate");} } 


        /// <summary>
        ///
        /// </summary>
        private DateTime? _LastUpdateDate;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("LastUpdateDate", false, false, true)]
        public DateTime? LastUpdateDate { get { return _LastUpdateDate;} set{_LastUpdateDate = value;OnPropertyChanged("LastUpdateDate");} } 


        /// <summary>
        ///
        /// </summary>
        private String _WeChatUserID;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("WeChatUserID", false, false, true)]
        public String WeChatUserID { get { return _WeChatUserID;} set{_WeChatUserID = value;OnPropertyChanged("WeChatUserID");} } 


        /// <summary>
        ///
        /// </summary>
        private String _Url;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Url", false, false, true)]
        public String Url { get { return _Url;} set{_Url = value;OnPropertyChanged("Url");} } 


        /// <summary>
        ///
        /// </summary>
        private String _PostData;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("PostData", false, false, true)]
        public String PostData { get { return _PostData;} set{_PostData = value;OnPropertyChanged("PostData");} } 


        /// <summary>
        ///
        /// </summary>
        private String _RespData;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("RespData", false, false, true)]
        public String RespData { get { return _RespData;} set{_RespData = value;OnPropertyChanged("RespData");} } 


        /// <summary>
        ///
        /// </summary>
        private String _ErrorMsg;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("ErrorMsg", false, false, true)]
        public String ErrorMsg { get { return _ErrorMsg;} set{_ErrorMsg = value;OnPropertyChanged("ErrorMsg");} } 




    }
}