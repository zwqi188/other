﻿using System;
using System.Collections.Generic;
using System.Text;
using DbUtility;

namespace Models
{
    public partial class UserQuestionnaire: EntityBase
    {

		        /// <summary>
        ///
        /// </summary>
        private DateTime _CreateDate;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("CreateDate", false, false, false)]
        public DateTime CreateDate { get { return _CreateDate;} set{_CreateDate = value;OnPropertyChanged("CreateDate");} } 


        /// <summary>
        ///
        /// </summary>
        private String _WeChatUserID;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("WeChatUserID", false, false, false)]
        public String WeChatUserID { get { return _WeChatUserID;} set{_WeChatUserID = value;OnPropertyChanged("WeChatUserID");} } 


        /// <summary>
        ///
        /// </summary>
        private String _Type;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Type", false, false, false)]
        public String Type { get { return _Type;} set{_Type = value;OnPropertyChanged("Type");} } 


        /// <summary>
        ///
        /// </summary>
        private String _Tag;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Tag", false, false, false)]
        public String Tag { get { return _Tag;} set{_Tag = value;OnPropertyChanged("Tag");} } 




    }
}