﻿using System;
using System.Collections.Generic;
using System.Text;
using DbUtility;

namespace Models
{
    public partial class UserInfo: EntityBase
    {

		        /// <summary>
        ///
        /// </summary>
        private DateTime? _CreateDate;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("CreateDate", false, false, true)]
        public DateTime? CreateDate { get { return _CreateDate;} set{_CreateDate = value;OnPropertyChanged("CreateDate");} } 


        /// <summary>
        ///
        /// </summary>
        private DateTime? _LastUpdateDate;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("LastUpdateDate", false, false, true)]
        public DateTime? LastUpdateDate { get { return _LastUpdateDate;} set{_LastUpdateDate = value;OnPropertyChanged("LastUpdateDate");} } 


        /// <summary>
        ///
        /// </summary>
        private String _WeChatUserID;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("WeChatUserID", false, false, false)]
        public String WeChatUserID { get { return _WeChatUserID;} set{_WeChatUserID = value;OnPropertyChanged("WeChatUserID");} } 


        /// <summary>
        ///
        /// </summary>
        private String _Name;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Name", false, false, true)]
        public String Name { get { return _Name;} set{_Name = value;OnPropertyChanged("Name");} } 


        /// <summary>
        ///
        /// </summary>
        private String _EnglishName;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("EnglishName", false, false, true)]
        public String EnglishName { get { return _EnglishName;} set{_EnglishName = value;OnPropertyChanged("EnglishName");} } 


        /// <summary>
        ///
        /// </summary>
        private String _Mobile;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Mobile", false, false, true)]
        public String Mobile { get { return _Mobile;} set{_Mobile = value;OnPropertyChanged("Mobile");} } 


        /// <summary>
        ///
        /// </summary>
        private String _Avatar;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Avatar", false, false, true)]
        public String Avatar { get { return _Avatar;} set{_Avatar = value;OnPropertyChanged("Avatar");} } 


        /// <summary>
        ///
        /// </summary>
        private String _department;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("department", false, false, true)]
        public String department { get { return _department;} set{_department = value;OnPropertyChanged("department");} } 


        /// <summary>
        ///
        /// </summary>
        private String _wxid;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("wxid", false, false, true)]
        public String wxid { get { return _wxid;} set{_wxid = value;OnPropertyChanged("wxid");} } 


        /// <summary>
        ///
        /// </summary>
        private String _email;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("email", false, false, true)]
        public String email { get { return _email;} set{_email = value;OnPropertyChanged("email");} } 


        /// <summary>
        ///
        /// </summary>
        private String _hrcode;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("hrcode", false, false, true)]
        public String hrcode { get { return _hrcode;} set{_hrcode = value;OnPropertyChanged("hrcode");} } 




    }
}