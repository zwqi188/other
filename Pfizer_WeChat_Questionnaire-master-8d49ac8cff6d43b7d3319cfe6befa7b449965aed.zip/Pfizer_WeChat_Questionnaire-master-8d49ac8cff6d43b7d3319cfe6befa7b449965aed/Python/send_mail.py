from email import encoders
from email.header import Header
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.utils import parseaddr, formataddr
import smtplib

import datetime

import numpy as np
import pandas as pd
import pymssql


class send_mail():

    def __init__(self,To,Subject,Content,Att):
        self.from_addr = 'ron.liu@edoctor.cn'
        self.password = 'Shun1987'
        self.to_addr = To #'qingliang.tan@edoctor.cn'
        self.smtp_server = 'smtp.partner.outlook.cn'
        self.smtp_port = 587

        # self.from_addr = 'wx@happyruru.com'
        # self.password = 'Sh123456'
        # self.to_addr = To #'qingliang.tan@edoctor.cn'
        # self.smtp_server = 'smtp.mxhichina.com'
        # self.smtp_port = 25


        # self.from_addr = 'jianai2017@126.com'
        # self.password = 'Sh123456'
        # self.to_addr = To #'qingliang.tan@edoctor.cn'
        # self.smtp_server = 'smtp.126.com'
        # self.smtp_port = 25

        self.Subject = Subject
        self.Content = Content
        self.Att = Att

    def _format_addr(self,s):
        name, addr = parseaddr(s)
        return formataddr((Header(name, 'utf-8').encode(), addr))

    def send(self):

        # 邮件对象:
        msg = MIMEMultipart()
        msg['From'] = self._format_addr('Ron Liu <%s>' % self.from_addr)
        msg['To'] = self._format_addr('您 <%s>' % self.to_addr)
        msg['Subject'] = Header(self.Subject, 'utf-8').encode()

        # 邮件正文是MIMEText:
        msg.attach(MIMEText(self.Content, 'html', 'utf-8'))

        # 添加附件就是加上一个MIMEBase，从本地读取一个图片:
        with open(self.Att, 'rb') as f:
            # 设置附件的MIME和文件名，这里是xlsx类型:
            mime = MIMEBase('application','vnd.ms-excel')
            # 加上必要的头信息:
            mime.add_header('Content-Disposition', 'attachment', filename=self.Att)
            mime.add_header('Content-ID', '<0>')
            mime.add_header('X-Attachment-Id', '0')
            # 把附件的内容读进来:
            mime.set_payload(f.read())
            # 用Base64编码:
            encoders.encode_base64(mime)
            # 添加到MIMEMultipart:
            msg.attach(mime)

        server = smtplib.SMTP(self.smtp_server, self.smtp_port)
        server.starttls()
        # server.set_debuglevel(1)
        server.login(self.from_addr, self.password)
        server.sendmail(self.from_addr, [self.to_addr], msg.as_string())
        server.quit()

content = '''
        <html>
        <head>
        <meta charset="UTF-8">
        </head>
        <body>
        <p>Dear Helen</p>
        <p>更新数据见附件。</p>
        <p>--<br>
        Best Regards,<br>
        Ron Liu 刘中顺<br>
        Senior Project Manager<br>
        M:(+86)186 1602 7776 W:(+8621)3131 9333<br>
        翼多.eDoctor Healthcare Communications<br>
        上海市长宁区天山路310号海益商务大厦12层, 200336</p>
        </body>
        </html>
'''

class export_data():
    def __init__(self,filename):
        self.host = '10.162.70.251\SQL2008'
        self.port = 1433
        self.db = 'pfizerfirst.vhdong.com.v2'
        self.user = 'edoctor'
        self.password = 'QWER!@#$'
        self.filename = filename
        self._export()

    def _export(self):
        conn=pymssql.connect(host=self.host,user=self.user,password=self.password,database=self.db)
        a = pd.read_sql('SELECT ID,CreateDate,WeChatUserID,Type,Tag FROM [UserQuestionnaire] Where IsDeleted=0;',conn,'ID')
        b = pd.read_sql('SELECT ID,IsDeleted,CreateDate,LastUpdateDate,WeChatUserID,Name,EnglishName,Mobile,Avatar,department,wxid,email,hrcode FROM [UserInfo] Where IsDeleted=0',conn,'ID')

        writer = pd.ExcelWriter(self.filename)
        b.to_excel(writer,'user')
        a.to_excel(writer,'quiz')
        writer.save()
        

now = str(datetime.datetime.now()).split(" ")[0]
filename = "Data"+now+'.xlsx'
export_data(filename)

mail = send_mail("ron@edoctor.cn","辉瑞调研数据"+now,content,filename)
mail.send()

