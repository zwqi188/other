/**
 * Created by QingLiang.TAN on 2017/3/24.
 */
import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)
//全局状态管理
// https://vuex.vuejs.org/zh-cn/state.html
const store = new Vuex.Store({
  strict: true,
  //全局变量状态
  state: {
    isAuth: 0,// 是否登录(0：正在获取、-1：未登录、1：已登录)
    routesDistance:{},
    loading: 1,//全局Loading,
    department:null
  },
  //state派生出一些状态
  getters: {},
  //全局同步函数---改变全局变量
  mutations: {
    //改变登录状态
    // changeIsAuth(state, isAuth){
    //   state.isAuth = isAuth;
    // },
    //全局Loading状态
    changeLoading(state, loading){
      state.loading = loading;
    },
    changedepartment(state, department){
      state.department = department;
    }
  },
  //全局异步函数---调用mutation改变全局变量
  actions: {},
  //模块store
  modules: {
  }
})

export default store
