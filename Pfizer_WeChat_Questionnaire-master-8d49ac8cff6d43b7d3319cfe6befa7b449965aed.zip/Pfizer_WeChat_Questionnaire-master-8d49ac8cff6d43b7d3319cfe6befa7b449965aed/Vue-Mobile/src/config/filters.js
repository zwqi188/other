/**
 * Created by QingLiang.TAN on 2017/4/11.
 */

// 自定义过滤器
import formatTime from '../tools/date/format'
import friendlyTime from '../tools/date/friendly-time'
import trim from '../tools/string/trim'

export default{
  'formatTime': formatTime,
  'friendlyTime': friendlyTime,
  'trim': trim
}
