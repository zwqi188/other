/**
 * Created by QingLiang.TAN on 2017/3/24.
 */
import Vue from 'vue'
import Router from 'vue-router'

import {entryHome,pageList ,Result} from '@/pages/index/'

//注册路由
Vue.use(Router)

export default new Router({
  mode: 'history',
  base: '/mob/',
  // linkActiveClass : 'is-active', // router-link active样式
  routes: [
    {path:"/operate/",component:pageList},
    {path:"/result",component:Result},
    {path:"/entry",component:entryHome}
    // {path: '*', meta: {auth: false}, component: Result}
  ]
})



