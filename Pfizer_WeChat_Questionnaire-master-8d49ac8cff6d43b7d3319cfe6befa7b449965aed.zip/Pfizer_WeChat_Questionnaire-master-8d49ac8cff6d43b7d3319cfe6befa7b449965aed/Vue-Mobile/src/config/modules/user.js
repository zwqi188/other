//全局(底部导航栏目)状态管理
export default {
    strict: true,
    //全局变量状态
    state: {
      hide: false,
      selected: null
    },
    //state派生出一些状态
    getters: {},
    //全局同步函数---改变全局变量
    mutations: {
      //改变底部导航栏目选中值
      changeFooterBarSelected(state, selected){
        state.hide = false;
        state.selected = selected;
      }
    },
    //全局异步函数---调用mutation改变全局变量
    actions: {},
  }