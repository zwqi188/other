<template>
  <div id="app">
    <!--加载Loading-->
    <div class="app-loading" v-if="loading">
      <img src="~assets/loading.svg" />
    </div>

    <!--路由页面-->
    <div style="height:100%;">
      <router-view></router-view>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
import { mapState, mapMutations, mapActions } from 'vuex'
export default {
  components: {

  },
  data() {
    return {
      bgimg:[
            "/vue-mob/img/btnsend.png",        
            "/vue-mob/img/nouser.png",
            "/vue-mob/img/logo.png",
            "/vue-mob/img/say.png",
            "/vue-mob/img/havefiles1.png",
            "/vue-mob/img/havefiles2.png",
            "/vue-mob/img/havefiles3.png",
            "/vue-mob/img/havefiles4.png",
            "/vue-mob/img/havefiles5.png",
            "/vue-mob/img/entrybg.png",
            "/vue-mob/img/nofiles.png",
            "/vue-mob/img/nofiles1.png",
            "/vue-mob/img/nofiles2.png",
            "/vue-mob/img/nofiles3.png",
            "/vue-mob/img/nofiles4.png",
            "/vue-mob/img/nofiles5.png",
        ]
    }
  },
  computed: {
    ...mapState({
      loading: state => state.loading,
      routesDistance: "routesDistance",
    })
  },
  watch: {
    "$route"(to, from) {
      if (this.goRouterScrollDistance) {
        this.goRouterScrollDistance()
      }
    },
  },
  mounted() {
  },
  methods: {
    ...mapMutations([
       "changeLoading","changedepartment"
    ]),
    Getinit() {
      (function(doc, win) {
        var docEl = doc.documentElement, resizeEvt = 'orientationchange' in window ? 'orientationchange' : 'resize',
          recalc = function() {
            var clientWidth = docEl.clientWidth;
            if (!clientWidth) return;
            if (clientWidth >= 640) {
              docEl.style.fontSize = '100px';
            }
            else {
              docEl.style.fontSize = 100 * (clientWidth / 640) + 'px';
            }
          };
        if (!doc.addEventListener) return;
        win.addEventListener(resizeEvt, recalc, false);
        doc.addEventListener('DOMContentLoaded', recalc, false);
      })(document, window);
    },
     //图片预加载
    onloadImage(){
        var newimgs=[];
        for(var i=0;i<this.bgimg.length;i++){
            newimgs[i]=new Image();
            newimgs[i].src=this.bgimg[i];
        }
    },
    getuserinfo(){
      this.$http.post("/api/getuserinfo").then((res)=>{
           this.changedepartment(res.data.department);
          if(!res.data.department){
                    this.changeLoading(0);
                    this.$router.push({path:'/entry'});
          }else if( !res.data.quest){
                this.$router.push({path:'/operate/'});
          }else{
               this.$router.push({path:"/result"});
          }
      });
    }

  },
  created() {
    this.changeLoading(0)
    this.getuserinfo()
    this.Getinit()
      this.onloadImage();
  }
}
</script>

<style lang="less" rel="stylesheet/less" type="text/less">
/*基本样式*/

@import '~vux/src/styles/reset.less';
@import '~vux/src/styles/1px.less';
@import '~vux/src/styles/tap.less';

/*自定义主题样式*/

@import 'assets/theme.less';
</style>
