import Vue from 'vue'

//设置ajax使用插件
import axios from 'axios'
Vue.prototype.$http = axios
Vue.axios = axios


//注册表单验证
import { VeeValidate } from './libs/Validator'
Vue.use(VeeValidate, {
    errorBagName: 'veeErrors'
});


//自定义全局状态管理
import store from './config/store'

//注册过滤器
import filters from './config/filters'
Object.keys(filters).forEach(key => {
    Vue.filter(key, filters[key])
})

//自定义路由
import router from './config/router'

//vux提示插件
 import  {AlertPlugin, ToastPlugin} from 'vux'
// import AlertPlugin from 'vux/src/plugins/alert/index.js'
// import ToastPlugin from 'vux/src/plugins/toast/index.js'
Vue.use(AlertPlugin)
Vue.use(ToastPlugin)

// 移除移动端点击延迟
import FastClick from 'fastclick'
FastClick.attach(document.body)


//项目启动项
import App from './App.vue'

const app = new Vue({
    router,
    store,
    ...App
}).$mount('#app')