<template>
  <div class="app-page-home">
     <div  class="page-header-logo">
          <img src="~assets/logo.png" />
     </div>
     <div  class="page-content">
         <p>{{title}}</p>
         <p>GCO在此推出本店现有各色菜<span class="page-content-mini">{{content3[0]}}</span>
         品<span  class="page-content-mini">{{content3[1]}}</span>大全,邀您点评，该点评约需要您5分钟时间。</p> 
        <p>2018年主推啥菜系,您的口<span  class="page-content-mini">{{content3[2]}}</span>味<span  class="page-content-mini">{{content3[3]}}</span>来做主</p>
        <p class="page-content-menu">{{username}}</p>
     </div>
     <div  class="page-section">
           <img src="~assets/user.png"  />
           <p>调研针对如下4类同事，请点击选择</p>
               <div class="page-section-box" v-for="(item,index)  in userlist"  :key="index">
              <div class="page-section-list" v-on:click="GetUser(index)"  >
                    {{item[0]}}
              </div>
              <span  class="page-section-con">{{item[1]}}</span>
              </div>
     </div>
     <a class="page-entry" @click="GetuserInfo" ></a>
  </div>
</template>

<script type="text/ecmascript-6">
import { mapMutations, mapActions ,mapState } from 'vuex'
export default {
  components: { },
  data() {
    return {
        title:"各位客官（销售/市场/医学部同事）：",
        username:"店家：GCO-全球商务运作团队",
        content3:["(服)","(务)","(反)","(馈)"],
        userlist:[["MICS","27项服务，请您评价"],["DM,RM","37项服务，请您评价"],["RPM","10项服务，请您评价"],["市场部,医学部","16项服务，请您评价"]],
        userid:0,
        user:this.$store.state.department,
    }
  },
  computed: { 
  },
  methods: {
     ...mapMutations([
      "changeIsAuth", "changeLoading","changedepartment"
    ]),
    GetuserInfo(){
       if(this.user){
                     this.$router.push({path:'/operate/'});
       }else{
            this.$vux.alert.show({
                    title: '请选择部门',
                    content:""
                })
       }
    },
      GetUser(id){
          this.changedepartment(this.userlist[id][0]);
          this.user=this.userlist[id];
        var  userlist=document.getElementsByClassName('page-section-list');
           for(var i=0;i<userlist.length;i++){
               userlist[i].classList.remove('page-section-dan');
           }
           userlist[id].classList.add('page-section-dan');
      },
  }
}
</script>
<style lang="less" rel="stylesheet/less" type="text/less">
  /*基本样式*/
  @import '~vux/src/styles/reset.less';
  @import '~vux/src/styles/1px.less';
  @import '~vux/src/styles/tap.less';
  /*自定义主题样式*/
   @import '~assets/theme.less';
.app-page-home{
    width:80%;
    height: 100%;
    background:url("~assets/entrybg.png") 0% 0% no-repeat;
    background-size: 100%;
    padding:0 10%;
    .page-header-logo {
    width:100%;
    padding:0 0.1rem;
    box-sizing:border-box;
    padding-top:0.4rem;
    text-align: center;
    img {
      width: 100%;
      display:block;
    }
  }
    .page-section{
        width:100%;
        font-size:0.2rem;
        padding:0.2rem 0;
         border-radius:5px 5px  0 0;
        background:rgba(204,204,204,0.4);
        img{
            max-width:50%;
            padding:0 25%;
            display:block;
        }
        p{
           text-align: center ;
           padding:0.05rem 0;
        }
        .page-section-box{
            display:flex;
            margin:0  0.2rem 0.2rem 0.2rem;
            .page-section-list{
             display: inline;
             flex:1;   
            text-align: center;
            padding:0.05rem 0;
            border:2px solid #7cb9dc;
            border-radius: 4px;
        }
        .page-section-con{
            padding:0.05rem 0.4rem;
            border:2px solid transparent;
        }
        .page-section-dan{
            background:blue;
            color:#fff;
            border:2px solid blue;
            border-radius: 4px;
        }
        }
        
        
    }
    .page-content{
        width:100%;  
        font-size:0.22rem;
        line-height:0.44rem;
        letter-spacing: 1px ;
        padding:0.3rem 0;
        .page-content-mini{
            transform: scale(0.80);
            display:inline-block;
        }
        .page-content-menu{
            text-align: right;
        }
    }
    .page-entry{
        margin: 0.3rem auto;
        width:2rem;
        height:0.6rem;
        background:url("~assets/next.png") 0% 0% no-repeat;
        background-size: 100% 100%;
        display:block;
    }
    
}
</style>


