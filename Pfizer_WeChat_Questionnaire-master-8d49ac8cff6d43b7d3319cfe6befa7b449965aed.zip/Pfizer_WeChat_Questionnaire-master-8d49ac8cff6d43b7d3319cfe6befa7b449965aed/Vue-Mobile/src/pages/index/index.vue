<script type="text/ecmascript-6">

  import entryHome  from"./Home"
  import pageList  from "./List"
  import  Result from "./Result"
  export  default
  {
      entryHome , pageList, Result
  }

</script>