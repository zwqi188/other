<template>
  <div class="page-result">
      <p>您的每一个反馈对我们都很重要。<br/>谢谢！</p>
      <p  style="text-align:right;">GCO</p>
  </div>
</template>
<script type="text/ecmascript-6">
export default {
  components: {

  },
  data() {
    return {
    }
  },
  methods: {
  }
}
</script>
<style lang="less" rel="stylesheet/less" type="text/less">
 .page-result{
     width: 100%;
     box-sizing: border-box;
     padding-top:50%  ;
     height: 100vh;
     background: -webkit-linear-gradient(#eef2f4, #c1c8cd);
     overflow: hidden;
     p{
       font-size:0.3rem;
       padding:0 13%;
       text-align: left;
       line-height:0.8rem;
       margin:auto;
      color:#000;
     }
 }
</style>