<template>
    <div id="pageoperate" class="page-operate">
        <!--加载Loading-->
    <div class="app-loading" v-if="loading">
      <img src="~assets/loading.svg" />
    </div>
        <!-- 头部区域 -->
        <div id="pageheader" class="page-operate-header">
            <img src="~assets/say.png" />
        </div>
        <!-- 中间内容区域 -->
        <div class="page-operate-content">
            <div v-show="!showfiles" id="pagecontent" class="page-scroller-content">
                <div class="page-scroller">
                    <div class="tab-list">
                        <div class="page-tab-item   page-position" :tabindex="index" :style="positionstyle" v-for="(item , index ) in  filename" :key="index">
                            <p v-html="item[1]"></p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- 底部文件夹区域 -->
            <div class="page-operate-menu" id="pagebox">
                <div class="operate-menu-list">
                    <div class="menu-list-item" :class="item.isopen ? item.name : ''" v-on:click="showfilesinfo(index)" v-for="(item , index) in filelist" :key="index">
                        <span  class="menu-list-icon" v-show="item.list.length">{{item.list.length}}</span>
                    </div>
                </div>
                <div class="operate-menu-item">
                    <a class="operate-menu-btn" @click="datasend"></a>
                </div>
            </div>
        </div>
        <!-- 浏览文件夹页面模板 -->
        <div v-show="showfiles" id="pagefiles" class="page-files">
            <div @click="hidefilesinfo" class="page-files-hide"></div>
            <div class="page-files-show" id="filesshow">
                <div class="tab-header" id="tabheader">修改选择，将服务项直接拖入合适文件夹即可</div>
                <div class="page-files-content" id="tabfilecontent">
                    <div class="files-scroller">
                        <div class="tab-list  pagetabbox" v-for="(item , index ) in  filelist" v-show="menuindex==index" :key="index">
                            <div class="page-tab-item  page-tab-show" :tabindex="index" :style="positionstyle" v-for="( items , index ) in item.list" :key="index">
                                <p v-html="items[1]"></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script type="text/ecmascript-6">
import { mapState,mapMutations, mapActions } from 'vuex'
import { MICS, DMRM, RPM, Mark } from "../../config";
export default {
    components: {
    },
    data() {
        return {
            filename: [],
            user: this.$store.state.department,
            loading:1,
            filelist: [
                { list: [], isopen: false, name: "menu-list-dan1" },
                { list: [], isopen: false, name: "menu-list-dan2" },
                { list: [], isopen: false, name: "menu-list-dan3" },
                { list: [], isopen: false, name: "menu-list-dan4" },
                { list: [], isopen: false, name: "menu-list-dan5" },
                { list: [], isopen: false, name: "menu-list-dan6" }
            ],
            showfiles: false,
            hidefiles: false,
            positionstyle: {
                width: "32%",
                height: "1rem",
                display:'none'
            },
            tablist: null,
            tabX: null,
            tabY: null,
            boxtop: null,//头部容器
            filebox: null,
            fileindex: null,//标签索引
            filecontent: null,
            menuindex: "index", //文件夹索引
            scrollTop: null,//滚动条滚动的距离
            scrollerheight: null,
            pagebox: null, //文件夹容器,
            showfilelist: null,
            showlist: null,
            tabheader: null,
            isopen:null,
            startinit:true

        }
    },
    computed: {
    },
    methods: {
        ...mapMutations([
       "changeLoading","changedepartment"
    ]),
        //获取数据
        GetUser() {
            switch (this.user) {
                case "MICS":
                    this.filename = MICS;
                    break;
                case "DM,RM":
                    this.filename = DMRM
                    break;
                case "RPM":
                    this.filename = RPM
                    break;
                case "市场部,医学部":
                    this.filename = Mark
                    break;
            }
             if(!this.user){
                  this.$router.push({path:'/entry'});
             }else if(this.filename.length == 0){
                  this.$router.push({path:'/result'});
             }
        },
        //发送数据
        datasend() {
            if (this.filename.length == 0) {
                this.$http.post("/api/QuestionnaireResult", {
                    department:this.user,
                    data1: this.dataarr(this.filelist[0].list),
                    data2: this.dataarr(this.filelist[1].list),
                    data3: this.dataarr(this.filelist[2].list),
                    data4: this.dataarr(this.filelist[3].list),
                    data5: this.dataarr(this.filelist[4].list),
                    data6: this.dataarr(this.filelist[5].list)
                }).then((res) => {
                    if (res.data.result == "1") {
                        this.$router.push({ path: "/result" });
                    } else {
                        this.$vux.toast.show({
                            text: res.data.errmsg || '提交失败'
                        })
                        setTimeout(() => {
                            this.$vux.toast.hide();
                        }, 1000)
                    }
                })
            }else{
                this.$vux.alert.show({
                    title: '请全部选择',
                })
            }

        },
        //处理数据
        dataarr(data) {
            let arr = [];
            for (let item of data) {
                arr.push(item[0])
            }
            return arr;
        },

        //显示文件夹内容
        showfilesinfo(index) {
            if ( this.menuindex == index) {
                this.showfiles = !this.showfiles;
                this.filelist[this.menuindex].isopen = false ;
            } else {
                this.showfiles = true;
            }
            this.menuindex = index;
            if (this.showfiles) {
                this.fileboxinit();
                var pagetabbox = document.getElementsByClassName('pagetabbox');
                this.showfilelist = pagetabbox[index].getElementsByClassName('page-tab-show');
                this.showlist = this.filelist[index].list;
                if (this.showfilelist.length > 0) {
                    this.filetabinit();
                    this.filestart();
                }
                this.filecontent = this.filelist[index].list;
                for (let item of this.filelist) {
                    item.isopen = false;
                }
                this.filelist[index].isopen = true;
            }

        },
        //初始化文件夹标签位置
        filetabinit() {
            var tabcontent = document.getElementById("tabfilecontent");
            var tabheader = document.getElementById("tabheader");
            this.tabheader = tabheader;
            tabcontent.style.paddingTop = 30 + "px";
            var length = this.showfilelist.length;
            var lenarr = parseInt(length / 3);
            var width = this.showfilelist[0].style.width;
            var height = this.showfilelist[0].style.height;
               this.filelist[this.menuindex].isopen = true;  
            for (let i = 0; i < length; i++) {
                this.showfilelist[i].style.display="block";
                this.showfilelist[i].style.position="absolute";
                var nums = (Math.floor(i / 3) * parseFloat(height) + 0.4* Math.floor(i / 3)).toFixed(2);
                this.showfilelist[i].style.top = nums + "rem";
                this.showfilelist[i].style.left = (i % 3) * 33.5 + "%";
                this.showfilelist[i].classList.remove('page-tab-index');
            }
        },
        //文件夹标签绑定事件
        filestart() {
            for (let item of this.showfilelist) {
                item.addEventListener('touchstart', this.filestartmove, false)
                item.addEventListener('touchmove', this.filemove, false)
                item.addEventListener('touchend', this.filemoveend, false)
            }
        },
        //文件夹标签初始运动
        filestartmove(evnet) {
              this.filelist[this.menuindex].isopen = true;
            let ele = event.target;
            if (event.target.nodeName == "P") {
                ele = event.target.parentNode;
            } else if(event.target.nodeName=="B"){
                ele = event.target.parentNode.parentNode;
            }else{
                ele =event.target;
            }
            this.fileindex = ele.getAttribute('tabindex');
            this.tabX = ele.offsetWidth / 2;
            this.tabY = ele.offsetHeight / 2;
               let startX = event.touches[0].pageX;
            let startY = event.touches[0].pageY;  
            ele.style.position="fixed";
            ele.style.left=startX-this.tabX+"px";
            ele.style.top=startY-this.tabY+"px";
            ele.classList.add("page-tab-index");
            event.preventDefault();
        },
        //文件夹标签开始运动
        filemove(event) {
            var page = document.getElementById('pageoperate');
            var menu = document.getElementsByClassName("operate-menu-item")[0];
            let ele = event.target;
            if (event.target.nodeName == "P") {
                ele = event.target.parentNode;
            } else if(event.target.nodeName=="B"){
                ele = event.target.parentNode.parentNode;
            }else{
                ele = event.target;
            }
            let startX = event.touches[0].pageX;
            let startY = event.touches[0].pageY;    
            if (startX >= 15 && startX <= ele.parentNode.offsetWidth - this.tabX / 2) {
                ele.style.left = startX - this.tabX + "px";
            }
            if (startY >= this.boxtop && startY <= page.offsetHeight - menu.offsetHeight - this.tabY) {
                ele.style.top = startY -this.tabY+"px";
            }
            var tabendx = parseInt(ele.style.left) + this.tabX;
            var tabendy = parseInt(ele.style.top);
            var chax = 0;
            var chay = 0;
            var pagebox = document.getElementById("pagebox");
            for (var i = 0; i < this.filebox.length; i++) {
                chax = tabendx - this.filebox[i].offsetLeft - this.filebox[i].offsetWidth / 2;
                chay = tabendy - this.filebox[i].offsetTop - pagebox.offsetTop;
                this.filelist[i].isopen = false;
                if (Math.abs(chax) > 0 && Math.abs(chax) < this.filebox[i].offsetWidth / 2 && Math.abs(chay) > 0 && Math.abs(chay) < this.filebox[i].offsetHeight / 2) {
                    this.filelist[i].isopen = true;
                } else {
              this.filelist[this.menuindex].isopen = true;                      
                }
            }
        },
        //文件夹标签结束运动
        filemoveend(evnet) {
            let ele = event.target;
            if (event.target.nodeName == "P") {
                ele = event.target.parentNode;
            } else if(event.target.nodeName ==  "B"){
                ele = event.target.parentNode.parentNode;
            }else{
                ele = event.target;
            }          
            var pagebox = document.getElementById("pagebox");
            var tabendx = parseInt(ele.style.left) + this.tabX;
            var tabendy = parseInt(ele.style.top);
            var chax = 0;
            var chay = 0;
            for (var i = 0; i < this.filebox.length; i++) {
                chax = tabendx - this.filebox[i].offsetLeft - this.filebox[i].offsetWidth / 2;
                chay = tabendy - this.filebox[i].offsetTop - pagebox.offsetTop;
                this.filelist[i].isopen = false;
                if (Math.abs(chax) > 0 && Math.abs(chax) < this.filebox[i].offsetWidth / 2 && Math.abs(chay) > 0 && Math.abs(chay) < this.filebox[i].offsetHeight / 2) {
                    this.filelist[i].list.push(this.showlist[this.fileindex]);
                    this.showlist.splice(this.fileindex, 1);
                    if (i < this.filebox.length - 1) {
                        this.filebox[i].classList.add('menu-list-dan');
                    } else {
                        this.filebox[i].classList.add('menu-list-last');
                    }
                    //重新排列
                    this.filetabinit();  
                } else {                 
                    this.filetabinit();  
                }
            }
        },
        //隐藏文件夹内容
        hidefilesinfo() {
            this.showfiles = false;
          this.filelist[this.menuindex].isopen = false;
        },
        //初始化文件夹容器
        fileboxinit() {
            var filebox = document.getElementById("pagefiles");
            filebox.style.height = "57%";
            if(this.boxtop){
                  filebox.style.top = this.boxtop +5+ "px"; 
            }else{
                filebox.style.top=70+"px"
            }
        },
        //标签移动事件开始
        tabstart() {
            for (let item of this.tablist) {
                item.addEventListener('touchstart', this.tostart, false)
                item.addEventListener('touchmove', this.tabmove, false)
                item.addEventListener('touchend', this.tabmoveend, false)
            }
        },
        //初始化移动
        tostart(event) {
            var _this = this
            let ele = event.target;
            if (event.target.nodeName == "P") {
                ele = event.target.parentNode;
            } else if(event.target.nodeName=="B"){
                ele = event.target.parentNode.parentNode;
            }else{
                ele = event.target;
            }
            this.fileindex = ele.getAttribute('tabindex');
            this.tabX = ele.offsetWidth / 2;
            this.tabY = ele.offsetHeight / 2;
            let startX = event.touches[0].pageX;
            let startY = event.touches[0].pageY;  
            ele.style.position="fixed";
            ele.style.left=startX-this.tabX+"px";
            ele.style.top=startY-this.tabY+"px";
            ele.classList.add("page-tab-index");
            event.preventDefault();
        },
        //开始移动
        tabmove(event) {
            var page = document.getElementById('pageoperate');
            var menu = document.getElementsByClassName("operate-menu-item")[0];
            let ele = event.target;
            if (event.target.nodeName == "P") {
                ele = event.target.parentNode;
            } else if(event.target.nodeName =="B"){
                ele = event.target.parentNode.parentNode;
            }else{
                ele =event.target;
            }
            let startX = event.touches[0].pageX;
            let startY = event.touches[0].pageY;
            if (startX >= 15 && startX <= ele.parentNode.offsetWidth - this.tabX / 2) {
                ele.style.left = startX - this.tabX + "px";
            }
            if (startY >= this.boxtop && startY <= page.offsetHeight - menu.offsetHeight - this.tabY) {
                ele.style.top = startY - this.tabY + "px";
            }
            var tabendx = parseInt(ele.style.left) + this.tabX;
            var tabendy = parseInt(ele.style.top)+this.tabY;
            var chax = 0;
            var chay = 0;
            var pagebox = document.getElementById("pagebox");
            for (var i = 0; i < this.filebox.length; i++) {
                chax = tabendx - this.filebox[i].offsetLeft - this.filebox[i].offsetWidth / 2;
                chay = tabendy - this.filebox[i].offsetTop -this.filebox[i].offsetHeight/2 - pagebox.offsetTop;
                this.filelist[i].isopen = false;
                if (Math.abs(chax) > 0 && Math.abs(chax) < this.filebox[i].offsetWidth / 2 && Math.abs(chay) > 0 && Math.abs(chay) < this.filebox[i].offsetHeight/2) {
                    this.filelist[i].isopen = true;
                } else {
                }
            }
            event.preventDefault();
        },
        //标签结束移动
        tabmoveend(event) {
            let ele = event.target;
            if (event.target.nodeName == "P") {
                ele = event.target.parentNode;
            } else if(event.target.nodeName == "B") {
                ele = event.target.parentNode.parentNode;
            }else{
                ele=event.target;
            }
            var tabendx = parseInt(ele.style.left) + this.tabX;
            var tabendy = parseInt(ele.style.top)+this.tabY;
            var chax = 0;
            var chay = 0;
            var pagebox = document.getElementById("pagebox");
            for (var i = 0; i < this.filebox.length; i++) {
                chax = tabendx - this.filebox[i].offsetLeft - this.filebox[i].offsetWidth / 2;
                chay = tabendy - this.filebox[i].offsetTop -this.filebox[i].offsetHeight/2 - pagebox.offsetTop;
                this.filelist[i].isopen = false;
                if (Math.abs(chax) > 0 && Math.abs(chax) < this.filebox[i].offsetWidth / 2 && Math.abs(chay) > 0 && Math.abs(chay) < this.filebox[i].offsetHeight / 2) {
                    this.filelist[i].list.push(this.filename[this.fileindex]);
                    this.filename.splice(this.fileindex, 1);
                    if (i < this.filebox.length - 1) {
                        this.filebox[i].classList.add('menu-list-dan');
                    } else {
                        this.filebox[i].classList.add('menu-list-last');
                    }
                    //重新排列
                    this.tabposition();
                } else {
                    this.tabposition();
                }
            }
        },
        //初始化标签位置
        tabposition() {
            this.tablist = document.getElementsByClassName("page-position");
            this.pagebox = document.getElementById("pagebox"); 
             var contentbox = document.getElementById('pagecontent');
            var header = document.getElementById("pageheader");
             this.boxtop = header.offsetHeight;
            contentbox.parentNode.style.paddingBottom = this.pagebox.offsetHeight + 10 + "px";
            contentbox.parentNode.style.paddingTop = header.offsetHeight+ "px";
            this.filebox = document.getElementsByClassName("menu-list-item");
            var length = this.tablist.length;
            if (length > 0) {
                var width = this.tablist[0].style.width;
                var height = this.tablist[0].style.height;
                for (let i = 0; i < length; i++) {
                    this.tablist[i].style.position = "absolute";
                    this.tablist[i].style.display = "block";
                    this.tablist[i].style.left = (i % 3) * 34 + "%";
                    var num = (Math.floor(i / 3) * parseFloat(height) + 0.4 * Math.floor(i / 3)).toFixed(2);
                    this.tablist[i].style.top = num + "rem";
                    this.tablist[i].classList.remove('page-tab-index');
                }
            }
            if (length > 2) {
                this.scrollheight = parseFloat(this.tablist[length - 1].style.top) + parseFloat(this.tablist[length - 1].style.height);
            }
                 contentbox.style.height = this.scrollheight + "rem";
        },
        //判断
    },
    activated() {
    },
    mounted() {
        this.GetUser();
        setTimeout(() => {
            this.loading=0;
            this.tabposition();
            this.tabstart();
        }, 1000)

    }
}
</script>
<style lang="less" rel="stylesheet/less" type="text/less">
.page-operate {
    width: 100%;
    height: 100vh;
    background: -webkit-linear-gradient(#eef2f4, #c1c8cd);
    overflow-y: scroll;
    font-size: 0.12rem;
    .page-operate-header {
        display: block;
        position: fixed;
        width:100%;
        z-index: 10;
        background:-webkit-linear-gradient(#eef2f4, #eaeef0);
        padding: 0.1rem 0;
        img {
            max-width: 100%;
            // display: block;
        }
    }
    .page-files {
        width: 96%;
        box-sizing: border-box;
        position: fixed;
        z-index: 10;
        left: 2%;
        border-radius: 5px;
        border: 3px solid blue;
        .page-files-show {
            width: 100%;
            height: 100%;
            overflow-y: scroll;
            overflow-x: hidden;
            position: relative;
            z-index: 8;
            .tab-header {
                position: relative;
                color: #999;
                text-align: center;
                width: 100%;
                left: 0;
                top: 0;
                padding: 5px 0;
            }
            .page-files-content {
                width: 100%;
                position: absolute;
                left: 0;
                min-height:80%;
                top: 0;
                z-index: 10;
                .files-scroller {
                    height: 100%;
                    position: relative;
                    .tab-list {
                        .page-tab-index {
                            z-index: 99;
                            transform: scale(0.5);
                        }
                        .page-tab-item {
                            background: url("~assets/file.png") 0% 0% no-repeat;
                            background-size: 100% 100%;
                            box-shadow: 2px 0px 5px #ccc;
                            border-radius: 5px;
                            position: absolute;
                            p {
                                position: absolute;
                                left: 0;
                                right: 0;
                                top: 0;
                                bottom: 0;
                                 width:100%;
                                  box-sizing:border-box;
                                 padding:0 7%;
                                margin: auto;
                                display: table;
                                font-weight: 900;
                                font-size: 0.2rem;
                                b {
                                    color: #2975ff;
                                }
                            }
                        }
                    }
                }
            }
        }
        .page-files-hide {
            position: absolute;
            z-index: 18;
            right: -0.18rem;
            top: -0.25rem;
            background: url("~assets/nofalse.png") 0% 0% no-repeat;
            background-size: 100%;
            width: 0.5rem;
            height: 0.5rem;
        }
    }

    .page-operate-content {
        padding: 0 0.1rem;
        padding-bottom: 0.1rem;
        position: relative;
        .page-scroller-content {
            min-height: 300px;
            position: relative;
            height: 100%;
            .page-scroller {
                .tab-list {
                    .page-tab-index {
                        z-index: 99;
                        transform: scale(0.5);
                    }
                    .page-tab-item {
                        position: absolute;
                        margin: 0.1rem 0;
                        background: url("~assets/file.png") 0% 0% no-repeat;
                        background-size: 100% 100%;
                        box-shadow: 2px 0px 5px #ccc;
                        border-radius: 5px;

                        p {
                            position: absolute;
                            left: 0;
                            right: 0;
                            bottom: 0;
                            top: 0;
                            width:100%;
                            box-sizing:border-box;
                            padding:0 7%;
                            margin: auto;
                            display: table;
                            font-weight: 900;
                           font-size: 0.2rem;
                            b {
                                color: #2975ff;
                            }
                        }
                    }
                }
            }
        }
    }
    .page-operate-menu {
        position: fixed;
        width: 100%;
        z-index: 10;
        box-sizing: border-box;
        left: 0;
        bottom: 0;
        background: -webkit-linear-gradient(#cfd5d8, #fff);
        height: 30%;
        padding: 0 0.05rem;
        .operate-menu-list {
            height: 70%;
            display: flex;
            flex-wrap: wrap;
            align-content: flex-start;
            justify-content: center;
            div:nth-last-child(1) {
                background: url("~assets/nofiles.png") 0% 0% no-repeat;
                background-size: 100%;
            }
            div:nth-of-type(1) {
                background: url('~assets/nofiles1.png') 0% 0% no-repeat;
                background-size: 100%;
            }
            div:nth-of-type(2) {
                background: url('~assets/nofiles2.png') 0% 0% no-repeat;
                background-size: 100%;
            }
            div:nth-of-type(3) {
                background: url('~assets/nofiles3.png') 0% 0% no-repeat;
                background-size: 100%;
            }
            div:nth-of-type(4) {
                background: url('~assets/nofiles4.png') 0% 0% no-repeat;
                background-size: 100%;
            }
            div:nth-of-type(5) {
                background: url('~assets/nofiles5.png') 0% 0% no-repeat;
                background-size: 100%;
            }
            .menu-list-item {
                width: 19%;
                margin-right: 1%;
                height: 40%;
                color: #fff;
                margin-top: 0.07rem;
                background-size: 100% 100%;
                position: relative;
                .menu-list-icon{
                    position: absolute;
                    top:0.01rem;left:0.1rem;
                    padding:0 0.06rem;
                    background:red;
                    border-radius: 100%;
                }
            }
            div.menu-list-dan1 {
                background: url("~assets/havefiles1.png") 0% 0% no-repeat;
                background-size: 100%;
            }
            div.menu-list-dan2 {
                background: url("~assets/havefiles2.png") 0% 0% no-repeat;
                background-size: 100%;
            }
            div.menu-list-dan3 {
                background: url("~assets/havefiles3.png") 0% 0% no-repeat;
                background-size: 100%;
            }
            div.menu-list-dan4 {
                background: url("~assets/havefiles4.png") 0% 0% no-repeat;
                background-size: 100%;
            }
            div.menu-list-dan5 {
                background: url("~assets/havefiles5.png") 0% 0% no-repeat;
                background-size: 100%;
            }
            div.menu-list-dan6 {
                background: url("~assets/nouser.png") 0% 0% no-repeat;
                background-size: 100%;
            }
        }
        .operate-menu-item {
            display: flex;
            height: 30%;
            justify-content: center;
            a:nth-of-type(1) {
                background: url("~assets/btnsend.png") 0% 0% no-repeat;
                background-size: 100%;
            }
            .operate-menu-btn {
                margin: 0 0.13rem; // margin-bottom:0.1rem;
                width: 30%;
                height: 100%;
                color: #fff;
                font-size: 0.14rem;
                display: block;
            }
        }
    }
}
</style>