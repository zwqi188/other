/**
 * Created by QingLiang.TAN on 2017/4/26.
 */

var express = require('express')

// var app = express()

var fs = require('fs'); // 载入fs模块

/***********************Start 自定义测试接口******************************/
var apiRoutes = express.Router();

//发现手机验证码
apiRoutes.post('/Mobile/User/SendMobileCode', function (req, res) {
  res.json({"result": 1})
});


/**********************End 自定义测试接口*******************************/
//列表-
apiRoutes.post('/mobile/*/List', function (req, res) {
  res.json([])
});

//详情-
apiRoutes.post('/mobile/*/Info', function (req, res) {
  res.json({"ID": 1})
});

//创建--
apiRoutes.post('/mobile/*/Create', function (req, res) {
  res.json({"result": 1})
});

//更新--
apiRoutes.post('/mobile/*/Update/:id', function (req, res) {
  res.json({"result": 1})
});

//删除--
apiRoutes.post('/mobile/*/Delete', function (req, res) {
  res.json({"result": 1})
});


module.exports = apiRoutes;
