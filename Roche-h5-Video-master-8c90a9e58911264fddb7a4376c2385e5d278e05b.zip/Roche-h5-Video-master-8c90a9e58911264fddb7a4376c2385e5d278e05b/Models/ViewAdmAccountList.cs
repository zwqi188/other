﻿using System;
using System.Collections.Generic;
using System.Text;
using DbUtility;

namespace Models
{
    public partial class ViewAdmAccountList: EntityBase
    {

		        /// <summary>
        ///
        /// </summary>
        private DateTime? _CreateDate;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("CreateDate", false, false, true)]
        public DateTime? CreateDate { get { return _CreateDate;} set{_CreateDate = value;OnPropertyChanged("CreateDate");} } 


        /// <summary>
        ///
        /// </summary>
        private String _UserName;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("UserName", false, false, false)]
        public String UserName { get { return _UserName;} set{_UserName = value;OnPropertyChanged("UserName");} } 


        /// <summary>
        ///
        /// </summary>
        private String _RealName;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("RealName", false, false, true)]
        public String RealName { get { return _RealName;} set{_RealName = value;OnPropertyChanged("RealName");} } 


        /// <summary>
        ///
        /// </summary>
        private String _Avatar;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Avatar", false, false, true)]
        public String Avatar { get { return _Avatar;} set{_Avatar = value;OnPropertyChanged("Avatar");} } 


        /// <summary>
        ///
        /// </summary>
        private String _Email;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Email", false, false, true)]
        public String Email { get { return _Email;} set{_Email = value;OnPropertyChanged("Email");} } 


        /// <summary>
        ///
        /// </summary>
        private String _Mobile;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Mobile", false, false, true)]
        public String Mobile { get { return _Mobile;} set{_Mobile = value;OnPropertyChanged("Mobile");} } 


        /// <summary>
        ///
        /// </summary>
        private String _GroupName;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("GroupName", false, false, true)]
        public String GroupName { get { return _GroupName;} set{_GroupName = value;OnPropertyChanged("GroupName");} } 




    }
}