﻿using System;
using System.Collections.Generic;
using System.Text;
using DbUtility;

namespace Models
{
    public partial class Video: EntityBase
    {

        public bool UserLike { set; get; }

    }
}