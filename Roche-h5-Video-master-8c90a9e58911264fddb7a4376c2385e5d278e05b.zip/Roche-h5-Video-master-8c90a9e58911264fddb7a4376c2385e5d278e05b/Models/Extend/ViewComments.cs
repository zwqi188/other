﻿using System;
using System.Collections.Generic;
using System.Text;
using DbUtility;

namespace Models
{
    public partial class ViewComments: EntityBase
    {

        public string CommentDate {
            get
            {
                return this.CreateDate.HasValue ? this.CreateDate.Value.ToString("yyyy/MM/dd") : string.Empty;
            }
        }

    }
}