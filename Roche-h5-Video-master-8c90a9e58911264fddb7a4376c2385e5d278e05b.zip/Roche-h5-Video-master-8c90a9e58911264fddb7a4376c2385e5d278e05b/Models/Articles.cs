﻿using System;
using System.Collections.Generic;
using System.Text;
using DbUtility;

namespace Models
{
    public partial class Articles: EntityBase
    {

		        /// <summary>
        ///
        /// </summary>
        private DateTime? _CreateDate;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("CreateDate", false, false, true)]
        public DateTime? CreateDate { get { return _CreateDate;} set{_CreateDate = value;OnPropertyChanged("CreateDate");} } 


        /// <summary>
        ///
        /// </summary>
        private DateTime? _LastUpdateDate;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("LastUpdateDate", false, false, true)]
        public DateTime? LastUpdateDate { get { return _LastUpdateDate;} set{_LastUpdateDate = value;OnPropertyChanged("LastUpdateDate");} } 


        /// <summary>
        ///
        /// </summary>
        private Int32? _CreateUserID;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("CreateUserID", false, false, true)]
        public Int32? CreateUserID { get { return _CreateUserID;} set{_CreateUserID = value;OnPropertyChanged("CreateUserID");} } 


        /// <summary>
        ///
        /// </summary>
        private Int32? _LastUpdateUserID;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("LastUpdateUserID", false, false, true)]
        public Int32? LastUpdateUserID { get { return _LastUpdateUserID;} set{_LastUpdateUserID = value;OnPropertyChanged("LastUpdateUserID");} } 


        /// <summary>
        ///
        /// </summary>
        private String _Title;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Title", false, false, false)]
        public String Title { get { return _Title;} set{_Title = value;OnPropertyChanged("Title");} } 


        /// <summary>
        ///
        /// </summary>
        private String _Author;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Author", false, false, true)]
        public String Author { get { return _Author;} set{_Author = value;OnPropertyChanged("Author");} } 


        /// <summary>
        ///
        /// </summary>
        private String _Category;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Category", false, false, true)]
        public String Category { get { return _Category;} set{_Category = value;OnPropertyChanged("Category");} } 


        /// <summary>
        ///
        /// </summary>
        private String _Cover;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Cover", false, false, true)]
        public String Cover { get { return _Cover;} set{_Cover = value;OnPropertyChanged("Cover");} } 


        /// <summary>
        ///
        /// </summary>
        private String _Label;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Label", false, false, true)]
        public String Label { get { return _Label;} set{_Label = value;OnPropertyChanged("Label");} } 


        /// <summary>
        ///
        /// </summary>
        private String _Summary;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Summary", false, false, true)]
        public String Summary { get { return _Summary;} set{_Summary = value;OnPropertyChanged("Summary");} } 


        /// <summary>
        ///
        /// </summary>
        private String _Content;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Content", false, false, true)]
        public String Content { get { return _Content;} set{_Content = value;OnPropertyChanged("Content");} } 


        /// <summary>
        ///
        /// </summary>
        private String _Attachment;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Attachment", false, false, true)]
        public String Attachment { get { return _Attachment;} set{_Attachment = value;OnPropertyChanged("Attachment");} } 


        /// <summary>
        ///
        /// </summary>
        private String _OriginalAddress;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("OriginalAddress", false, false, true)]
        public String OriginalAddress { get { return _OriginalAddress;} set{_OriginalAddress = value;OnPropertyChanged("OriginalAddress");} } 


        /// <summary>
        ///
        /// </summary>
        private Int32? _ReleaseStatus;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("ReleaseStatus", false, false, true)]
        public Int32? ReleaseStatus { get { return _ReleaseStatus;} set{_ReleaseStatus = value;OnPropertyChanged("ReleaseStatus");} } 


        /// <summary>
        ///
        /// </summary>
        private DateTime? _ReleaseTime;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("ReleaseTime", false, false, true)]
        public DateTime? ReleaseTime { get { return _ReleaseTime;} set{_ReleaseTime = value;OnPropertyChanged("ReleaseTime");} } 


        /// <summary>
        ///
        /// </summary>
        private Int32? _SortValue;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("SortValue", false, false, true)]
        public Int32? SortValue { get { return _SortValue;} set{_SortValue = value;OnPropertyChanged("SortValue");} } 


        /// <summary>
        ///
        /// </summary>
        private Int32? _ReadNumber;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("ReadNumber", false, false, true)]
        public Int32? ReadNumber { get { return _ReadNumber;} set{_ReadNumber = value;OnPropertyChanged("ReadNumber");} } 


        /// <summary>
        ///
        /// </summary>
        private Int32? _LikeNumber;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("LikeNumber", false, false, true)]
        public Int32? LikeNumber { get { return _LikeNumber;} set{_LikeNumber = value;OnPropertyChanged("LikeNumber");} } 


        /// <summary>
        ///
        /// </summary>
        private Int32? _ShareNumber;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("ShareNumber", false, false, true)]
        public Int32? ShareNumber { get { return _ShareNumber;} set{_ShareNumber = value;OnPropertyChanged("ShareNumber");} } 


        /// <summary>
        ///
        /// </summary>
        private Int32? _CommentNumber;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("CommentNumber", false, false, true)]
        public Int32? CommentNumber { get { return _CommentNumber;} set{_CommentNumber = value;OnPropertyChanged("CommentNumber");} } 


        /// <summary>
        ///
        /// </summary>
        private Decimal? _ScoreValue;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("ScoreValue", false, false, true)]
        public Decimal? ScoreValue { get { return _ScoreValue;} set{_ScoreValue = value;OnPropertyChanged("ScoreValue");} } 




    }
}