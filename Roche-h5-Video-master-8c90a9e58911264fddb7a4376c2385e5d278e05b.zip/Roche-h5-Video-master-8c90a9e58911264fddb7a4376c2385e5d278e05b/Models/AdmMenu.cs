﻿using System;
using System.Collections.Generic;
using System.Text;
using DbUtility;

namespace Models
{
    public partial class AdmMenu: EntityBase
    {

		        /// <summary>
        ///
        /// </summary>
        private DateTime? _CreateDate;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("CreateDate", false, false, true)]
        public DateTime? CreateDate { get { return _CreateDate;} set{_CreateDate = value;OnPropertyChanged("CreateDate");} } 


        /// <summary>
        ///
        /// </summary>
        private DateTime? _LastUpdateDate;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("LastUpdateDate", false, false, true)]
        public DateTime? LastUpdateDate { get { return _LastUpdateDate;} set{_LastUpdateDate = value;OnPropertyChanged("LastUpdateDate");} } 


        /// <summary>
        ///
        /// </summary>
        private Int32? _CreateUserID;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("CreateUserID", false, false, true)]
        public Int32? CreateUserID { get { return _CreateUserID;} set{_CreateUserID = value;OnPropertyChanged("CreateUserID");} } 


        /// <summary>
        ///
        /// </summary>
        private Int32? _LastUpdateUserID;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("LastUpdateUserID", false, false, true)]
        public Int32? LastUpdateUserID { get { return _LastUpdateUserID;} set{_LastUpdateUserID = value;OnPropertyChanged("LastUpdateUserID");} } 


        /// <summary>
        ///
        /// </summary>
        private String _MenuName;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("MenuName", false, false, false)]
        public String MenuName { get { return _MenuName;} set{_MenuName = value;OnPropertyChanged("MenuName");} } 


        /// <summary>
        ///
        /// </summary>
        private String _RouteName;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("RouteName", false, false, true)]
        public String RouteName { get { return _RouteName;} set{_RouteName = value;OnPropertyChanged("RouteName");} } 


        /// <summary>
        ///
        /// </summary>
        private String _RouteUrl;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("RouteUrl", false, false, true)]
        public String RouteUrl { get { return _RouteUrl;} set{_RouteUrl = value;OnPropertyChanged("RouteUrl");} } 




    }
}