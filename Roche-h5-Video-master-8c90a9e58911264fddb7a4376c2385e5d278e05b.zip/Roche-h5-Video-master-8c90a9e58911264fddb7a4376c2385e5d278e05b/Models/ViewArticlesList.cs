﻿using System;
using System.Collections.Generic;
using System.Text;
using DbUtility;

namespace Models
{
    public partial class ViewArticlesList: EntityBase
    {

		        /// <summary>
        ///
        /// </summary>
        private String _Title;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Title", false, false, false)]
        public String Title { get { return _Title;} set{_Title = value;OnPropertyChanged("Title");} } 


        /// <summary>
        ///
        /// </summary>
        private String _Author;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Author", false, false, true)]
        public String Author { get { return _Author;} set{_Author = value;OnPropertyChanged("Author");} } 


        /// <summary>
        ///
        /// </summary>
        private String _Category;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Category", false, false, true)]
        public String Category { get { return _Category;} set{_Category = value;OnPropertyChanged("Category");} } 


        /// <summary>
        ///
        /// </summary>
        private String _Label;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Label", false, false, true)]
        public String Label { get { return _Label;} set{_Label = value;OnPropertyChanged("Label");} } 


        /// <summary>
        ///
        /// </summary>
        private Int32? _ReleaseStatus;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("ReleaseStatus", false, false, true)]
        public Int32? ReleaseStatus { get { return _ReleaseStatus;} set{_ReleaseStatus = value;OnPropertyChanged("ReleaseStatus");} } 


        /// <summary>
        ///
        /// </summary>
        private DateTime? _ReleaseTime;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("ReleaseTime", false, false, true)]
        public DateTime? ReleaseTime { get { return _ReleaseTime;} set{_ReleaseTime = value;OnPropertyChanged("ReleaseTime");} } 


        /// <summary>
        ///
        /// </summary>
        private Int32? _SortValue;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("SortValue", false, false, true)]
        public Int32? SortValue { get { return _SortValue;} set{_SortValue = value;OnPropertyChanged("SortValue");} } 


        /// <summary>
        ///
        /// </summary>
        private Int32? _ReadNumber;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("ReadNumber", false, false, true)]
        public Int32? ReadNumber { get { return _ReadNumber;} set{_ReadNumber = value;OnPropertyChanged("ReadNumber");} } 


        /// <summary>
        ///
        /// </summary>
        private Int32? _LikeNumber;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("LikeNumber", false, false, true)]
        public Int32? LikeNumber { get { return _LikeNumber;} set{_LikeNumber = value;OnPropertyChanged("LikeNumber");} } 


        /// <summary>
        ///
        /// </summary>
        private Int32? _ShareNumber;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("ShareNumber", false, false, true)]
        public Int32? ShareNumber { get { return _ShareNumber;} set{_ShareNumber = value;OnPropertyChanged("ShareNumber");} } 


        /// <summary>
        ///
        /// </summary>
        private Int32? _CommentNumber;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("CommentNumber", false, false, true)]
        public Int32? CommentNumber { get { return _CommentNumber;} set{_CommentNumber = value;OnPropertyChanged("CommentNumber");} } 


        /// <summary>
        ///
        /// </summary>
        private Decimal? _ScoreValue;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("ScoreValue", false, false, true)]
        public Decimal? ScoreValue { get { return _ScoreValue;} set{_ScoreValue = value;OnPropertyChanged("ScoreValue");} } 




    }
}