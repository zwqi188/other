﻿using System;
using System.Collections.Generic;
using System.Text;
using DbUtility;

namespace Models
{
    public partial class AdmGroup: EntityBase
    {

		        /// <summary>
        ///
        /// </summary>
        private DateTime? _CreateDate;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("CreateDate", false, false, true)]
        public DateTime? CreateDate { get { return _CreateDate;} set{_CreateDate = value;OnPropertyChanged("CreateDate");} } 


        /// <summary>
        ///
        /// </summary>
        private DateTime? _LastUpdateDate;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("LastUpdateDate", false, false, true)]
        public DateTime? LastUpdateDate { get { return _LastUpdateDate;} set{_LastUpdateDate = value;OnPropertyChanged("LastUpdateDate");} } 


        /// <summary>
        ///
        /// </summary>
        private Int32? _CreateUserID;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("CreateUserID", false, false, true)]
        public Int32? CreateUserID { get { return _CreateUserID;} set{_CreateUserID = value;OnPropertyChanged("CreateUserID");} } 


        /// <summary>
        ///
        /// </summary>
        private Int32? _LastUpdateUserID;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("LastUpdateUserID", false, false, true)]
        public Int32? LastUpdateUserID { get { return _LastUpdateUserID;} set{_LastUpdateUserID = value;OnPropertyChanged("LastUpdateUserID");} } 


        /// <summary>
        ///
        /// </summary>
        private String _GroupName;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("GroupName", false, false, false)]
        public String GroupName { get { return _GroupName;} set{_GroupName = value;OnPropertyChanged("GroupName");} } 


        /// <summary>
        ///
        /// </summary>
        private String _GroupDesc;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("GroupDesc", false, false, true)]
        public String GroupDesc { get { return _GroupDesc;} set{_GroupDesc = value;OnPropertyChanged("GroupDesc");} } 


        /// <summary>
        ///
        /// </summary>
        private String _MenuIDs;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("MenuIDs", false, false, true)]
        public String MenuIDs { get { return _MenuIDs;} set{_MenuIDs = value;OnPropertyChanged("MenuIDs");} } 




    }
}