﻿using System;
using System.Collections.Generic;
using System.Text;
using DbUtility;

namespace Models
{
    public partial class Video: EntityBase
    {

		        /// <summary>
        ///
        /// </summary>
        private DateTime? _CreateDate;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("CreateDate", false, false, true)]
        public DateTime? CreateDate { get { return _CreateDate;} set{_CreateDate = value;OnPropertyChanged("CreateDate");} } 


        /// <summary>
        ///
        /// </summary>
        private DateTime? _LastUpdateDate;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("LastUpdateDate", false, false, true)]
        public DateTime? LastUpdateDate { get { return _LastUpdateDate;} set{_LastUpdateDate = value;OnPropertyChanged("LastUpdateDate");} } 


        /// <summary>
        ///
        /// </summary>
        private Int32? _CreateUserID;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("CreateUserID", false, false, true)]
        public Int32? CreateUserID { get { return _CreateUserID;} set{_CreateUserID = value;OnPropertyChanged("CreateUserID");} } 


        /// <summary>
        ///
        /// </summary>
        private Int32? _LastUpdateUserID;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("LastUpdateUserID", false, false, true)]
        public Int32? LastUpdateUserID { get { return _LastUpdateUserID;} set{_LastUpdateUserID = value;OnPropertyChanged("LastUpdateUserID");} } 


        /// <summary>
        ///
        /// </summary>
        private String _Title;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Title", false, false, true)]
        public String Title { get { return _Title;} set{_Title = value;OnPropertyChanged("Title");} } 


        /// <summary>
        ///
        /// </summary>
        private String _Author;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Author", false, false, true)]
        public String Author { get { return _Author;} set{_Author = value;OnPropertyChanged("Author");} } 


        /// <summary>
        ///
        /// </summary>
        private String _Avatar;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Avatar", false, false, true)]
        public String Avatar { get { return _Avatar;} set{_Avatar = value;OnPropertyChanged("Avatar");} } 


        /// <summary>
        ///
        /// </summary>
        private String _Cover;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Cover", false, false, true)]
        public String Cover { get { return _Cover;} set{_Cover = value;OnPropertyChanged("Cover");} } 


        /// <summary>
        ///
        /// </summary>
        private String _Summary;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Summary", false, false, true)]
        public String Summary { get { return _Summary;} set{_Summary = value;OnPropertyChanged("Summary");} } 


        /// <summary>
        ///
        /// </summary>
        private String _Content;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Content", false, false, true)]
        public String Content { get { return _Content;} set{_Content = value;OnPropertyChanged("Content");} } 


        /// <summary>
        ///
        /// </summary>
        private Int32? _SortValue;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("SortValue", false, false, true)]
        public Int32? SortValue { get { return _SortValue;} set{_SortValue = value;OnPropertyChanged("SortValue");} } 


        /// <summary>
        ///
        /// </summary>
        private Int32? _PlayNumber;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("PlayNumber", false, false, true)]
        public Int32? PlayNumber { get { return _PlayNumber;} set{_PlayNumber = value;OnPropertyChanged("PlayNumber");} } 


        /// <summary>
        ///
        /// </summary>
        private Int32? _LikeNumber;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("LikeNumber", false, false, true)]
        public Int32? LikeNumber { get { return _LikeNumber;} set{_LikeNumber = value;OnPropertyChanged("LikeNumber");} } 


        /// <summary>
        ///
        /// </summary>
        private Int32? _CommentNumber;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("CommentNumber", false, false, true)]
        public Int32? CommentNumber { get { return _CommentNumber;} set{_CommentNumber = value;OnPropertyChanged("CommentNumber");} } 


        /// <summary>
        ///
        /// </summary>
        private String _DataConfigFIle;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("DataConfigFIle", false, false, true)]
        public String DataConfigFIle { get { return _DataConfigFIle;} set{_DataConfigFIle = value;OnPropertyChanged("DataConfigFIle");} } 




    }
}