﻿using System;
using System.Collections.Generic;
using System.Text;
using DbUtility;

namespace Models
{
    public partial class WeChatConfig: EntityBase
    {

		        /// <summary>
        ///
        /// </summary>
        private String _CorpID;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("CorpID", false, false, false)]
        public String CorpID { get { return _CorpID;} set{_CorpID = value;OnPropertyChanged("CorpID");} } 


        /// <summary>
        ///
        /// </summary>
        private String _Secret;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Secret", false, false, false)]
        public String Secret { get { return _Secret;} set{_Secret = value;OnPropertyChanged("Secret");} } 


        /// <summary>
        ///
        /// </summary>
        private String _AccessToken;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("AccessToken", false, false, true)]
        public String AccessToken { get { return _AccessToken;} set{_AccessToken = value;OnPropertyChanged("AccessToken");} } 


        /// <summary>
        ///
        /// </summary>
        private DateTime? _ExpiresIn;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("ExpiresIn", false, false, true)]
        public DateTime? ExpiresIn { get { return _ExpiresIn;} set{_ExpiresIn = value;OnPropertyChanged("ExpiresIn");} } 


        /// <summary>
        ///
        /// </summary>
        private String _Ticket;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("Ticket", false, false, true)]
        public String Ticket { get { return _Ticket;} set{_Ticket = value;OnPropertyChanged("Ticket");} } 


        /// <summary>
        ///
        /// </summary>
        private DateTime? _TicketExpiresIn;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("TicketExpiresIn", false, false, true)]
        public DateTime? TicketExpiresIn { get { return _TicketExpiresIn;} set{_TicketExpiresIn = value;OnPropertyChanged("TicketExpiresIn");} } 




    }
}