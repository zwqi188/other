﻿using System;
using System.Collections.Generic;
using System.Text;
using DbUtility;

namespace Models
{
    public partial class Likes: EntityBase
    {

		        /// <summary>
        ///
        /// </summary>
        private DateTime? _CreateDate;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("CreateDate", false, false, true)]
        public DateTime? CreateDate { get { return _CreateDate;} set{_CreateDate = value;OnPropertyChanged("CreateDate");} } 


        /// <summary>
        ///
        /// </summary>
        private Int32 _VideoID;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("VideoID", false, false, false)]
        public Int32 VideoID { get { return _VideoID;} set{_VideoID = value;OnPropertyChanged("VideoID");} } 


        /// <summary>
        ///
        /// </summary>
        private String _WeChatUserID;
        /// <summary>
        ///
        /// </summary>
        [ColumnAttribute("WeChatUserID", false, false, false)]
        public String WeChatUserID { get { return _WeChatUserID;} set{_WeChatUserID = value;OnPropertyChanged("WeChatUserID");} } 




    }
}