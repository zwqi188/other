

标题：贝伐珠单抗效及安全性数据简介(新代表培训)

简介：贝伐珠单抗联合卡铂与紫杉醇一线治疗晚期非鳞NSCLC患者疗效及安全性数据简介

内容：
贝伐珠单抗联合化疗主要研究介绍：晚期非鳞一线新标准
- 主要注册研究：E4599、BEYOND
- 其他注册研究：JO19907
- IV期研究：SAiL（中国）

贝伐珠单抗主要信息介绍：
- 亚洲人群获益更大
- 早期持续使用获益更多
- 显著延长EGFR野生型患者生存
- EGFR突变患者潜力选择

贝伐珠单抗安全性介绍：
- 安全性可预期、易管理


http://cdn.sandbox.edstatic.com/202003120126/9fe5753519367365bb286ad8a3e99f89/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/media/live.mp4

http://cdn.sandbox.edstatic.com/202003120126/9366b2f7d09fa2a9d254b0c32cc02955/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/media/slide.mp4

http://cdn.sandbox.edstatic.com/202003120126/1fbecbde03e2716ac6c2819b77dd8790/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/timeline.json


http://cdn.sandbox.edstatic.com/202003120126/f9f3b82579990ef42fcb6c7b3381b970/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/1.jpg
http://cdn.sandbox.edstatic.com/202003120126/7c1e01d721aae01fbe645c607ad21cb5/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/2.jpg
http://cdn.sandbox.edstatic.com/202003120126/d6ed8caca41203f7efd795fab7c2a3b8/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/3.jpg
http://cdn.sandbox.edstatic.com/202003120126/7dfdd449214a1eb0d44169db76b564d1/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/4.jpg
http://cdn.sandbox.edstatic.com/202003120126/71a7a3aba21dfe92ac37eb0c080897d7/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/5.jpg
http://cdn.sandbox.edstatic.com/202003120126/a3a24bd1c9d5afbbf39c8f53fcbac233/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/6.jpg
http://cdn.sandbox.edstatic.com/202003120126/d2b64b1305d25fddba9c07797d9a6934/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/7.jpg
http://cdn.sandbox.edstatic.com/202003120126/f7a43270f8f3e968f0acb8698334daae/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/8.jpg
http://cdn.sandbox.edstatic.com/202003120126/e6be17caf5c59be6a843c73bd54a85bd/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/9.jpg
http://cdn.sandbox.edstatic.com/202003120126/3fbe9db5720ed72c95cdc1019da6a9b7/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/10.jpg
http://cdn.sandbox.edstatic.com/202003120126/121ae64695ac6ab85b5b8f67eaeb56f7/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/11.jpg
http://cdn.sandbox.edstatic.com/202003120126/c463131bcccc3d75d68daac94581a350/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/12.jpg
http://cdn.sandbox.edstatic.com/202003120126/f37f93581fcb546f300076eab4cca3f8/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/13.jpg
http://cdn.sandbox.edstatic.com/202003120126/82e530345e1bd00c23df9d31d08a4b3d/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/14.jpg
http://cdn.sandbox.edstatic.com/202003120126/35d6c1101adb33429e814097943d844e/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/15.jpg
http://cdn.sandbox.edstatic.com/202003120126/6eb1ad361bef6f354654fd147a793241/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/16.jpg
http://cdn.sandbox.edstatic.com/202003120126/8d580e0bf557d3546b204813ab015fa6/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/17.jpg
http://cdn.sandbox.edstatic.com/202003120126/66318cbe617d82fc31e0d99fd7e94756/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/18.jpg
http://cdn.sandbox.edstatic.com/202003120126/1f5e2f99116351d91d38b427b13119aa/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/19.jpg
http://cdn.sandbox.edstatic.com/202003120126/5f922b274fb203229f391f7b687e34a9/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/20.jpg
http://cdn.sandbox.edstatic.com/202003120126/8602612296d5e4a88d351905e31fc6e2/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/21.jpg
http://cdn.sandbox.edstatic.com/202003120126/354a4707d99376a33cefd35d514cecc2/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/22.jpg
http://cdn.sandbox.edstatic.com/202003120126/68ed5a8517732a3cb6042e3d19f9de6c/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/23.jpg
http://cdn.sandbox.edstatic.com/202003120126/4b7ec42a4d9dfdae6076987b3765c1fc/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/24.jpg
http://cdn.sandbox.edstatic.com/202003120126/fbfb0a5ceed3455933cd29837ed07bd1/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/25.jpg
http://cdn.sandbox.edstatic.com/202003120126/3edb47c8a36a89897c59941b6f7a0173/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/26.jpg
http://cdn.sandbox.edstatic.com/202003120126/5d457b402b756ed5ff36e7f367bc8edc/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/27.jpg
http://cdn.sandbox.edstatic.com/202003120126/f7c71e6677009b7d1b2d2e91639ba27e/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/28.jpg
http://cdn.sandbox.edstatic.com/202003120126/b560b114a515097cb3906d25aa8cef15/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/29.jpg
http://cdn.sandbox.edstatic.com/202003120126/ccacae278e70dee585bccb9716dd35dd/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/30.jpg
http://cdn.sandbox.edstatic.com/202003120126/beb746af0dbeb06b745b75e30b074e58/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/31.jpg
http://cdn.sandbox.edstatic.com/202003120126/7c45a4e4c09ba190ee3c0722436ab5b3/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/32.jpg
http://cdn.sandbox.edstatic.com/202003120126/a56bcd644dc6e8a7ad615a70ae15dfc2/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/33.jpg
http://cdn.sandbox.edstatic.com/202003120126/499ec475d28b66bfb714a65636e79c40/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/34.jpg
http://cdn.sandbox.edstatic.com/202003120126/6ddce1d03f06384067c948ed3fbd90e7/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/35.jpg
http://cdn.sandbox.edstatic.com/202003120126/b7dd2c4417552260081ec7ddf8be961a/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/36.jpg
http://cdn.sandbox.edstatic.com/202003120126/8840ec3aeb36db6d542d5d130b3e6d29/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/37.jpg
http://cdn.sandbox.edstatic.com/202003120126/a3398f9e1b766faee55556a73726ad4a/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/38.jpg
http://cdn.sandbox.edstatic.com/202003120126/6a85a13bd25625567b0cd3160e786896/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/39.jpg
http://cdn.sandbox.edstatic.com/202003120126/02433a2816f8d0aafff0c76e13eeece2/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/40.jpg
http://cdn.sandbox.edstatic.com/202003120126/ce759e7367434e18e9607283ee556a79/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/41.jpg
http://cdn.sandbox.edstatic.com/202003120126/dd19a78aaa7efb8fd01a0c55793ead86/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/42.jpg
http://cdn.sandbox.edstatic.com/202003120126/e5659938f733955fa68500131fa620aa/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/43.jpg
http://cdn.sandbox.edstatic.com/202003120126/23b241339dd630cad13655b8bc0ca778/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/44.jpg
http://cdn.sandbox.edstatic.com/202003120126/4a9c9bfb4921065c578a1dfe6689f6d3/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/45.jpg
http://cdn.sandbox.edstatic.com/202003120126/d5e0a72dddd01a732d36d6c92ce1e7b8/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/46.jpg
http://cdn.sandbox.edstatic.com/202003120126/41dc8f15e42fcb02861825ccc9ca82b2/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/47.jpg
http://cdn.sandbox.edstatic.com/202003120126/c1635f70b6da7e2b70b35f04080a6856/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/48.jpg
http://cdn.sandbox.edstatic.com/202003120126/632796c26cdf531699c09ebd1d2697a4/2017/03/a1ea7f82-d065-36b0-50fb-2bd89833ed63/images/49.jpg
