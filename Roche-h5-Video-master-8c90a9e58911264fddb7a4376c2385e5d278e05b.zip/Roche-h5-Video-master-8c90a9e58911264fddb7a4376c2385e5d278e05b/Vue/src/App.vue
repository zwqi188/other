<template>
  <router-view></router-view>
</template>

<script>
  export default {
    name : 'app'
  }
</script>

<style>
  /*@import '~weui/dist/style/weui.min.css';*/
  /*@import '~weui/dist/example/example.css';*/
  /*@import '~font-awesome/css/font-awesome.css';*/
  body{
    font-family:"lucida grande", "lucida sans unicode", lucida, helvetica, "Hiragino Sans GB", "Microsoft YaHei", "WenQuanYi Micro Hei", sans-serif;
    font-size:16px;
    background-color:#f8f8f8;
  }
</style>
