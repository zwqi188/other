<template>
  <div class="page-message-send">
    <input type="text" placeholder="发表你的言论...." v-model="message"/>
    <div class="page-message-send-button">
      <button :class="{disable: this.timer}" @click="sendMessage()">{{this.timer>0?(this.timer+' s'):'发表'}}</button>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
  import {AjaxPlugin, Toast} from 'vux'

  export default {
    components : {
      AjaxPlugin,
      Toast
    },
    data () {
      return {
        customEventName : 'send-message-back',
        message : null,
        timer : 0
      }
    },
    methods : {
      sendTimer(){
        if(this.timer < 1){
          return false;
        }
        setTimeout((back)=>{
          this.timer = this.timer - 1;
          this.sendTimer();
        }, 1000);
      },
      sendMessage(){
        if(!this.message || this.timer > 0){
          return false;
        }
        AjaxPlugin.$http.post('/Mobile/API/PublishComment/' + this.$route.params.id, {Content : this.message}).then((res)=>{
          if(res.data.errmsg){
            this.$vux.toast.show({
              text : res.data.errmsg,
              type : 'warn',
              time : 500
            })
          } else {
            this.$emit(this.customEventName, res.data);
            this.message = null;
            this.timer = 5;
            this.sendTimer();
          }
        });
      }
    }
  }
</script>
<style>
  .page-message-send{ height:45px; position:fixed; left:0px; right:0px; top:0px; display:flex; z-index:99; background-color:#ffffff; }
  .page-message-send-button{ display:block; width:90px; text-align:center; line-height:45px; }
  .page-message-send-button button{ width:64px; height:30px; line-height:30px; border:none; font-size:12px; color:#ffffff; background-color:#0066CC; border-radius:10px; }
  .page-message-send-button button.disable{ background-color:#989A9C; }
  .page-message-send input{ height:45px; display:flex; flex:1; border:none; text-indent:1.2em;
    box-sizing:border-box;
    background:-webkit-linear-gradient(top, #e5e5e5, #e5e5e5, rgba(229, 229, 229, 0)) bottom left no-repeat;
    background:linear-gradient(180deg, #e5e5e5, #e5e5e5, rgba(229, 229, 229, 0)) bottom left no-repeat;
    background-size:100% 1px; }

</style>
