<template>
  <div class="page-video-comment">
    <message-send @send-message-back="sendMessageBack"></message-send>
    <scroller :on-infinite="ajaxVideoComments" ref="my_scroller" style="top:46px;">
      <div class="page-video-message" v-for="item in messages">
        <div class="page-video-message-avatar"><img :src="item.Avatar"/></div>
        <div class="page-video-message-box">
          <span class="page-video-message-name">{{item.UserName}}</span>
          <span class="page-video-message-date">{{item.CommentDate}}</span>
          <p class="page-user-message">{{item.Content}}</p>
        </div>
      </div>
    </scroller>
  </div>
</template>
<script type="text/ecmascript-6">
  import {AjaxPlugin, Toast} from 'vux'
  import Scroller from 'vue-scroller'
  import messageSend from './send.vue'
  export default{
    components : {
      AjaxPlugin,
      Scroller,
      messageSend
    },
    data () {
      return {
        messages : []
      }
    },
    methods : {
      ajaxVideoComments(){
        //获取视频评论
        let minid = this.messages.length > 0 ? (this.messages[this.messages.length - 1].ID) : 0;
        AjaxPlugin.$http.get('/Mobile/API/GetVideoComments/' + this.$route.params.id, {MinID : minid}).then((res)=>{

          for(var i = 0, len = res.data.length; i < len; i++){
            this.messages.push(res.data[i]);
          }

          //重新排版
          setTimeout(() =>{
            if(this.$refs && this.$refs.my_scroller){
              this.$refs.my_scroller.resize();

              //判断没有更多数据了
              if(res.data.length < 20){
                this.$refs.my_scroller.showLoading = false;
                this.$refs.my_scroller.loadingState = 2;
              } else {
                this.$refs.my_scroller.loadingState = 0;
              }
            }
          })
        })
      },
      sendMessageBack(item){
        //发送评论回调
        this.messages.unshift(item);
      }
    }
  }
</script>

<style>
  .page-video-comment{ position:relative; min-height:100%; }
  /*.page-video-comment:before{ height:46px; display:block; content:""; }*/
  .page-video-message{ display:flex; margin-top:10px; }
  .page-video-message-avatar{ width:54px; text-align:center; }
  .page-video-message-avatar img{ width:30px; height:30px; border-radius:50%; }
  .page-video-message-box{ flex:1; padding:0px 12px; font-size:12px; color:#757575; }
  .page-video-message-name{ color:#0066CC; }
  .page-video-message-date{ float:right; }
  .page-user-message{ margin:0; padding:10px 0; box-sizing:border-box;
    background:-webkit-linear-gradient(top, #e5e5e5, #e5e5e5, rgba(229, 229, 229, 0)) bottom left no-repeat;
    background:linear-gradient(180deg, #e5e5e5, #e5e5e5, rgba(229, 229, 229, 0)) bottom left no-repeat;
    background-size:100% 1px; }
  /*._v-container > ._v-content > .loading-layer[data-v-7e6ccbb8]{ height:auto; }*/
</style>
