import Vue from 'vue'
import Router from 'vue-router'

import videolist from '../pages/video/list.vue'
import videoInfo from '../pages/video/info.vue'


Vue.use(Router)

export default new Router({
  routes : [
    {path : '/video/list', component : videolist},
    {path : '/video/info/:id', component : videoInfo},
    {path : '/', component : videolist}
  ]
})
