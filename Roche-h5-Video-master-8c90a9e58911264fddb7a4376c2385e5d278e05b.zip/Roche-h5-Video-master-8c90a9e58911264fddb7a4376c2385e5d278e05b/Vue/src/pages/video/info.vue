<template>
  <div class="page js_show">
    <div class="page-video-play">
      <video-player :options="videoOptions" @player-state-changed="playerStateChanged"></video-player>
    </div>
    <div class="page-video-header">
      <tab class="page-video-tab" :line-width=2 active-color='#0066CC' v-model="current">
        <tab-item class="vux-center" v-for="(item, index) in list" :selected="current === index" @click="current = index" :key="index">{{item}}</tab-item>
      </tab>
      <div class="vux-tab page-video-custom-tab">
        <div class="vux-tab-item">
          <span class="page-video-likes" :class="{active:userLike}" @click="ajaxVideoLike()">{{likeNumber}}</span>
        </div>
      </div>
    </div>
    <div class="page-video-content">
      <swiper v-model="current" height="100%" :show-dots="false" :threshold="9999" :min-moving-distance="9999">
        <swiper-item :key="0">
          <div class="page-video-desc" v-html="html"></div>
        </swiper-item>
        <swiper-item :key="1">
          <div class="page-video-image">
            <img :src="currentPPT"/>
          </div>
        </swiper-item>
        <swiper-item :key="2">
          <message-list></message-list>
        </swiper-item>
      </swiper>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">

  import {AjaxPlugin, Tab, TabItem, Swiper, SwiperItem, Toast} from 'vux'
  import {videoPlayer} from 'vue-video-player'
  import Scroller from 'vue-scroller'

  import messageList from '../../components/message/list.vue'

  export default {
    components : {
      AjaxPlugin,
      Tab,
      TabItem,
      Swiper,
      SwiperItem,
      Toast,
      videoPlayer,
      Scroller,
      messageList
    },
    data () {
      return {
        userLike : null,
        likeNumber : null,
        html : null,
        list : ['介绍', '资料', '评论'],
        current : 0,
        timeline : [],
        currentPPT : null,
        videoOptions : {
          playsinline : true,
          autoplay : false,
          height : "260px",
          poster : null,
          source : {},
          language : 'zh-CN',
          defaultSrcReId : 2
        },
        messages : []
      }
    },
    methods : {
      playerStateChanged(playerCurrentState) {

        if(playerCurrentState.play){
          //开始播放
        } else if(playerCurrentState.currentTime == 0){

        }
        else if(playerCurrentState.currentTime){
          //判断数据源
          if(!this.timeline || !this.timeline.length){
            return false;
          }
          //播放时间点
          for(var i = 0; i < this.timeline.length; i++){
            if(playerCurrentState.currentTime >= this.timeline[i].time && ((i + 1) == this.timeline.length || playerCurrentState.currentTime < this.timeline[i + 1].time)){
              this.currentPPT = this.timeline[i].file;
              break;
            }
          }
        }
        else if(playerCurrentState.ended){
          //播放结束
        }
      },
      ajaxVideoInfo(){
        //获取视频详情信息
        AjaxPlugin.$http.get('/Mobile/API/GetVideoInfo/' + this.$route.params.id).then((res)=>{
          this.userLike = res.data.UserLike;
          this.likeNumber = res.data.LikeNumber || 0;
          this.html = res.data.Content;
          this.videoOptions.poster = res.data.Cover;
          this.ajaxVideoConfig(res.data.DataConfigFIle);
        })
      },
      ajaxVideoConfig (url){
        //获取视频静态配置数据
        AjaxPlugin.$http.get(url).then((res)=>{
          this.timeline = res.data.timeline;
          this.videoOptions.source = res.data.source;
          this.currentPPT = (!this.timeline || !this.timeline.length) ? null : this.timeline[0].file;
        });
      },
      ajaxVideoPlay(){
        //添加播放次数
        AjaxPlugin.$http.post('/Mobile/API/PlayVideo/' + this.$route.params.id).then((res)=>{

        });
      },
      ajaxVideoLike(){
        if(this.userLike){
          return false;
        }
        //给视频点赞
        AjaxPlugin.$http.post('/Mobile/API/LikeVideo/' + this.$route.params.id).then((res)=>{
          if(res.data.result){
            this.userLike = true;
            this.likeNumber++;
            this.$vux.toast.show({
              text : '点赞成功',
              type : 'success',
              time : 500
            })
          } else if(res.data.errmsg){
            this.$vux.toast.show({
              text : res.data.errmsg,
              type : 'warn',
              time : 500
            })
          }
        });
      }
    },
    created(){
      this.ajaxVideoInfo();
    }
  }
</script>
<style>
  .page-video-play{ width:100%; height:260px; position:fixed; overflow:hidden; z-index:99; }
  .page-video-play video{ height:260px; }
  .page-video-header{ width:100%; height:44px; position:fixed; top:260px; display:flex; overflow:hidden; z-index:99; }
  .page-video-tab{ width:180px; }
  .page-video-custom-tab{ flex:1; line-height:44px; }
  .page-video-custom-tab .vux-tab-item{ padding:0px 12px; }
  .page-video-likes{ float:right; position:relative; }
  .page-video-likes:after{ width:20px; height:20px; position:absolute; left:-22px; top:12px; content:''; background:url(../../assets/votethumbsup_v.png) no-repeat; background-size:100%; }
  .page-video-likes.active:after{ background:url(../../assets/votethumbsup.png) no-repeat; background-size:100%; }
  .page-video-source{ width:20px; height:20px; float:right; position:relative; margin-left:15px; }
  .page-video-source:after{ width:18px; height:18px; position:absolute; left:0px; top:12px; content:''; background:url(../../assets/slideshare.png) no-repeat; background-size:100%; }
  .page-video-content{ position:fixed; top:304px; bottom:0%; left:0%; right:0%; }
  .page-video-content .vux-slider{ height:100%; }
  .page-video-desc{ padding:10px; }
  .page-video-image{ width:100%; height:100%; position:relative; overflow:hidden; }
  .page-video-image img{ max-width:98%; max-height:98%; position:absolute; top:50%; left:50%; transform:translate(-50%, -50%); box-shadow:0px 0px 15px #c1bfbf; }
</style>
