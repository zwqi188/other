<template>
  <div class="page js_show">
    <scroller :on-infinite="ajaxVideoList" ref="my_scroller">
      <div v-for="(item, index) in list">
        <router-link :to="{ path: '/video/info/'+item.ID}" class="page-video-list">
          <div class="page-video-list-image">
            <img class="page-video-list-cover" :src="item.Cover"/>
            <div class="page-video-list-mask"></div>
            <div class="page-video-list-title" v-html="item.Title"></div>
          </div>
          <div class="page-video-list-header">
            <img class="page-video-list-avatar" :src="item.Avatar">
            <span class="page-video-list-author">{{item.Author}}</span>
            <span class="page-video-list-messages">{{item.CommentNumber||0}}</span>
            <span class="page-video-list-play">{{item.PlayNumber||0}}次播放</span>
          </div>
        </router-link>
      </div>
    </scroller>
  </div>
</template>
<script type="text/ecmascript-6">
  import {AjaxPlugin} from 'vux'
  import Scroller from 'vue-scroller'
  export default  {
    //引用组件
    components : {AjaxPlugin, Scroller},
    //定义方法
    methods : {},
    //定义变量
    data () {
      return {
        list : []
      }
    },
    methods : {
      ajaxVideoList(){
        //获取视频列表
        let minid = this.list.length > 0 ? (this.list[this.list.length - 1].ID) : 0;
        AjaxPlugin.$http.get('/Mobile/API/GetVideoList', {MinID : minid}).then((res)=>{
          for(var i = 0, len = res.data.length; i < len; i++){
            this.list.push(res.data[i]);
          }

          //重新排版
          setTimeout(() =>{
            if(this.$refs && this.$refs.my_scroller){
              this.$refs.my_scroller.resize();

              //判断没有更多数据了
              if(res.data.length < 20){
                this.$refs.my_scroller.showLoading = false;
                this.$refs.my_scroller.loadingState = 2;
              } else {
                this.$refs.my_scroller.loadingState = 0;
              }
            }
          })

        })
      }
    }
  }
</script>
<style>
  .page{ position:absolute; top:0; right:0; bottom:0; left:0; background-color:#f8f8f8; }
  .page-video-list{ position:relative; display:block; background-color:#ffffff; text-decoration:none; }
  .page-video-list-image{ width:100%; height:200px; position:relative; text-align:center; overflow:hidden; }
  .page-video-list-cover{ max-width:150%; max-height:150%; min-width:100%; min-height:100%; position:absolute; top:50%; left:50%; transform:translate(-50%, -50%); }
  .page-video-list-mask{ width:100%; height:100%; position:absolute; left:0%; top:0%; background-color:rgba(0, 0, 0, 0.4); z-index:9; }
  .page-video-list-title{ width:100%; position:absolute; top:50%; left:50%; transform:translate(-50%, -50%); z-index:10; text-align:center; color:#ffffff; font-size:18px; font-weight:500; }
  .page-video-list-header{ padding:0 12px; height:50px; position:relative; font-size:12px; color:#353535; line-height:50px; }
  .page-video-list-avatar{ margin-right:10px; width:30px; height:30px; border-radius:50%; vertical-align:middle; }
  .page-video-list-messages{ position:relative; float:right; margin-left:35px; }
  .page-video-list-messages:after{ width:16px; height:16px; position:absolute; left:-18px; top:16px; content:""; background:url(../../assets/comment3.1.png) no-repeat; background-size:100%; }
  .page-video-list-play{ float:right; }
</style>
