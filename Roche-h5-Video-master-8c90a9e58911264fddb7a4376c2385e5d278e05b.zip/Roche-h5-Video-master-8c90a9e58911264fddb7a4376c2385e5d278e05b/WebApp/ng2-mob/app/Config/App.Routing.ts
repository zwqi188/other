/**
 * Created by QingLiang.TAN on 2016/8/30.
 */
import {ModuleWithProviders}  from '@angular/core';
import {Routes, RouterModule} from '@angular/router';


//自定义页面
import {HomeIndex} from  '../Home/Index';


//路由
const appRoutes:Routes = [
    //默认
    {path: '', redirectTo: 'Home', pathMatch: 'full'},
    
    {path: 'Home', component: HomeIndex}
];

export const RoutingModule:ModuleWithProviders = RouterModule.forRoot(appRoutes);