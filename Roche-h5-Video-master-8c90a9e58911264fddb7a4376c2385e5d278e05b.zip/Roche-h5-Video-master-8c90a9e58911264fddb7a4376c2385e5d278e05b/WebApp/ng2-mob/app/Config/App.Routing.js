"use strict";
var router_1 = require('@angular/router');
//自定义页面
var Index_1 = require('../Home/Index');
//路由
var appRoutes = [
    //默认
    { path: '', redirectTo: 'Home', pathMatch: 'full' },
    { path: 'Home', component: Index_1.HomeIndex }
];
exports.RoutingModule = router_1.RouterModule.forRoot(appRoutes);
//# sourceMappingURL=App.Routing.js.map