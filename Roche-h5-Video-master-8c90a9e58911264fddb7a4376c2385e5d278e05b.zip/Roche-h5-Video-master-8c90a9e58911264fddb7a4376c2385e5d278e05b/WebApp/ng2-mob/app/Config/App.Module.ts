import {NgModule, ChangeDetectorRef}       from '@angular/core';
import {BrowserModule}  from '@angular/platform-browser';
import {FormsModule}    from '@angular/forms';
import {HttpModule}    from '@angular/http';

//程序根入口
import {AppComponent}  from './App.Component';


//自定义服务
import {HttpServices}   from '../Common/HttpServices';

//自定义路由
import {RoutingModule} from './App.Routing';

//自定义页面
import {HomeIndex} from  '../Home/Index';


@NgModule({
    imports: [
        BrowserModule,
        FormsModule,
        HttpModule,
        RoutingModule,
    ],
    declarations: [
        AppComponent,
        HomeIndex,
    ],
    providers: [
        ChangeDetectorRef,
        HttpServices,

    ],
    bootstrap: [AppComponent]
})
export class AppModule {
}


/*
 Copyright 2016 Google Inc. All Rights Reserved.
 Use of this source code is governed by an MIT-style license that
 can be found in the LICENSE file at http://angular.io/license
 */