/**
 * Created by QingLiang.TAN on 2016/8/30.
 */
import {Component} from '@angular/core';

@Component({
    selector: 'my-app',
    template: `
        <router-outlet></router-outlet>
    `,
})
export class AppComponent {

    constructor() {
        console.log('new myApp')
    }

}

