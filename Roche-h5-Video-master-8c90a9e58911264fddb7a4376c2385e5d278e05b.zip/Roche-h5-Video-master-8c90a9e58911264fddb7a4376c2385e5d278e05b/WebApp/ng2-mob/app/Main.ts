/**
 * Created by QingLiang.TAN on 2016/8/30.
 */
// 预加载ng2
import 'core-js';
import 'reflect-metadata';
import 'zone.js/dist/zone';

import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';
import {AppModule} from './Config/App.Module';

//外部插件
import '../js/public.js';




platformBrowserDynamic().bootstrapModule(AppModule);
