/**
 * Created by QingLiang.TAN on 2016/10/19.
 */
import {Component, ChangeDetectorRef} from '@angular/core';
import {ActivatedRoute} from '@angular/router';

// 自定义服务
import {HttpServices} from  '../Common/HttpServices';

//管理员分组列表
@Component({
    selector: 'List',
    templateUrl: '../ng2-mob/app/Home/Index.html?v=' + window.versions,
})
export class HomeIndex {

    private model:any = {
        list: [
            '温州现715斤巨型金枪鱼 最贵一块肉3800元一两(图)',
            '郑州拆迁户致3死1伤被击毙案续：伤者索赔200万',
            '云南初三女生放学途中死亡陈尸山林 事发当天生日(图)',
            '过期食品倒路边 市民争相捡吃其余重回市场',
            '《在人间》第94期：北京地铁十年']
    };

    constructor(private http:HttpServices, private route:ActivatedRoute, private ref:ChangeDetectorRef) {

        //获取详情数据
        // this.ref.detectChanges();
        // this.http.post('/Admin/Articles/Info', this.route.params.value).then(body => {
        //     this.model = body.json();
        //     this.model.ReleaseTime = (this.model.ReleaseTime && this.model.ReleaseTime.toDateFormat('yyyy-MM-dd'));
        // });
    }

}


