"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by QingLiang.TAN on 2016/10/19.
 */
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
// 自定义服务
var HttpServices_1 = require('../Common/HttpServices');
//管理员分组列表
var HomeIndex = (function () {
    function HomeIndex(http, route, ref) {
        this.http = http;
        this.route = route;
        this.ref = ref;
        this.model = {
            list: [
                '温州现715斤巨型金枪鱼 最贵一块肉3800元一两(图)',
                '郑州拆迁户致3死1伤被击毙案续：伤者索赔200万',
                '云南初三女生放学途中死亡陈尸山林 事发当天生日(图)',
                '过期食品倒路边 市民争相捡吃其余重回市场',
                '《在人间》第94期：北京地铁十年']
        };
        //获取详情数据
        // this.ref.detectChanges();
        // this.http.post('/Admin/Articles/Info', this.route.params.value).then(body => {
        //     this.model = body.json();
        //     this.model.ReleaseTime = (this.model.ReleaseTime && this.model.ReleaseTime.toDateFormat('yyyy-MM-dd'));
        // });
    }
    HomeIndex = __decorate([
        core_1.Component({
            selector: 'List',
            templateUrl: '../ng2-mob/app/Home/Index.html?v=' + window.versions,
        }), 
        __metadata('design:paramtypes', [HttpServices_1.HttpServices, router_1.ActivatedRoute, core_1.ChangeDetectorRef])
    ], HomeIndex);
    return HomeIndex;
}());
exports.HomeIndex = HomeIndex;
//# sourceMappingURL=Index.js.map