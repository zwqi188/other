/**
 * Created by QingLiang.TAN on 2016/8/26.
 */

//.net JSON数据返回的时间字符串转换（格式化）
String.prototype.toDateFormat = function(fmt){
    if(!this){
        return '';
    }
    var date = eval('new ' + this.replace("/", "").replace("/", ""));

    return date.toFormat(fmt);
}

//日期转字符串（格式化）
Date.prototype.toFormat = function(fmt){

    if(!this){
        return '';
    }
    var o = {
        "M+" : this.getMonth() + 1, //月份
        "d+" : this.getDate(), //日
        "h+" : this.getHours(), //小时
        "m+" : this.getMinutes(), //分
        "s+" : this.getSeconds(), //秒
        "q+" : Math.floor((this.getMonth() + 3) / 3), //季度
        "S" : this.getMilliseconds() //毫秒
    };

    if(/(y+)/.test(fmt)){
        fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    }

    for(var k in o){
        if(new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    }
    return fmt;
}

window.public.setCookie = function(name, value, days) {
    var Days = days ? days : 365;
    var exp = new Date();
    exp.setTime(exp.getTime() + Days * 24 * 60 * 60 * 1000);
    document.cookie = name + "=" + escape(value) + ";expires=" + exp.toGMTString() + ";path=/";
};

window.public.getCookie = function (name) {
    var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
    if (arr = document.cookie.match(reg)) return unescape(arr[2]);
    else return null;
};

window.public.delCookie = function (name) {
    var exp = new Date();
    exp.setTime(exp.getTime() - 1);
    var cval = window.public.getCookie(name);
    if (cval!=null) document.cookie= name + "="+cval+";expires="+exp.toGMTString() + ";path=/";
};