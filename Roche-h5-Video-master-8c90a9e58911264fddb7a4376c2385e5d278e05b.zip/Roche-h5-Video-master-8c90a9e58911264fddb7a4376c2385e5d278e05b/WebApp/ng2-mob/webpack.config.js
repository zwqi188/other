/**
 * Created by QingLiang.TAN on 2016/12/23.
 */
var webpack = require('webpack');
var HtmlWebpackPlugin = require('html-webpack-plugin');
module.exports = {
    entry : './ng2-mob/app/main.js',
    output : {
        path : './ng2-mob/dist',
        filename : 'app.bundle.js'
    },
    module : {
        loaders : [
            {test : /\.component.ts$/, loader : 'ts!angular2-template'},
            {test : /\.ts$/, exclude : /\.component.ts$/, loader : 'ts'},
            {test : /\.html$/, loader : 'raw'},
            {test : /\.css$/, loader : 'raw'}
        ]
    },
    resolve : {
        extensions : ['', '.js', '.ts']
    },
    plugins : [
        new webpack.optimize.UglifyJsPlugin({
            compressor : {
                warnings : false
            }
        }),
        new HtmlWebpackPlugin({
            template : './ng2-mob/index.html'
        })
    ]
};
