﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApp.Areas.Admin.Controllers
{
    public class PublicController : Controller
    {
        ///<summary>
        /// 生成随机验证码
        /// </summary>
        public void verifyCode()
        {
            Common.VerifyCode.Get();
        }

        /// <summary>
        /// 登陆系统
        /// </summary>
        /// <param name="uname"></param>
        /// <param name="upwd"></param>
        /// <param name="code"></param>
        /// <returns></returns>
        public ActionResult Login(string uname, string upwd, string code)
        {
            if (Session["verifyCode"] == null)
            {
                return "验证码已过期".ToJsonResult();
            }

            if (code != Session["verifyCode"].ToString())
            {
                return "验证错误，请重新输入".ToJsonResult();
            }

            if (new Libs.Account().LogOn(uname, upwd))
            {
                return true.ToJsonResult();
            }
            else
            {
                return "用户名或密码错误，请重新输入".ToJsonResult();
            }
        }

        /// <summary>
        /// 退出登陆
        /// </summary>
        /// <returns></returns>
        public ActionResult LogOut()
        {
            new Libs.Account().LogOut();
            return Redirect("~/adm");
        }

        /// <summary>
        /// 获取密码
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        public ActionResult Forget(string email)
        {
            return false.ToJsonResult();
        }

    }
}
