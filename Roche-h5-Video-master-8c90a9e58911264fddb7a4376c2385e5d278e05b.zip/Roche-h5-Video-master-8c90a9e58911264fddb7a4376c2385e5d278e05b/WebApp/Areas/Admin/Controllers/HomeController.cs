﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApp.Areas.Admin.Controllers
{
    public class HomeController : Controller
    {

        /// <summary>
        /// 后台页面入口、视图
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public ActionResult Index(string url = "")
        {
            if (Libs.Account.IsLogOn || url.ToLower() == "login")
            {
                return View("~/Views/Adm.cshtml");
            }
            else
            {
                return Redirect("~/adm/Login");
            }
        }




    }
}
