﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApp.Areas.Admin.Controllers
{
    public class AdmAccountController : Libs.BaseController
    {

        /// <summary>
        /// 获取分页数据
        /// </summary>
        /// <param name="w"></param>
        /// <param name="pageIndex">分页下标（默认1）</param>
        /// <param name="pageSize">分页显示数（默认50）</param>
        /// <param name="orderKey">排序字段</param>
        /// <param name="orderDes">排序方式</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult List(Models.ViewAdmAccountList w, int? pageIndex, int? pageSize, string orderKey, int? orderDes)
        {
            var list = new EntityService().GetPagedObjects(w, pageIndex ?? 1, pageSize ?? DefaultPageCount, string.Empty, base.ListOrderBy(orderKey, orderDes));

            return list.ToJsonResult();
        }

        /// <summary>
        /// 导出数据
        /// </summary>
        /// <param name="w"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Export(Models.ViewAdmAccountList w)
        {
            var dt = new EntityService().GetDataTables(new string[3] { "ID as #", "UserName as 帐户名", "GroupName as 分组" }, w);

            var filepath = "/upload/excel/" + Guid.NewGuid().ToString("N") + ".xls";
            dt.ExportExcel(Server.MapPath("~") + filepath);

            return new Dictionary<string, string>() { { "result", filepath } }.ToJsonResult();

        }

        /// <summary>
        /// 获取数据详细
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Info(int id)
        {
            var result = new EntityService().GetObject<Models.AdmAccount>(id);

            return result.ToJsonResult();
        }

        /// <summary>
        /// 创建数据
        /// </summary>
        /// <param name="t"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Create(Models.AdmAccount t, string NewPwd)
        {
            t.CreateDate = DateTime.Now;
            t.CreateUserID = base.AccountID;
            t.IsDeleted = false;

            if (!NewPwd.IsNullOrBlank())
            {
                t.UserPwd = NewPwd.HashMD5Password();
            }

            var result = new EntityService().Create(t);

            return result.ToJsonResult();
        }

        /// <summary>
        /// 更新数据
        /// </summary>
        /// <param name="t"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Update(Models.AdmAccount t, string NewPwd)
        {
            t.LastUpdateDate = DateTime.Now;
            t.LastUpdateUserID = base.AccountID;

            if (!NewPwd.IsNullOrBlank())
            {
                t.UserPwd = NewPwd.HashMD5Password();
            }

            var result = new EntityService().Update(t);

            return result.ToJsonResult();
        }

        /// <summary>
        /// 删除数据
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Delete(List<int> ids)
        {
            var result = new EntityService().Deletes<Models.AdmAccount>(ids);

            return result.ToJsonResult();
        }

    }
}
