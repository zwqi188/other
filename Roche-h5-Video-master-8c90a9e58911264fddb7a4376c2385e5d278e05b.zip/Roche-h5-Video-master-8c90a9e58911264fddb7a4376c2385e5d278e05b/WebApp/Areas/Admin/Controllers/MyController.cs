﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApp.Areas.Admin.Controllers
{
    public class MyController : Libs.BaseController
    {

        /// <summary>
        /// 获取个人信息
        /// </summary>
        /// <returns></returns>
        public JsonResult GetMyInfo()
        {
            return new EntityService().GetObject<Models.AdmAccount>(base.AccountID).ToJsonResult();
        }

        /// <summary>
        /// 更新个人信息
        /// </summary>
        /// <param name="t"></param>
        /// <returns></returns>
        public JsonResult UpdateMyInfo(string UserName, string RealName, string Mobile, string Email, string Avatar)
        {
            var t = new Models.AdmAccount()
            {
                ID = base.AccountID,
                UserName = UserName,
                RealName = RealName,
                Mobile = Mobile,
                Email = Email,
                Avatar = Avatar,
                LastUpdateDate = DateTime.Now,
            };
            return new EntityService().Update(t).ToJsonResult();
        }

        /// <summary>
        /// 更新登陆密码
        /// </summary>
        /// <param name="oldpwd"></param>
        /// <param name="newpwd"></param>
        /// <returns></returns>
        public JsonResult UpdatePassWord(string OldPwd, string NewPwd)
        {
            var t = new EntityService().GetObject<Models.AdmAccount>(base.AccountID);

            if (t.UserPwd != OldPwd.HashMD5Password())
            {
                return "旧密码不正确".ToJsonResult();
            }

            return new EntityService().Update(new Models.AdmAccount() { ID = base.AccountID, UserPwd = NewPwd.HashMD5Password(), LastUpdateDate = DateTime.Now }).ToJsonResult();
        }

        /// <summary>
        /// 获取我的前端权限路由
        /// </summary>
        /// <returns></returns>
        public JsonResult GetMyAccess()
        {
            var res = Libs.Account.GetAccess();

            return res.ToJsonResult();
        }
    }
}
