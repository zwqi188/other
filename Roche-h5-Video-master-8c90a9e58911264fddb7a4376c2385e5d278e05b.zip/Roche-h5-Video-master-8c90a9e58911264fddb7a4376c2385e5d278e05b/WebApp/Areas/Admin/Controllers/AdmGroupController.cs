﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApp.Areas.Admin.Controllers
{
    public class AdmGroupController : Libs.BaseController
    {

        /// <summary>
        /// 获取分页数据
        /// </summary>
        /// <param name="w"></param>
        /// <param name="pageIndex">分页下标（默认1）</param>
        /// <param name="pageSize">分页显示数（默认50）</param>
        /// <param name="orderKey">排序字段</param>
        /// <param name="orderDes">排序方式</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult List(Models.AdmGroup w, int? pageIndex, int? pageSize, string orderKey, int? orderDes)
        {
            var list = new EntityService().GetPagedObjects(w, pageIndex ?? 1, pageSize ?? DefaultPageCount, string.Empty, base.ListOrderBy(orderKey, orderDes));

            return list.ToJsonResult();
        }

        /// <summary>
        /// 导出数据
        /// </summary>
        /// <param name="w"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Export(Models.AdmGroup w)
        {
            var dt = new EntityService().GetDataTables(new string[3] { "ID as #", "GroupName as 分组名", "GroupDesc as 	分组备注" }, w);

            var filepath = "/upload/excel/" + Guid.NewGuid().ToString("N") + ".xls";
            dt.ExportExcel(Server.MapPath("~") + filepath);

            return new Dictionary<string, string>() { { "result", filepath } }.ToJsonResult();

        }

        /// <summary>
        /// 获取数据详细
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Info(int id)
        {
            var result = new EntityService().GetObject<Models.AdmGroup>(id);

            return result.ToJsonResult();
        }

        /// <summary>
        /// 创建数据
        /// </summary>
        /// <param name="t"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Create(Models.AdmGroup t, List<int> ids)
        {
            t.CreateDate = DateTime.Now;
            t.CreateUserID = base.AccountID;
            t.IsDeleted = false;

            t.MenuIDs = string.Join(",", ids);

            var result = new EntityService().Create(t);

            return result.ToJsonResult();
        }

        /// <summary>
        /// 更新数据
        /// </summary>
        /// <param name="t"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Update(Models.AdmGroup t, List<int> ids)
        {
            t.LastUpdateDate = DateTime.Now;
            t.LastUpdateUserID = base.AccountID;

            if (t.ID != 1) // 超级管理员组 不能被修改
            {
                t.MenuIDs = string.Join(",", ids);
            }

            var result = new EntityService().Update(t);

            return result.ToJsonResult();
        }

        /// <summary>
        /// 删除数据
        /// </summary>
        /// <param name="ids"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Delete(List<int> ids)
        {
            var result = new EntityService().Deletes<Models.AdmGroup>(ids);

            return result.ToJsonResult();
        }

        /// <summary>
        /// 获取select控件可选择数据
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Select()
        {
            var result = new List<Respone.JsonSelect>();

            var list = new EntityService().GetObjects<Models.AdmGroup>();
            foreach (var item in list)
            {
                result.Add(new Respone.JsonSelect()
                {
                    value = item.ID,
                    text = item.GroupName,
                });
            }

            return result.ToJsonResult();
        }

        /// <summary>
        /// 获取权限菜单数据
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public JsonResult GetAdmMenuSelect()
        {
            var result = new Dictionary<string, string>();

            var list = new EntityService().GetObjects<Models.AdmMenu>();
            foreach (var item in list)
            {
                result.Add(item.ID.ToString(), item.MenuName);
            }

            return result.ToJsonResult();
        }
    }
}


