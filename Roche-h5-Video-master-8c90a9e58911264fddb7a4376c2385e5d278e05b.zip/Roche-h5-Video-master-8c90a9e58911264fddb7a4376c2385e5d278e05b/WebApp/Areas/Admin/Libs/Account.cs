﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApp.Areas.Admin.Libs
{
    public class Account
    {

        /// <summary>
        /// （cookie&session）Key值 
        /// </summary>
        private const string Prefix = "Current-Account-";
        private const string Encry = "eDoctorEncry";

        /// <summary>
        /// 登录用户ID
        /// </summary>
        public static int AccountID
        {
            get
            {
                try
                {
                    if (System.Web.HttpContext.Current.Request.Cookies[Prefix + "ID"] != null && !string.IsNullOrEmpty(System.Web.HttpContext.Current.Request.Cookies[Prefix + "ID"].Value))
                    {
                        return int.Parse(System.Web.HttpContext.Current.Request.Cookies[Prefix + "ID"].Value.DecodeDes(Encry, Encry));
                    }
                    else
                    {
                        return 0;
                    }
                }
                catch
                {
                    return 0;
                }
            }
        }

        /// <summary>
        /// 获取帐户详细信息
        /// </summary>
        public static Models.AdmAccount AccountInfo
        {
            get
            {
                try
                {
                    if (System.Web.HttpContext.Current.Session[Prefix + "Info"] == null && AccountID > 0)
                    {
                        System.Web.HttpContext.Current.Session[Prefix + "Info"] = new EntityService().GetObject<Models.AdmAccount>(AccountID);
                    }

                    if (System.Web.HttpContext.Current.Session[Prefix + "Info"] != null)
                    {
                        return System.Web.HttpContext.Current.Session[Prefix + "Info"] as Models.AdmAccount;
                    }
                    else
                    {
                        return null;
                    }
                }
                catch
                {
                    return null;
                }
            }
        }

        /// <summary>
        /// 判断是否已经登陆
        /// </summary>
        public static bool IsLogOn
        {
            get
            {
                if (AccountID < 1)
                {
                    return false;
                }
                if (System.Web.HttpContext.Current.Request.Cookies[Prefix + "encry"] != null)
                {
                    return (Prefix + Encry + AccountID.ToString()).HashMD5Password() == System.Web.HttpContext.Current.Request.Cookies[Prefix + "encry"].Value;
                }
                else
                {
                    return false;
                }
            }
        }

        /// <summary>
        /// 判断用户对菜单权限
        /// </summary>
        /// <param name="menuid"></param>
        /// <returns></returns>
        public static bool IsAccess(int menuid)
        {

            //获取用户信息
            if (AccountInfo == null)
            {
                return false;
            }

            //获取用户分组
            var Group = new EntityService().GetObject<Models.AdmGroup>(AccountInfo.GroupID);
            if (Group == null || Group.MenuIDs.IsNullOrBlank())
            {
                return false;
            }

            //判断是否最高权限
            if (Group.MenuIDs == "all")
            {
                return true;
            }

            //判断分组权限
            return Group.MenuIDs.Split(',').Contains(menuid.ToString());
        }

        /// <summary>
        /// 获取当前用户权限
        /// </summary>
        /// <returns></returns>
        public static List<string> GetAccess()
        {
            //返回数据
            var res = new List<string>();

            //获取用户信息
            if (AccountInfo == null)
            {
                return res;
            }

            //获取用户分组
            var Group = new EntityService().GetObject<Models.AdmGroup>(AccountInfo.GroupID);
            if (Group == null || Group.MenuIDs.IsNullOrBlank())
            {
                return res;
            }

            //获取分组权限
            var Menus = new EntityService().GetObjects<Models.AdmMenu>(new Models.AdmMenu() { IsDeleted = false }, Group.MenuIDs == "all" ? "" : " and ID in(" + Group.MenuIDs + ")");
            foreach (var item in Menus)
            {
                res.Add(item.RouteName);
            }

            return res;
        }

        /// <summary>
        /// 登录
        /// </summary>
        public bool LogOn(string uname, string upwd)
        {
            //获取帐户信息
            var u = new EntityService().GetObject(new Models.AdmAccount() { UserName = uname, UserPwd = upwd.HashMD5Password() });
            if (u == null)
            {
                return false;
            }

            //保存Cookie---accountid
            System.Web.HttpCookie cookie = new System.Web.HttpCookie(Prefix + "ID");
            cookie.Value = u.ID.ToString().EncryDes(Encry, Encry);
            cookie.Expires = DateTime.Now.AddDays(7);
            System.Web.HttpContext.Current.Response.AppendCookie(cookie);

            //保存Cookie---encryption
            System.Web.HttpCookie cookieencry = new System.Web.HttpCookie(Prefix + "encry");
            cookieencry.Value = (Prefix + Encry + u.ID.ToString()).HashMD5Password();
            cookieencry.Expires = DateTime.Now.AddDays(7);
            System.Web.HttpContext.Current.Response.AppendCookie(cookieencry);

            //保存session---account
            System.Web.HttpContext.Current.Session[Prefix + "Info"] = u;
            return true;
        }

        /// <summary>
        /// 退出登陆
        /// </summary>
        public void LogOut()
        {

            //保存Cookie---accountid
            System.Web.HttpCookie cookie = new System.Web.HttpCookie(Prefix + "ID");
            cookie.Expires = DateTime.Now.AddDays(-7);
            System.Web.HttpContext.Current.Response.AppendCookie(cookie);

            //保存Cookie---encryption
            System.Web.HttpCookie cookieencry = new System.Web.HttpCookie(Prefix + "encry");
            cookieencry.Expires = DateTime.Now.AddDays(-7);
            System.Web.HttpContext.Current.Response.AppendCookie(cookieencry);

            //移除会话信息
            System.Web.HttpContext.Current.Session.Remove(Prefix + "Info");
            System.Web.HttpContext.Current.Session.Remove(Prefix + "group");
        }
    }
}