﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApp.Areas.Admin.Libs
{
    public class BaseController : Controller
    {
        /// <summary>
        /// 分页&默认显示数
        /// </summary>
        protected const int DefaultPageCount = 50;

        /// <summary>
        /// 帐户ID
        /// </summary>
        protected int AccountID { set; get; }

        /// <summary>
        /// 进行授权时调用
        /// </summary>
        /// <param name="filterContext"></param>
        protected override void OnAuthorization(AuthorizationContext filterContext)
        {
            //判断是否已经登陆
            if (!Account.IsLogOn)
            {
                filterContext.Result = "未登陆".ToJsonResult();
                return;
            }

            //当前登陆用户ID
            this.AccountID = Account.AccountID;

            //判断当前用户是否对此路由接口访问权限
            var menu = new EntityService().GetObject(new Models.AdmMenu() { RouteUrl = Request.CurrentExecutionFilePath });
            if (menu != null && !Libs.Account.IsAccess(menu.ID))
            {
                filterContext.Result = "权限不足".ToJsonResult();
                return;
            }
        }


        /// <summary>
        /// 接口异常时调用
        /// </summary>
        /// <param name="filterContext"></param>
        protected override void OnException(ExceptionContext filterContext)
        {
            //filterContext.Result = ("异常:" + filterContext.Exception.Message).ToJsonResult();
            filterContext.ExceptionHandled = true;
            filterContext.Result = ("异常错误").ToJsonResult();
        }


        /// <summary>
        /// 查询列表排序
        /// </summary>
        /// <param name="orderKey"></param>
        /// <param name="orderDes"></param>
        /// <returns></returns>
        protected virtual string ListOrderBy(string orderKey, int? orderDes)
        {
            if (orderKey.IsNullOrBlank())
            {
                return "ID Desc";
            }

            if (orderDes == 1)
            {
                return orderKey + " Desc";
            }
            else
            {
                return orderKey + " Asc";
            }
        }
    }
}