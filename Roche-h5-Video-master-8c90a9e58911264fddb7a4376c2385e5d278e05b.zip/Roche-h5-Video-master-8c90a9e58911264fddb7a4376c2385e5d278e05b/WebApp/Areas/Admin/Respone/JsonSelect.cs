﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApp.Areas.Admin.Respone
{
    public class JsonSelect
    {
        public object value { set; get; }

        public string text { set; get; }

        public List<JsonSelect> children { set; get; }
    }

    /// <summary>
    /// 权限菜单
    /// </summary>
    public partial class AdmMenu_Select
    {
        public int ID { get; set; }

        public string MenuName { get; set; }

    }
}