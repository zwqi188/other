﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApp.Areas.WeChat
{
    public class WeChatAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "WeChat";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {


            context.MapRoute(
                "WeChatDefault",
                "WeChat/{controller}/{action}",
                new { controller = "API", action = "Authorize", id = UrlParameter.Optional },
                new[] { "WebApp.Areas.WeChat.Controllers" }
            );
        }
    }
}