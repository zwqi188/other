﻿﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApp.Areas.WeChat.Controllers
{
    public class APIController : Controller
    {
        /// <summary>
        /// 获取code
        /// </summary>
        /// <returns></returns>
        public ActionResult Authorize(string state)
        {

            var req = new eDoctor.SDK.Http.HttpGet("https://open.weixin.qq.com/connect/oauth2/authorize");
            req.Params.Add(new eDoctor.SDK.Http.RequestParams() { Key = "appid", Value = Libs.Config.CorpID });
            req.Params.Add(new eDoctor.SDK.Http.RequestParams() { Key = "response_type", Value = "code" });
            req.Params.Add(new eDoctor.SDK.Http.RequestParams() { Key = "scope", Value = "snsapi_base" });
            req.Params.Add(new eDoctor.SDK.Http.RequestParams() { Key = "state", Value = state });
            req.Params.Add(new eDoctor.SDK.Http.RequestParams() { Key = "redirect_uri", Value = Common.UrlHelper.HostUrl + "/WeChat/API/GetUserInfo" });


            return Redirect(req.GetConstructedUri());
            //return View();
        }

        /// <summary>
        /// 根据code获取成员信息
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        public ActionResult GetUserInfo(string code, string state)
        {
            var res = new Libs.WeChat().GetUserId(code);
            if (res.IsNullOrBlank())
            {
                return Redirect("~/ng2-mob/error.html");
            }
            else
            {                
                return Redirect("~/mob");
            }
        }

        /// <summary>
        /// 下载微信图片文件
        /// </summary>
        /// <param name="fileToUpload"></param>
        /// <returns></returns>
        public JsonResult DownloadImages(string media_id)
        {
            if (string.IsNullOrEmpty(media_id))
            {
                return ("图片上传失败").ToJsonResult();
            }

            //获得保存路径
            string filename = Guid.NewGuid().ToString("N") + ".jpg";

            try
            {
                var url = "https://qyapi.weixin.qq.com/cgi-bin/media/get?access_token=" + Libs.Config.AccessToken + "&media_id=" + media_id;

                if (new Libs.WeChat().DownLoad(url, Server.MapPath("~/Upload/img/"), filename))
                {
                    return new Dictionary<string, string>() { { "result", "/upload/img/" + filename } }.ToJsonResult();
                }
                else
                {
                    return "上传失败，请重试...".ToJsonResult();
                }
            }
            catch (Exception)
            {
                return "上传失败，请重试...".ToJsonResult();
            }
        }

        /// <summary>
        /// 获取JS配置
        /// </summary>        
        /// <param name="url"></param>
        /// <param name="debug"></param>
        /// <returns></returns>
        public ActionResult JSConfig(string url, bool debug = false)
        {
            return Content(new Libs.WeChat().JSConfig(url, debug));
        }

        /// <summary>
        /// 微信端测试免授权入口
        /// </summary>
        /// <returns></returns>
        public ActionResult Test(string UserID)
        {
            new Libs.WeChat().Test(UserID);

            return Redirect("~/mob");
        }
    }
}
