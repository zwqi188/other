﻿﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApp.Areas.WeChat.Libs
{
    public class WeChat
    {

        /// <summary>
        /// （cookie&session）Key值 
        /// </summary>
        private const string Prefix = "Current-WeChat-";
        private const string Key = "71148e94a3cce2eb31f19161c787060a";

        /// <summary>
        /// 登录用户ID
        /// </summary>
        public static string UserID
        {
            get
            {
                if (System.Web.HttpContext.Current.Request.Cookies[Prefix + "UserID"] != null && !string.IsNullOrEmpty(System.Web.HttpContext.Current.Request.Cookies[Prefix + "UserID"].Value))
                {
                    return System.Web.HttpContext.Current.Request.Cookies[Prefix + "UserID"].Value.DecodeDes(Key,Key);
                }
                else
                {
                    return string.Empty;
                }

            }
        }        
        /// <summary>
        /// 判断是否已经登陆
        /// </summary>
        public static bool IsLogOn
        {
            get
            {
                if (UserID.IsNullOrBlank())
                {
                    return false;
                }
                if (System.Web.HttpContext.Current.Request.Cookies[Prefix + "encry"] != null)
                {
                    return (Prefix + Key + UserID).HashMD5Password() == System.Web.HttpContext.Current.Request.Cookies[Prefix + "encry"].Value;
                }
                else
                {
                    return false;
                }
            }
        }

        /// <summary>
        /// 根据code获取成员信息
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        public string GetUserId(string code)
        {
            var url = "https://qyapi.weixin.qq.com/cgi-bin/user/getuserinfo?access_token=" + Config.AccessToken + "&code=" + code;
            var req = new eDoctor.SDK.Http.HttpGet(url);

            var res = req.Request();

            var model = new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<Respone.WeChatUserId>(res);

            if (model.errcode == 0 && !model.UserId.IsNullOrBlank())
            {

                //获取用是否在存在数据库中
                var u = new EntityService().GetObject(new Models.WeChatUserInfo() { WeChatUserID = model.UserId });

                //判断是否已经存在数据库中
                if (u == null && !this.GetUserInfo(model.UserId))
                {
                    return null;
                }
                else
                {
                    //保存Cookie---UserID
                    System.Web.HttpCookie cookie = new System.Web.HttpCookie(Prefix + "UserID");
                    cookie.Value = model.UserId.EncryDes(Key, Key);
                    cookie.Expires = DateTime.Now.AddMonths(1);
                    System.Web.HttpContext.Current.Response.AppendCookie(cookie);

                    //保存Cookie---encryption
                    System.Web.HttpCookie cookieencry = new System.Web.HttpCookie(Prefix + "encry");
                    cookieencry.Value = (Prefix + Key + model.UserId).HashMD5Password();
                    cookieencry.Expires = DateTime.Now.AddMonths(1);
                    System.Web.HttpContext.Current.Response.AppendCookie(cookieencry);

                    return model.UserId;
                }
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// 获取成员信息
        /// </summary>
        /// <param name="userid"></param>
        private bool GetUserInfo(string userid)
        {
            //https://qyapi.weixin.qq.com/cgi-bin/user/get?access_token=ACCESS_TOKEN&userid=USERID
            var url = "https://qyapi.weixin.qq.com/cgi-bin/user/get?access_token=" + Config.AccessToken + "&userid=" + userid;
            var req = new eDoctor.SDK.Http.HttpGet(url);

            var res = req.Request();
            var model = new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<Respone.WeChatUserInfo>(res);

            if (model.errcode == 0)
            {
                return new EntityService().Create(new Models.WeChatUserInfo()
                {                    
                    IsDeleted = false,
                    CreateDate = DateTime.Now,

                    WeChatUserID = model.userid,
                    UserName = model.name,
                    Avatar = model.avatar,
                    Mobile = model.mobile,
                    Email = model.email,

                });
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 获取JS配置
        /// </summary>        
        /// <param name="url"></param>
        /// <param name="debug"></param>
        /// <returns></returns>
        public string JSConfig(string url, bool debug = false)
        {
            var temp = @"wx.config({
                            debug: [_debug_], // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
                            appId: '[_appId_]', // 必填，公众号的唯一标识
                            timestamp: [_timestamp_], // 必填，生成签名的时间戳
                            nonceStr: '[_nonceStr_]', // 必填，生成签名的随机串
                            signature: '[_signature_]',// 必填，签名，见附录1
                            jsApiList: [
                                'checkJsApi',
                                'onMenuShareTimeline',
                                'onMenuShareAppMessage',
                                'onMenuShareQQ',
                                'onMenuShareWeibo',
                                'hideMenuItems',
                                'showMenuItems',
                                'hideAllNonBaseMenuItem',
                                'showAllNonBaseMenuItem',
                                'translateVoice',
                                'startRecord',
                                'stopRecord',
                                'onRecordEnd',
                                'playVoice',
                                'pauseVoice',
                                'stopVoice',
                                'uploadVoice',
                                'downloadVoice',
                                'chooseImage',
                                'previewImage',
                                'uploadImage',
                                'downloadImage',
                                'getNetworkType',
                                'openLocation',
                                'getLocation',
                                'hideOptionMenu',
                                'showOptionMenu',
                                'closeWindow',
                                'scanQRCode',
                                'chooseWXPay',
                                'openProductSpecificView',
                                'addCard',
                                'chooseCard',
                                'openCard'
                            ] 
                        })";

            string noncestr, signature;
            long timestamp;
            signature = this.Signature(Config.Ticket, url, out noncestr, out timestamp);

            //替换模版中的参数
            temp = temp.Replace("[_debug_]", debug.ToString().ToLower())
                .Replace("[_appId_]", Config.CorpID)
                .Replace("[_timestamp_]", timestamp.ToString())
                .Replace("[_nonceStr_]", noncestr)
                .Replace("[_signature_]", signature);

            return temp;
        }

        /// <summary>
        /// 生成签名
        /// </summary>
        /// <param name="jsapi_ticket"></param>
        /// <param name="url"></param>
        /// <param name="noncestr"></param>
        /// <param name="timestamp"></param>
        /// <returns></returns>
        private string Signature(string jsapi_ticket, string url, out string noncestr, out long timestamp)
        {
            noncestr = Guid.NewGuid().ToString("n");
            timestamp = DateTimeToInt(DateTime.Now).Value;  //(long)DateTime.Now.TimeOfDay.TotalSeconds;
            string[] ArrTmp = { "jsapi_ticket=" + jsapi_ticket, "noncestr=" + noncestr, "timestamp=" + timestamp, "url=" + url };
            //Array.Sort(ArrTmp);
            string tmpStr = string.Join("&", ArrTmp);
            return System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(tmpStr, "SHA1").ToLower();
        }

        /// <summary>
        /// 日期类型转成Int
        /// </summary>
        private int? DateTimeToInt(DateTime? datetime)
        {
            if (datetime == null)
                return null;
            else
            {
                TimeSpan ts1 = new TimeSpan(datetime.Value.Ticks);
                TimeSpan ts2 = new TimeSpan(DateTime.Parse("1970-1-1").Ticks);
                TimeSpan ts = ts1.Subtract(ts2).Duration();
                return (int)ts.TotalSeconds;
            }
        }

        /// <summary>
        /// 下载文件到指定地址
        /// </summary>
        /// <param name="httpUrl">网络地址</param>
        /// <param name="filePath">保存本地目录</param>
        /// <param name="fileName">保存文件名</param>
        /// <returns></returns>
        public bool DownLoad(string httpUrl, string filePath, string fileName)
        {
            try
            {
                if (string.IsNullOrEmpty(httpUrl)) return false;

                if (!System.IO.Directory.Exists(filePath))
                {
                    System.IO.Directory.CreateDirectory(filePath);
                }

                using (System.Net.WebClient client = new System.Net.WebClient())
                {
                    client.DownloadFile(httpUrl, filePath + fileName);
                }

                return true;
            }
            catch
            {
                return false;
            }
        }


        /// <summary>
        /// 测试入口
        /// </summary>
        public void Test(string UserId)
        {
            if (UserId.IsNullOrBlank())
            {
                UserId = "ID1432560910936223607";
            }
            
            //保存Cookie---UserID
            System.Web.HttpCookie cookie = new System.Web.HttpCookie(Prefix + "UserID");
            cookie.Value = UserId.EncryDes(Key, Key);
            cookie.Expires = DateTime.Now.AddDays(1);
            System.Web.HttpContext.Current.Response.AppendCookie(cookie);

            //保存Cookie---encryption
            System.Web.HttpCookie cookieencry = new System.Web.HttpCookie(Prefix + "encry");
            cookieencry.Value = (Prefix + Key + UserId).HashMD5Password();
            cookieencry.Expires = DateTime.Now.AddDays(1);
            System.Web.HttpContext.Current.Response.AppendCookie(cookieencry);

        }
    }
}