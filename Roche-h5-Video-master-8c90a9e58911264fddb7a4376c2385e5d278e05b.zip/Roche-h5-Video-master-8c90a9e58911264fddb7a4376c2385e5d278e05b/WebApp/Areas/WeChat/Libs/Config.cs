﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApp.Areas.WeChat.Libs
{
    public class Config
    {
        /// <summary>
        /// 当前域名
        /// </summary>
        public static string GetHost
        {
            get
            {
                return Common.UrlHelper.HostUrl;
                //return HttpContext.Current.Request.Url.Host.ToString();
            }
        }

        /// <summary>
        /// 应用ID
        /// </summary>
        public static string CorpID
        {
            get
            {
                bind();
                return _CorpID;
            }
        }
        private static string _CorpID;

        /// <summary>
        /// 密钥
        /// </summary>
        public static string Secret
        {
            get
            {
                bind();
                return _Secret;
            }
        }
        private static string _Secret;

        /// <summary>
        /// 授权令牌
        /// </summary>
        public static string AccessToken
        {
            get
            {
                bind();
                getToken();
                return _access_token;
            }
        }
        private static string _access_token;
        private static DateTime? _expires_in;

        /// <summary>
        /// 管理组临时票
        /// </summary>
        public static string Ticket
        {
            get
            {
                bind();
                getTicket();
                return _ticket;
            }
        }
        private static string _ticket;
        private static DateTime? _ticket_expires_in;

        /// <summary>
        /// 加载数据
        /// </summary>
        private static void bind()
        {
            if (_CorpID.IsNullOrBlank() || _Secret.IsNullOrBlank())
            {
                var wc = new EntityService().GetObject<Models.WeChatConfig>(1);// Models.wechat_configLogic().Get(1);
                if (wc != null)
                {
                    _CorpID = wc.CorpID;
                    _Secret = wc.Secret;
                    _access_token = wc.AccessToken;
                    _expires_in = wc.ExpiresIn;
                    _ticket = wc.Ticket;
                    _ticket_expires_in = wc.TicketExpiresIn;
                }
            }
        }

        /// <summary>
        /// 获取授权令牌token
        /// </summary>
        private static void getToken()
        {
            if (_access_token.IsNullOrBlank() || !_expires_in.HasValue || DateTime.Now.CompareTo(_expires_in.Value) >= 0)
            {
                var req = new eDoctor.SDK.Http.HttpGet("https://qyapi.weixin.qq.com/cgi-bin/gettoken");
                req.Params.Add(new eDoctor.SDK.Http.RequestParams() { Key = "corpid", Value = _CorpID });
                req.Params.Add(new eDoctor.SDK.Http.RequestParams() { Key = "corpsecret", Value = _Secret });

                var res = req.Request();

                var token = new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<AccessTokenRespone>(res);
                if (token.errcode.HasValue && token.errcode > 0)
                {
                    throw new Exception("微信授权失败");
                }
                else
                {
                    _access_token = token.access_token;
                    _expires_in = DateTime.Now.AddSeconds(token.expires_in);

                    //更新数据库
                    new EntityService().Update(new Models.WeChatConfig() { ID = 1, AccessToken = _access_token, ExpiresIn = _expires_in});                    
                }

            }
        }

        /// <summary>
        /// 获取临时票ticket
        /// </summary>
        private static void getTicket()
        {
            if (_ticket.IsNullOrBlank() || !_ticket_expires_in.HasValue || DateTime.Now.CompareTo(_ticket_expires_in.Value) >= 0)
            {
                var req = new eDoctor.SDK.Http.HttpGet("https://qyapi.weixin.qq.com/cgi-bin/get_jsapi_ticket");
                req.Params.Add(new eDoctor.SDK.Http.RequestParams() { Key = "access_token", Value = AccessToken });

                var res = req.Request();

                var ticket = new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<TicketRespone>(res);
                if (ticket.errcode.HasValue && ticket.errcode > 0)
                {
                    throw new Exception("微信授权临时票失败");
                }
                else
                {
                    _ticket = ticket.ticket;
                    _ticket_expires_in = DateTime.Now.AddSeconds(ticket.expires_in);

                    //更新数据库
                    new EntityService().Update(new Models.WeChatConfig() { ID = 1, Ticket = _ticket, TicketExpiresIn = _ticket_expires_in});                    
                }
            }
        }

        /// <summary>
        /// 授权令牌模型
        /// </summary>
        private class AccessTokenRespone
        {
            public string access_token { set; get; }
            public int expires_in { set; get; }
            public int? errcode { set; get; }
            public string errmsg { set; get; }
        }

        /// <summary>
        /// 管理组临时票
        /// </summary>
        private class TicketRespone
        {

            public string ticket { set; get; }
            public int expires_in { set; get; }

            public int? errcode { set; get; }
            public string errmsg { set; get; }
        }
    }
}