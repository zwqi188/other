﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApp.Areas.WeChat.Respone
{
    public class WeChatUserInfo
    {

        //{
        //   "errcode": 0,
        //   "errmsg": "ok",
        //   "userid": "zhangsan",
        //   "name": "李四",
        //   "department": [1, 2],
        //   "position": "后台工程师",
        //   "mobile": "15913215421",
        //   "gender": "1",
        //   "email": "zhangsan@gzdev.com",
        //   "weixinid": "lisifordev",  
        //   "avatar": "http://wx.qlogo.cn/mmopen/ajNVdqHZLLA3WJ6DSZUfiakYe37PKnQhBIeOQBO4czqrnZDS79FH5Wm5m4X69TBicnHFlhiafvDwklOpZeXYQQ2icg/0",
        //   "status": 1,
        //   "extattr": {"attrs":[{"name":"爱好","value":"旅游"},{"name":"卡号","value":"1234567234"}]}
        //}


        public int errcode { set; get; }
        public string errmsg { set; get; }


        public string userid { set; get; }
        public string name { set; get; }

        public List<int> department { set; get; }
        public string position { set; get; }
        public string mobile { set; get; }
        public string gender { set; get; }
        public string email { set; get; }
        public string weixinid { set; get; }
        public string avatar { set; get; }
        public int status { set; get; }



    }
}