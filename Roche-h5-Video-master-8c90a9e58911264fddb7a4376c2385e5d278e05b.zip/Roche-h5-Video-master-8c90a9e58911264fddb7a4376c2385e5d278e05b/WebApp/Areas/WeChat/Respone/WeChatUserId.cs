﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApp.Areas.WeChat.Respone
{
    public class WeChatUserId
    {

        //{
        //   "UserId":"USERID",
        //   "DeviceId":"DEVICEID"
        //}

        //{
        //   "OpenId":"OPENID",
        //   "DeviceId":"DEVICEID"
        //}

        /// <summary>
        /// 成员UserID
        /// </summary>
        public string UserId { set; get; }
        /// <summary>
        /// 非企业成员的标识，对当前企业号唯一
        /// </summary>
        public string OpenId { set; get; }
        /// <summary>
        /// 手机设备号(由微信在安装时随机生成，删除重装会改变，升级不受影响)
        /// </summary>
        public string DeviceId { set; get; }


        public int errcode { set; get; }
        public string errmsg { set; get; }
    }
}