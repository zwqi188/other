﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApp.Areas.Mobile.Controllers
{
    public class HomeController : Controller
    {

        protected string WeChatUserID { set; get; }

        /// <summary>
        /// 进行授权时调用
        /// </summary>
        /// <param name="filterContext"></param>
        protected override void OnAuthorization(AuthorizationContext filterContext)
        {

            //if (!WeChat.Libs.WeChat.IsLogOn)
            //{
            //    filterContext.Result = Redirect(Common.UrlHelper.HostUrl + "/WeChat");
            //}
            //else
            //{
            //    this.WeChatUserID = WeChat.Libs.WeChat.UserID;
            //}

        }

        public ActionResult Index(string url)
        {
            return View("~/Views/Mob.cshtml");
        }


    }
}
