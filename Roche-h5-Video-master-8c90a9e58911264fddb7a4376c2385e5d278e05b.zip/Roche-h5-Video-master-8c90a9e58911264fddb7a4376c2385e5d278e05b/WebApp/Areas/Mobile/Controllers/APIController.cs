﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApp.Areas.Mobile.Controllers
{
    public class APIController : Controller
    {


        /// <summary>
        /// 分页&默认显示数
        /// </summary>
        protected const int DefaultPageCount = 20;

        /// <summary>
        /// 用户ID
        /// </summary>
        private string WeChatUserID { set; get; }

        /// <summary>
        /// 进行授权时调用
        /// </summary>
        /// <param name="filterContext"></param>
        protected override void OnAuthorization(AuthorizationContext filterContext)
        {
            //if (!WeChat.Libs.WeChat.IsLogOn)
            //{
            //    filterContext.Result = "权限不足".ToJsonResult();
            //}
            //else
            //{
            //    this.WeChatUserID = WeChat.Libs.WeChat.UserID;
            //}
        }


        /// <summary>
        /// 接口异常时调用
        /// </summary>
        /// <param name="filterContext"></param>
        protected override void OnException(ExceptionContext filterContext)
        {
            filterContext.ExceptionHandled = true;
            filterContext.Result = ("异常错误").ToJsonResult();
        }


        /// <summary>
        /// 获取视频列表
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public JsonResult GetVideoList(int? pageIndex, int? pageSize)
        {
            var list = new EntityService().GetPagedObjects(new Models.Video(), pageIndex ?? 1, pageSize ?? DefaultPageCount, string.Empty, "SortValue ASC");

            return list.PageList.ToJsonResult();
        }

        /// <summary>
        /// 获取视频详情
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public JsonResult GetVideoInfo(int ID)
        {
            var obj = new EntityService().GetObject<Models.Video>(ID);

            obj.UserLike = new EntityService().GetExist(new Models.Likes() { VideoID = obj.ID, WeChatUserID = this.WeChatUserID });

            return obj.ToJsonResult();
        }

        /// <summary>
        /// 获取视频评论
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="MinID"></param>
        /// <returns></returns>
        public JsonResult GetVideoComments(int ID, int? MinID)
        {
            var list = new EntityService().GetPagedObjects(new Models.ViewComments() { VideoID = ID }, 1, DefaultPageCount, (MinID.HasValue && MinID > 0) ? " and ID<{0}".FormatWith(MinID) : string.Empty, "ID DESC");

            return list.PageList.ToJsonResult();
        }

        /// <summary>
        /// 发表评论
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public JsonResult PublishComment(int ID, string Content)
        {
            var CommentID = 0;
            var result = new EntityService().Create(new Models.Comments()
            {
                IsDeleted = false,
                CreateDate = DateTime.Now,
                VideoID = ID,
                WeChatUserID = this.WeChatUserID,
                Content = Content
            }, ref CommentID);

            if (result)
            {
                var obj = new EntityService().GetObject<Models.Video>(ID);
                new EntityService().Update(new Models.Video() { ID = ID, CommentNumber = (obj.CommentNumber ?? 0) + 1 });

                return new EntityService().GetObject(new Models.ViewComments() { ID = ID }).ToJsonResult();
            }
            else
            {
                return result.ToJsonResult();
            }
        }

        /// <summary>
        /// 给视频点赞
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public JsonResult LikeVideo(int ID)
        {
            if (new EntityService().GetExist(new Models.Likes() { VideoID = ID, WeChatUserID = this.WeChatUserID }))
            {
                return false.ToJsonResult();
            }

            var result = new EntityService().Create(new Models.Likes()
            {
                IsDeleted = false,
                CreateDate = DateTime.Now,
                VideoID = ID,
                WeChatUserID = this.WeChatUserID,
            });

            if (result)
            {
                var obj = new EntityService().GetObject<Models.Video>(ID);
                new EntityService().Update(new Models.Video() { ID = ID, LikeNumber = (obj.LikeNumber ?? 0) + 1 });
            }

            return result.ToJsonResult();
        }

        /// <summary>
        /// 播放视频
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public JsonResult PlayVideo(int ID)
        {
            var obj = new EntityService().GetObject<Models.Video>(ID);
            var result = new EntityService().Update(new Models.Video() { ID = ID, PlayNumber = (obj.PlayNumber ?? 0) + 1 });

            return result.ToJsonResult();
        }

    }
}
