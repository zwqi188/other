﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApp.Areas.Mobile
{
    public class MobileAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "Mobile";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            //context.MapRoute(
            //    "MobApp",
            //    "mob/{*url}",
            //    new { controller = "Home", action = "Index" },
            //    new[] { "WebApp.Areas.Mobile.Controllers" }
            //);

            context.MapRoute(
                "MobileDefault",
                "Mobile/{controller}/{action}/{id}",
                new { controller = "Home", action = "Index", id = UrlParameter.Optional },
                new[] { "WebApp.Areas.Mobile.Controllers" }
            );
        }
    }
}