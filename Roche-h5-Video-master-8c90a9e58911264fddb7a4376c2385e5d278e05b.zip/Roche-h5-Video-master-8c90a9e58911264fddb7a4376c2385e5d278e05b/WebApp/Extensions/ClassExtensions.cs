﻿﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



internal static class ClassExtensions
{
    /// <summary>
    /// 类模型---API接口返回数据
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="t"></param>
    /// <returns></returns>
    public static System.Web.Mvc.JsonResult ToJsonResult<T>(this T t) where T : class
    {
        return new System.Web.Mvc.JsonResult() { Data = t, JsonRequestBehavior = System.Web.Mvc.JsonRequestBehavior.AllowGet };
    }

    /// <summary>
    /// bool模型---API接口返回数据
    /// </summary>
    /// <param name="result"></param>
    /// <returns></returns>
    public static System.Web.Mvc.JsonResult ToJsonResult(this bool result)
    {
        return new Dictionary<string, int>() { { "result", result ? 1 : 0 } }.ToJsonResult();
    }

    /// <summary>
    /// int模型---API接口返回数据
    /// </summary>
    /// <param name="result"></param>
    /// <returns></returns>
    public static System.Web.Mvc.JsonResult ToJsonResult(this int result)
    {
        return new Dictionary<string, int>() { { "result", result } }.ToJsonResult();
    }

    /// <summary>
    /// string模型---API接口返回数据
    /// </summary>
    /// <param name="result"></param>
    /// <returns></returns>
    public static System.Web.Mvc.JsonResult ToJsonResult(this string result)
    {
        return new Dictionary<string, string>() { { "errmsg", result } }.ToJsonResult();
    }
}

