﻿using System;


internal static class TimeExtensions
{

    /// <summary>
    /// Unix时间转日期格式
    /// </summary>
    /// <param name="seconds"></param>
    /// <returns></returns>
    public static DateTime FromUnixTime(this long seconds)
    {
        DateTime time = new DateTime(1970, 1, 1);

        time = time.AddSeconds(seconds);

        return time.ToLocalTime();
    }

    /// <summary>
    /// 日期格式转UNIX时间
    /// </summary>
    /// <param name="dateTime"></param>
    /// <returns></returns>
    public static long ToUnixTime(this DateTime dateTime)
    {

        var startTime = TimeZone.CurrentTimeZone.ToLocalTime(new System.DateTime(1970, 1, 1, 0, 0, 0, 0));

        TimeSpan timeSpan = (dateTime - startTime);
        long timestamp = (long)timeSpan.TotalSeconds;

        return timestamp;
    }



}