/**
 * Created by QingLiang.TAN on 2016/12/23.
 */
var webpack = require('webpack');
var HtmlWebpackPlugin = require('html-webpack-plugin');
module.exports = {
    entry : './ng2-adm/app/main.js',
    output : {
        path : './ng2-adm/dist',
        filename : 'app.bundle.js'
    },
    module : {
        loaders : [
            {test : /\.component.ts$/, loader : 'ts!angular2-template'},
            {test : /\.ts$/, exclude : /\.component.ts$/, loader : 'ts'},
            {test : /\.html$/, loader : 'raw'},
            {test : /\.css$/, loader : 'raw'}
        ]
    },
    resolve : {
        extensions : ['', '.js', '.ts']
    },
    plugins : [
        //提供全局的变量，在模块中使用无需用require引入
        new webpack.ProvidePlugin({
            "_" : "underscore",
            "window._" : "underscore"
        }),
        new webpack.optimize.UglifyJsPlugin({
            compressor : {
                warnings : false
            }
        }),
        new HtmlWebpackPlugin({
            template : './ng2-adm/index.html'
        })
    ]
};
