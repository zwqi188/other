/**
 * Created by QingLiang.TAN on 2016/6/2.
 */

import {Component} from '@angular/core';
import {Router} from '@angular/router';

// 自定义服务
import {HttpServices} from  '../Common/HttpServices';
import {LeftMenuSelectServices, MenuAccessServices} from  '../Common/DataServices';


//用户登陆
@Component({
    selector: 'AdmAccountLogin',
    templateUrl: '/ng2-adm/app/AdmAccount/login.html?v=' + window.versions,
})
export class AdmAccountLogin {

    // 页面属性
    private model = {formInvalid: false};

    constructor(private http:HttpServices, private  leftMenuSelect:LeftMenuSelectServices, private menuAccess:MenuAccessServices, private router:Router) {

        //定义左侧菜单选中项
        this.leftMenuSelect.selected = 'Login';

        //初始化一个验证码
        this.changeVerifyCode();
    }

    //改变验证码
    changeVerifyCode() {
        this.model.verifyCode = '/admin/public/verifyCode?v=' + Math.random();
    }

    //表单提交
    onSubmit(pageForm) {

        //判断表单验证
        if (!pageForm.form.valid) {
            this.model.formInvalid = true;
            return;
        }

        //提交数据
        let postData = pageForm.form.value;

        //发送请求
        this.http.post('/admin/Public/Login', postData).then(res => {
            let result = res.json();
            if (result.result) {
                //获取用户权限
                this.menuAccess.myAccess();
                //成功返回数据
                this.router.navigateByUrl('/');
            }
            else {
                //改变验证码
                this.changeVerifyCode();
                //提示
                window.swal("错误!", result.errmsg, "error")
            }
        });
    }
}
