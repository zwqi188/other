"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by QingLiang.TAN on 2016/8/3.
 */
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
// 自定义服务
var HttpServices_1 = require('../Common/HttpServices');
var DataServices_1 = require('../Common/DataServices');
//更新管理员
var AdmAccountUpdate = (function () {
    function AdmAccountUpdate(http, leftMenuSelect, route, ref) {
        var _this = this;
        this.http = http;
        this.leftMenuSelect = leftMenuSelect;
        this.route = route;
        this.ref = ref;
        //页面数据
        this.model = {};
        this.selectGroups = [];
        //设置左侧菜单选择
        this.leftMenuSelect.selected = 'Account';
        //获取分组可选项
        this.http.post('/Admin/AdmGroup/Select', null).then(function (body) {
            _this.selectGroups = body.json();
        });
        // //获取详情数据
        this.http.post('/Admin/AdmAccount/Info', this.route.params.value).then(function (body) {
            _this.model = body.json();
            _this.model.showUpdateImage = true;
        });
    }
    //预览图片
    AdmAccountUpdate.prototype.onPreview = function (img) {
        window.swal({
            title: '<img src=' + img + ' style="max-width:400px;min-height:150px;max-height:350px;" />',
            html: true,
            confirmButtonText: '关闭'
        });
    };
    //ueditor编辑器上传图片插件
    AdmAccountUpdate.prototype.onUpdateImage = function (images) {
        if (images && images.length) {
            this.model.Avatar = images[0].src;
            this.ref.detectChanges();
        }
    };
    // 表单提交
    AdmAccountUpdate.prototype.onSubmit = function (pageForm) {
        //判断表单验证
        if (!pageForm.form.valid) {
            this.model.formInvalid = true;
            return;
        }
        //提交数据
        var postData = pageForm.form.value;
        postData.ID = this.model.ID;
        //发送请求
        this.http.post('/Admin/AdmAccount/Update', postData).then(function (body) {
            var res = body.json();
            if (res.result) {
                window.swal("保存成功", "", "success");
            }
            else {
                window.swal(res.errmsg ? res.errmsg : "保存失败，请重试...", "", "error");
            }
        });
    };
    AdmAccountUpdate = __decorate([
        core_1.Component({
            selector: 'AdmAccountUpdate',
            templateUrl: '../ng2-adm/app/AdmAccount/Form.html?v=' + window.versions,
        }), 
        __metadata('design:paramtypes', [HttpServices_1.HttpServices, DataServices_1.LeftMenuSelectServices, router_1.ActivatedRoute, core_1.ChangeDetectorRef])
    ], AdmAccountUpdate);
    return AdmAccountUpdate;
}());
exports.AdmAccountUpdate = AdmAccountUpdate;
//# sourceMappingURL=Update.js.map