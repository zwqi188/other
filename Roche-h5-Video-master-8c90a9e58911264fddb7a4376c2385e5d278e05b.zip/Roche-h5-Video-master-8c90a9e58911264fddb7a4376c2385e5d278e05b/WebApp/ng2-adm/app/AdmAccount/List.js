"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by QingLiang.TAN on 2016/8/3.
 */
var core_1 = require('@angular/core');
// 自定义服务
var DataServices_1 = require('../Common/DataServices');
var HttpServices_1 = require('../Common/HttpServices');
var TableServices_1 = require('../Common/TableServices');
//用户登陆
var AdmAccountList = (function () {
    function AdmAccountList(leftMenuSelect, menuAccess, http) {
        this.leftMenuSelect = leftMenuSelect;
        this.menuAccess = menuAccess;
        this.http = http;
        //设置左侧菜单选择
        this.leftMenuSelect.selected = 'Account';
        //初始化表格服务类
        this.table = new TableServices_1.TableServices(http);
        //设置接口地址
        this.table.url.list = '/admin/AdmAccount/List';
        this.table.url.del = '/admin/AdmAccount/Delete';
        this.table.url.exp = '/admin/AdmAccount/Export';
        //设置字段初始化
        this.table.keysInit({
            ID: '#',
            UserName: '帐户名',
            GroupName: '分组名',
            RealName: '姓名',
            Email: '邮件',
            Mobile: '手机'
        }, {
            UserName: '帐户名',
            GroupName: '分组名',
            RealName: '姓名'
        });
        //初始加载
        this.table.goPage(1);
    }
    AdmAccountList = __decorate([
        core_1.Component({
            selector: 'AdmAccountList',
            templateUrl: '../ng2-adm/app/AdmAccount/List.html?v=' + window.versions,
        }), 
        __metadata('design:paramtypes', [DataServices_1.LeftMenuSelectServices, DataServices_1.MenuAccessServices, HttpServices_1.HttpServices])
    ], AdmAccountList);
    return AdmAccountList;
}());
exports.AdmAccountList = AdmAccountList;
//# sourceMappingURL=List.js.map