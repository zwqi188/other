/**
 * Created by QingLiang.TAN on 2016/8/3.
 */
import {Component, ChangeDetectorRef} from '@angular/core';
import {ActivatedRoute} from '@angular/router';


// 自定义服务
import {HttpServices} from  '../Common/HttpServices';
import {LeftMenuSelectServices, MenuAccessServices} from  '../Common/DataServices';


//创建管理员
@Component({
    selector: 'AdmAccountCreate',
    templateUrl: '../ng2-adm/app/AdmAccount/Form.html?v=' + window.versions,
})
export class AdmAccountCreate {

    //页面数据
    private model:any = {};
    private selectGroups:any = [];

    constructor(private http:HttpServices, private  leftMenuSelect:LeftMenuSelectServices, private route:ActivatedRoute, private ref:ChangeDetectorRef) {
        //设置左侧菜单选择
        this.leftMenuSelect.selected = 'Account';

        //获取分组可选项
        this.http.post('/Admin/AdmGroup/Select', null).then(body=> {
            this.selectGroups = body.json();
        });

        this.model.showUpdateImage = true;

    }

    //预览图片
    onPreview(img) {
        window.swal({
            title: '<img src=' + img + ' style="max-width:400px;min-height:150px;max-height:350px;" />',
            html: true,
            confirmButtonText: '关闭'
        });
    }

    //ueditor编辑器上传图片插件
    onUpdateImage(images) {
        if (images && images.length) {
            this.model.Avatar = images[0].src;
            this.ref.detectChanges();
        }
    }

    // 表单提交
    onSubmit(pageForm) {

        //判断表单验证
        if (!pageForm.form.valid) {
            this.model.formInvalid = true;
            return;
        }

        //提交数据
        let postData = pageForm.form.value;

        //发送请求
        this.http.post('/Admin/AdmAccount/Create', postData).then(body => {
            let res = body.json();
            if (res.result) {
                window.swal("保存成功", "", "success");
            } else {
                window.swal(res.errmsg ? res.errmsg : "保存失败，请重试...", "", "error");
            }
        });

    }

}


