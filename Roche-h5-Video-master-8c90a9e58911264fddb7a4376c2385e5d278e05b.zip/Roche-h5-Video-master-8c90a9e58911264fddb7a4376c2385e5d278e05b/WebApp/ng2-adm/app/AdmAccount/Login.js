/**
 * Created by QingLiang.TAN on 2016/6/2.
 */
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
// 自定义服务
var HttpServices_1 = require('../Common/HttpServices');
var DataServices_1 = require('../Common/DataServices');
//用户登陆
var AdmAccountLogin = (function () {
    function AdmAccountLogin(http, leftMenuSelect, menuAccess, router) {
        this.http = http;
        this.leftMenuSelect = leftMenuSelect;
        this.menuAccess = menuAccess;
        this.router = router;
        // 页面属性
        this.model = { formInvalid: false };
        //定义左侧菜单选中项
        this.leftMenuSelect.selected = 'Login';
        //初始化一个验证码
        this.changeVerifyCode();
    }
    //改变验证码
    AdmAccountLogin.prototype.changeVerifyCode = function () {
        this.model.verifyCode = '/admin/public/verifyCode?v=' + Math.random();
    };
    //表单提交
    AdmAccountLogin.prototype.onSubmit = function (pageForm) {
        var _this = this;
        //判断表单验证
        if (!pageForm.form.valid) {
            this.model.formInvalid = true;
            return;
        }
        //提交数据
        var postData = pageForm.form.value;
        //发送请求
        this.http.post('/admin/Public/Login', postData).then(function (res) {
            var result = res.json();
            if (result.result) {
                //获取用户权限
                _this.menuAccess.myAccess();
                //成功返回数据
                _this.router.navigateByUrl('/');
            }
            else {
                //改变验证码
                _this.changeVerifyCode();
                //提示
                window.swal("错误!", result.errmsg, "error");
            }
        });
    };
    AdmAccountLogin = __decorate([
        core_1.Component({
            selector: 'AdmAccountLogin',
            templateUrl: '/ng2-adm/app/AdmAccount/login.html?v=' + window.versions,
        }), 
        __metadata('design:paramtypes', [HttpServices_1.HttpServices, DataServices_1.LeftMenuSelectServices, DataServices_1.MenuAccessServices, router_1.Router])
    ], AdmAccountLogin);
    return AdmAccountLogin;
}());
exports.AdmAccountLogin = AdmAccountLogin;
//# sourceMappingURL=Login.js.map