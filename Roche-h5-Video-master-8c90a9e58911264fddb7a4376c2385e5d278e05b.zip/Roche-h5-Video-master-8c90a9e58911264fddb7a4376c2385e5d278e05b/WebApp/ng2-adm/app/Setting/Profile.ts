/**
 * Created by QingLiang.TAN on 2016/6/2.
 */

import {Component, ChangeDetectorRef} from '@angular/core';


// 自定义服务
import {HttpServices} from  '../Common/HttpServices';
import {LeftMenuSelectServices, MenuAccessServices} from  '../Common/DataServices';

//用户登陆
@Component({
    selector: 'Profile',
    templateUrl: '../ng2-adm/app/setting/Profile.html?v=' + window.versions,
})
export class Profile {

    //页面数据
    private model:any = {};


    constructor(private http:HttpServices, private  leftMenuSelect:LeftMenuSelectServices, private menuAccess:MenuAccessServices, private ref:ChangeDetectorRef) {


        //设置左侧菜单选择
        this.leftMenuSelect.selected = 'Setting';

        //获取当前用户信息
        this.http.post('/Admin/My/GetMyInfo', null).then(body => {
            this.model = body.json();
            this.model.showUpdateImage = true;
        });
    }

    //ueditor编辑器上传图片插件
    onUpdateImage(images) {
        if (images && images.length) {
            this.model.Avatar = images[0].src;
            this.ref.detectChanges();
        }
    }

    //预览图片
    onPreview(img) {
        window.swal({
            title: '<img src=' + img + ' style="max-width:400px;min-height:150px;max-height:350px;" />',
            html: true,
            confirmButtonText: '关闭'
        });
    }

    // 表单提交
    onSubmit(pageForm) {
        //判断表单验证
        if (!pageForm.form.valid) {
            this.model.formInvalid = true;
            return;
        }

        //提交数据
        let postData = pageForm.form.value;

        //发送请求
        this.http.post('/Admin/My/UpdateMyInfo', postData).then(body => {
            let res = body.json();
            if (res.result) {
                window.swal("保存成功", "", "success");
            } else {
                window.swal(res.errmsg ? res.errmsg : "保存失败，请重试...", "", "error");
            }
        });

    }
}


