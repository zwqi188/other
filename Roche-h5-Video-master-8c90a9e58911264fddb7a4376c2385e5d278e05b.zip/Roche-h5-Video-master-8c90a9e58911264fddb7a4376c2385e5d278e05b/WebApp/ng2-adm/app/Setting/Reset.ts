/**
 * Created by QingLiang.TAN on 2016/6/2.
 */

import {Component, ChangeDetectorRef} from '@angular/core';

// 自定义服务
import {HttpServices} from  '../Common/HttpServices';
import {LeftMenuSelectServices} from  '../Common/DataServices';


//用户登陆
@Component({
    selector: 'Reset',
    templateUrl: '../ng2-adm/app/setting/Reset.html?v=' + window.versions,
})
export class Reset {

    //页面数据
    private model:any = {};

    constructor(private http:HttpServices, private  leftMenuSelect:LeftMenuSelectServices, private ref:ChangeDetectorRef) {
        //设置左侧菜单选择
        this.leftMenuSelect.selected = 'Setting';
    }

    // 表单提交
    onSubmit(pageForm) {
        //判断表单验证
        if (!pageForm.form.valid) {
            this.model.formInvalid = true;
            return;
        }

        //确认密码
        if (this.model.ConfirmPwd != this.model.NewPwd) {
            this.model.formInvalid = true;
            return;
        }

        //提交数据
        let postData = pageForm.form.value;

        //发送请求
        this.http.post('/Admin/My/UpdatePassWord', postData).then(body => {
            let res = body.json();
            if (res.result) {
                window.swal("保存成功", "", "success");
            } else {
                window.swal(res.errmsg ? res.errmsg : "保存失败，请重试...", "", "error");
            }
        });

    }
}


