"use strict";
/**
 * Created by QingLiang.TAN on 2016/8/30.
 */
// 预加载ng2
require('core-js');
require('reflect-metadata');
require('zone.js/dist/zone');
var platform_browser_dynamic_1 = require('@angular/platform-browser-dynamic');
var App_Module_1 = require('./Config/App.Module');
//外部插件
require('underscore/underscore-min.js');
require('sweetalert/dist/sweetalert.min.js');
require('../ueditor/ueditor.config.js');
require('../ueditor/ueditor.all.js');
require('../js/public.js');
platform_browser_dynamic_1.platformBrowserDynamic().bootstrapModule(App_Module_1.AppModule);
//# sourceMappingURL=Main.js.map