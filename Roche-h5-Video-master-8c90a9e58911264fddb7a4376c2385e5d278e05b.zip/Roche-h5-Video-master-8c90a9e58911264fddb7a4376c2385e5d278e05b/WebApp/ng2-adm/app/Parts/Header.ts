/**
 * Created by QingLiang.TAN on 2016/6/2.
 */

import {Component} from '@angular/core';
import {Router} from '@angular/router';

// 自定义服务&功能
import {HttpServices} from  '../Common/HttpServices';
import {LeftMenuSelectServices} from "../Common/DataServices";


//页面顶部
@Component({
    selector: 'parts-header',
    template: `
    <div class="app-header">
        <div class="app-header-logo">
            <img src="../ng2-adm/images/edoctor.png"/>
            <p>eDoctor Management System</p>
        </div>
        <div class="app-header-theme"></div>
        <div class="app-header-tool" *ngIf="leftMenuSelect.selected && leftMenuSelect.selected!='Login'">
            <!--<a class="fa fa-envelope" title="消息"></a>-->
            <a routerLink="Setting/Profile" class="fa fa-user" title="个人信息"></a>
            <a (click)="onClickLogout()" class="fa fa-sign-out" title="退出登陆"></a>
        </div>
    </div>
    `
})
export class PartsHeader {
    constructor(private http:HttpServices, private leftMenuSelect:LeftMenuSelectServices, private router:Router) {
    }

    //退出登陆
    onClickLogout() {
        window.swal({
            title: "你确认要退出当前登陆吗？",
            text: "",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "确 认",
            cancelButtonText: "取 消",
            closeOnConfirm: true,
            closeOnCancel: true
        }, (isConfirm=> {
            if (isConfirm) {
                window.location.href = '/Admin/Public/Logout'
                // this.router.navigateByUrl("/Account/Login");
            }
        }));
    }
}


