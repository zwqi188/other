/**
 * Created by QingLiang.TAN on 2016/6/2.
 */
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
// 自定义服务&功能
var HttpServices_1 = require('../Common/HttpServices');
var DataServices_1 = require("../Common/DataServices");
//页面顶部
var PartsHeader = (function () {
    function PartsHeader(http, leftMenuSelect, router) {
        this.http = http;
        this.leftMenuSelect = leftMenuSelect;
        this.router = router;
    }
    //退出登陆
    PartsHeader.prototype.onClickLogout = function () {
        window.swal({
            title: "你确认要退出当前登陆吗？",
            text: "",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "确 认",
            cancelButtonText: "取 消",
            closeOnConfirm: true,
            closeOnCancel: true
        }, (function (isConfirm) {
            if (isConfirm) {
                window.location.href = '/Admin/Public/Logout';
            }
        }));
    };
    PartsHeader = __decorate([
        core_1.Component({
            selector: 'parts-header',
            template: "\n    <div class=\"app-header\">\n        <div class=\"app-header-logo\">\n            <img src=\"../ng2-adm/images/edoctor.png\"/>\n            <p>eDoctor Management System</p>\n        </div>\n        <div class=\"app-header-theme\"></div>\n        <div class=\"app-header-tool\" *ngIf=\"leftMenuSelect.selected && leftMenuSelect.selected!='Login'\">\n            <!--<a class=\"fa fa-envelope\" title=\"\u6D88\u606F\"></a>-->\n            <a routerLink=\"Setting/Profile\" class=\"fa fa-user\" title=\"\u4E2A\u4EBA\u4FE1\u606F\"></a>\n            <a (click)=\"onClickLogout()\" class=\"fa fa-sign-out\" title=\"\u9000\u51FA\u767B\u9646\"></a>\n        </div>\n    </div>\n    "
        }), 
        __metadata('design:paramtypes', [HttpServices_1.HttpServices, DataServices_1.LeftMenuSelectServices, router_1.Router])
    ], PartsHeader);
    return PartsHeader;
}());
exports.PartsHeader = PartsHeader;
//# sourceMappingURL=Header.js.map