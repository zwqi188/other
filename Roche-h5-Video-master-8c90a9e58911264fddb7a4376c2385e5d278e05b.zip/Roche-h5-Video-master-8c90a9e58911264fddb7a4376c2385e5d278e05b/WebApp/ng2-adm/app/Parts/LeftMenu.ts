/**
 * Created by QingLiang.TAN on 2016/6/2.
 */

import {Component} from '@angular/core';


// 自定义服务&功能
import {LeftMenuSelectServices, MenuAccessServices} from "../Common/DataServices";


//页面左部导航组件
@Component({
    selector: 'parts-leftmenu',
    template: `
    <div class="app-leftmenu">
        <ul class="app-leftmenu-list">            
            <li [ngClass]="{'active':leftMenuSelect.selected=='Setting'}" routerLink="/Setting/Profile" *ngIf="menuAccess.isAccess('Profile')">
                <span class="fa fa-cog"></span><label>个人设置</label>
            </li>
            <li [ngClass]="{'active':leftMenuSelect.selected=='Articles'}" routerLink="/Articles/List" *ngIf="menuAccess.isAccess('ArticlesList')">
                <span class="fa fa-book"></span><label>文章</label>
            </li>
            <li [ngClass]="{'active':leftMenuSelect.selected=='Group'}" routerLink="/Group/List" *ngIf="menuAccess.isAccess('AdmGroupList')">
                <span class="fa fa-group"></span><label>管理员分组</label>
            </li>
            <li [ngClass]="{'active':leftMenuSelect.selected=='Account'}" routerLink="/Account/List" *ngIf="menuAccess.isAccess('AdmAccountList')">
                <span class="fa fa-user-plus"></span><label>管理员</label>
            </li>
            <li [ngClass]="{'active':leftMenuSelect.selected=='Menu'}" routerLink="/Menu/List" *ngIf="menuAccess.isAccess('AdmMenuList')">
                <span class="fa fa-tasks"></span><label>权限菜单</label>
            </li>
        </ul>
    </div>
    `,
})
export class PartsLeftMenu {

    constructor(private leftMenuSelect:LeftMenuSelectServices, private menuAccess:MenuAccessServices) {
    }
}


