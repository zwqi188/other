/**
 * Created by QingLiang.TAN on 2016/6/30.
 */
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
//表格分页底部
var TableFooter = (function () {
    function TableFooter() {
        //是否提示
        this.table = {};
    }
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Object)
    ], TableFooter.prototype, "table", void 0);
    TableFooter = __decorate([
        core_1.Component({
            selector: 'table-footer',
            template: "\n    <!--\u8868\u683C\u5206\u9875-->\n    <div class=\"app-page-table-footer\" *ngIf=\"table.page.loading\">\n        <p><i class=\"fa fa-spinner fa-spin\"></i> \u6B63\u5728\u52AA\u529B\u52A0\u8F7D\u4E2D...</p>\n    </div>\n    <div class=\"app-page-table-footer\" *ngIf=\"!table.page.loading\">\n        <p *ngIf=\"!table.page.totalItemCount\">\u6CA1\u6709\u6570\u636E\uFF0C\u518D\u5237\u65B0\u8BD5\u4E00\u4E0B...</p>\n        <div *ngIf=\"table.page.totalItemCount\" class=\"pull-left\">\u5F53\u524D\u7B2C{{table.page.pageIndex}}\u9875/\u603B\u5171{{table.page.totalPageCount}}\u9875</div>\n        <ul *ngIf=\"table.page.totalItemCount\" class=\"pagination pull-right\">\n            <li class=\"disabled\" *ngIf=\"table.page.pageIndex<=1\">\n                <a>&laquo;</a>\n            </li>\n            <li (click)=\"table.goPage(1)\" *ngIf=\"table.page.pageIndex>1\">\n                <a>&laquo;</a>\n            </li>\n            <li class=\"disabled\" *ngIf=\"table.page.pageIndex<=1\">\n                <a>&lt;</a>\n            </li>\n            <li (click)=\"table.goPage(table.page.pageIndex-1)\" *ngIf=\"table.page.pageIndex>1\">\n                <a>&lt;</a>\n            </li>\n            <li class=\"active\">\n                <a>{{table.page.pageIndex}}</a>\n            </li>\n            <li class=\"disabled\" *ngIf=\"table.page.pageIndex>=table.page.totalPageCount\">\n                <a>&gt;</a>\n            </li>\n            <li (click)=\"table.goPage(table.page.pageIndex+1)\" *ngIf=\"table.page.pageIndex<table.page.totalPageCount\">\n                <a>&gt;</a>\n            </li>\n            <li class=\"disabled\" *ngIf=\"table.page.pageIndex>=table.page.totalPageCount\">\n                <a>&raquo;</a>\n            </li>\n            <li (click)=\"table.goPage(table.page.totalPageCount)\" *ngIf=\"table.page.pageIndex<table.page.totalPageCount\">\n                <a>&raquo;</a>\n            </li>\n            <li>\n               <input type=\"text\" class=\"form-control\" placeholder=\"{{table.page.pageIndex}}\" [(ngModel)]=\"table.page.goPageIndex\"/> \n            </li>\n            <li>\n                <a (click)=\"table.goPage(table.page.goPageIndex)\">Go</a>\n            </li>\n        </ul>\n        <div class=\"clearfix\"></div>\n    </div>\n    "
        }), 
        __metadata('design:paramtypes', [])
    ], TableFooter);
    return TableFooter;
}());
exports.TableFooter = TableFooter;
//# sourceMappingURL=TableFooter.js.map