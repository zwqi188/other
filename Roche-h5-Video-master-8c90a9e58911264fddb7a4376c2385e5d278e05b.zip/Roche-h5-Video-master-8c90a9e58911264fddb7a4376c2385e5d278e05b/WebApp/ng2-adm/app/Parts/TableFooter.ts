/**
 * Created by QingLiang.TAN on 2016/6/30.
 */

import {Component, Input, Output, EventEmitter} from '@angular/core';

//表格分页底部
@Component({
    selector: 'table-footer',
    template: `
    <!--表格分页-->
    <div class="app-page-table-footer" *ngIf="table.page.loading">
        <p><i class="fa fa-spinner fa-spin"></i> 正在努力加载中...</p>
    </div>
    <div class="app-page-table-footer" *ngIf="!table.page.loading">
        <p *ngIf="!table.page.totalItemCount">没有数据，再刷新试一下...</p>
        <div *ngIf="table.page.totalItemCount" class="pull-left">当前第{{table.page.pageIndex}}页/总共{{table.page.totalPageCount}}页</div>
        <ul *ngIf="table.page.totalItemCount" class="pagination pull-right">
            <li class="disabled" *ngIf="table.page.pageIndex<=1">
                <a>&laquo;</a>
            </li>
            <li (click)="table.goPage(1)" *ngIf="table.page.pageIndex>1">
                <a>&laquo;</a>
            </li>
            <li class="disabled" *ngIf="table.page.pageIndex<=1">
                <a>&lt;</a>
            </li>
            <li (click)="table.goPage(table.page.pageIndex-1)" *ngIf="table.page.pageIndex>1">
                <a>&lt;</a>
            </li>
            <li class="active">
                <a>{{table.page.pageIndex}}</a>
            </li>
            <li class="disabled" *ngIf="table.page.pageIndex>=table.page.totalPageCount">
                <a>&gt;</a>
            </li>
            <li (click)="table.goPage(table.page.pageIndex+1)" *ngIf="table.page.pageIndex<table.page.totalPageCount">
                <a>&gt;</a>
            </li>
            <li class="disabled" *ngIf="table.page.pageIndex>=table.page.totalPageCount">
                <a>&raquo;</a>
            </li>
            <li (click)="table.goPage(table.page.totalPageCount)" *ngIf="table.page.pageIndex<table.page.totalPageCount">
                <a>&raquo;</a>
            </li>
            <li>
               <input type="text" class="form-control" placeholder="{{table.page.pageIndex}}" [(ngModel)]="table.page.goPageIndex"/> 
            </li>
            <li>
                <a (click)="table.goPage(table.page.goPageIndex)">Go</a>
            </li>
        </ul>
        <div class="clearfix"></div>
    </div>
    `
})
export class TableFooter {

    //是否提示
    @Input() table:any = {};


}


