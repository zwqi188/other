/**
 * Created by QingLiang.TAN on 2016/8/3.
 */
import {Component, ChangeDetectorRef} from '@angular/core';

// 自定义服务
import {LeftMenuSelectServices, MenuAccessServices} from  '../Common/DataServices';
import {HttpServices} from  '../Common/HttpServices';
import {TableServices} from  '../Common/TableServices';

//管理员分组列表
@Component({
    selector: 'List',
    templateUrl: '../ng2-adm/app/Articles/List.html?v=' + window.versions,
})
export class ArticlesList {


    private table:TableServices;

    constructor(private leftMenuSelect:LeftMenuSelectServices, private menuAccess:MenuAccessServices, private http:HttpServices) {
        //设置左侧菜单选择
        this.leftMenuSelect.selected = 'Articles';

        //初始化表格服务类
        this.table = new TableServices(http);

        //设置接口地址
        this.table.url.list = '/admin/Articles/List';
        this.table.url.del = '/admin/Articles/Delete';
        this.table.url.exp = '/admin/Articles/Export';
        
        //设置字段初始化
        this.table.keysInit({
            "ID": '#',
            "Title": "标题",
            "Author": "作者",
            "Category": "分类",
            "ReleaseTime": "发布时间",
            "SortValue": "排序值",
            "ReadNumber": "阅读数",
            "LikeNumber": "点赞数",
            "ShareNumber": "分享数",
            "CommentNumber": "评论数",
            "ScoreValue": "评分值"
        }, {
            "likeTitle": "标题",
            "likeAuthor": "作者",
            "likeCategory": "分类"
        });


        //分页请求后回调
        this.table.goPageCallBack = (res=> {
            for (let item of this.table.model) {
                item.ReleaseTime = (item.ReleaseTime && item.ReleaseTime.toDateFormat('yyyy-MM-dd'));
            }
        });

        //初始加载
        this.table.goPage(1);
    }


}


