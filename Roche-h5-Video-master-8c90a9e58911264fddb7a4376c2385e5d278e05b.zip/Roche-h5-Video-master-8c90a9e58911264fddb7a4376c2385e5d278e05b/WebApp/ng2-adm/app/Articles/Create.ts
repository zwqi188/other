/**
 * Created by QingLiang.TAN on 2016/8/3.
 */
import {Component, ChangeDetectorRef} from '@angular/core';
import {ActivatedRoute} from '@angular/router';

// 自定义服务
import {HttpServices} from  '../Common/HttpServices';
import {LeftMenuSelectServices} from  '../Common/DataServices';


//创建管理员分组
@Component({
    selector: 'Create',
    templateUrl: '../ng2-adm/app/Articles/Form.html?v=' + window.versions,
})
export class ArticlesCreate {

    //页面数据
    private model:any = {};

    constructor(private http:HttpServices, private  leftMenuSelect:LeftMenuSelectServices, private route:ActivatedRoute, private ref:ChangeDetectorRef) {
        //设置左侧菜单选择
        this.leftMenuSelect.selected = 'Articles';
    }

    //表单提交
    onSubmit(pageForm) {

        //判断表单验证
        if (!pageForm.form.valid) {
            this.model.formInvalid = true;
            return;
        }

        //提交数据
        let postData = pageForm.form.value;
        postData.Content = this.model.Content;

        //发送请求
        this.http.post('/Admin/Articles/Create', postData).then(body => {
            let res = body.json();
            if (res.result) {
                window.swal("保存成功", "", "success");
            } else {
                window.swal(res.errmsg ? res.errmsg : "保存失败，请重试...", "", "error");
            }
        });

    }

}


