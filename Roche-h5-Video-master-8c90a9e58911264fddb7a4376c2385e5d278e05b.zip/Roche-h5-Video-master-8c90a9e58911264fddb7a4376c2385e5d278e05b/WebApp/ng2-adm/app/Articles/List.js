"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by QingLiang.TAN on 2016/8/3.
 */
var core_1 = require('@angular/core');
// 自定义服务
var DataServices_1 = require('../Common/DataServices');
var HttpServices_1 = require('../Common/HttpServices');
var TableServices_1 = require('../Common/TableServices');
//管理员分组列表
var ArticlesList = (function () {
    function ArticlesList(leftMenuSelect, menuAccess, http) {
        var _this = this;
        this.leftMenuSelect = leftMenuSelect;
        this.menuAccess = menuAccess;
        this.http = http;
        //设置左侧菜单选择
        this.leftMenuSelect.selected = 'Articles';
        //初始化表格服务类
        this.table = new TableServices_1.TableServices(http);
        //设置接口地址
        this.table.url.list = '/admin/Articles/List';
        this.table.url.del = '/admin/Articles/Delete';
        this.table.url.exp = '/admin/Articles/Export';
        //设置字段初始化
        this.table.keysInit({
            "ID": '#',
            "Title": "标题",
            "Author": "作者",
            "Category": "分类",
            "ReleaseTime": "发布时间",
            "SortValue": "排序值",
            "ReadNumber": "阅读数",
            "LikeNumber": "点赞数",
            "ShareNumber": "分享数",
            "CommentNumber": "评论数",
            "ScoreValue": "评分值"
        }, {
            "likeTitle": "标题",
            "likeAuthor": "作者",
            "likeCategory": "分类"
        });
        //分页请求后回调
        this.table.goPageCallBack = (function (res) {
            for (var _i = 0, _a = _this.table.model; _i < _a.length; _i++) {
                var item = _a[_i];
                item.ReleaseTime = (item.ReleaseTime && item.ReleaseTime.toDateFormat('yyyy-MM-dd'));
            }
        });
        //初始加载
        this.table.goPage(1);
    }
    ArticlesList = __decorate([
        core_1.Component({
            selector: 'List',
            templateUrl: '../ng2-adm/app/Articles/List.html?v=' + window.versions,
        }), 
        __metadata('design:paramtypes', [DataServices_1.LeftMenuSelectServices, DataServices_1.MenuAccessServices, HttpServices_1.HttpServices])
    ], ArticlesList);
    return ArticlesList;
}());
exports.ArticlesList = ArticlesList;
//# sourceMappingURL=List.js.map