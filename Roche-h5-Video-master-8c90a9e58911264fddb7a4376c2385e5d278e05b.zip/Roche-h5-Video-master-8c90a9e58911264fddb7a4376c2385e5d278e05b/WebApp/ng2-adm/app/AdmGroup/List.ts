/**
 * Created by QingLiang.TAN on 2016/8/3.
 */
import {Component} from '@angular/core';

// 自定义服务
import {LeftMenuSelectServices, MenuAccessServices} from  '../Common/DataServices';
import {HttpServices} from  '../Common/HttpServices';
import {TableServices} from  '../Common/TableServices';


//管理员分组列表
@Component({
    selector: 'AdmGroupList',
    templateUrl: '../ng2-adm/app/AdmGroup/List.html?v=' + window.versions,

})
export class AdmGroupList {


    private table:TableServices;

    constructor(private leftMenuSelect:LeftMenuSelectServices, private menuAccess:MenuAccessServices, private http:HttpServices) {
        //设置左侧菜单选择
        this.leftMenuSelect.selected = 'Group';

        //初始化表格服务类
        this.table = new TableServices(http);

        //设置接口地址
        this.table.url.list = '/admin/AdmGroup/List';
        this.table.url.del = '/admin/AdmGroup/Delete';
        this.table.url.exp = '/admin/AdmGroup/Export';

        //设置字段初始化
        this.table.keysInit({ID: '#', GroupName: '分组名', GroupDesc: '分组备注'}, {GroupName: '分组名'});

        //初始加载
        this.table.goPage(1);
    }


}


