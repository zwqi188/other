"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by QingLiang.TAN on 2016/8/3.
 */
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
// 自定义服务
var HttpServices_1 = require('../Common/HttpServices');
var DataServices_1 = require('../Common/DataServices');
//创建管理员分组
var AdmGroupCreate = (function () {
    function AdmGroupCreate(http, leftMenuSelect, route, ref) {
        var _this = this;
        this.http = http;
        this.leftMenuSelect = leftMenuSelect;
        this.route = route;
        this.ref = ref;
        //页面数据
        this.model = {};
        this.powerList = [];
        this.ids = [];
        //设置左侧菜单选择
        this.leftMenuSelect.selected = 'Group';
        //获取权限列表
        this.http.post('/Admin/AdmGroup/GetAdmMenuSelect').then(function (body) {
            var res = window._.pairs(body.json());
            _this.powerList = window._.sortBy(res, 1);
        });
    }
    // 点击checkbox
    AdmGroupCreate.prototype.selectIds = function (id) {
        var index = this.ids.indexOf(id);
        if (index > -1) {
            this.ids.splice(index, 1);
        }
        else {
            this.ids.push(id);
        }
    };
    //表单提交
    AdmGroupCreate.prototype.onSubmit = function (pageForm) {
        //判断表单验证
        if (!pageForm.form.valid) {
            this.model.formInvalid = true;
            return;
        }
        //提交数据
        var postData = pageForm.form.value;
        postData.ids = this.ids;
        //发送请求
        this.http.post('/Admin/AdmGroup/Create', postData).then(function (body) {
            var res = body.json();
            if (res.result) {
                window.swal("保存成功", "", "success");
            }
            else {
                window.swal(res.errmsg ? res.errmsg : "保存失败，请重试...", "", "error");
            }
        });
    };
    AdmGroupCreate = __decorate([
        core_1.Component({
            selector: 'AdmGroupCreate',
            templateUrl: '../ng2-adm/app/AdmGroup/Form.html?v=' + window.versions,
        }), 
        __metadata('design:paramtypes', [HttpServices_1.HttpServices, DataServices_1.LeftMenuSelectServices, router_1.ActivatedRoute, core_1.ChangeDetectorRef])
    ], AdmGroupCreate);
    return AdmGroupCreate;
}());
exports.AdmGroupCreate = AdmGroupCreate;
//# sourceMappingURL=Create.js.map