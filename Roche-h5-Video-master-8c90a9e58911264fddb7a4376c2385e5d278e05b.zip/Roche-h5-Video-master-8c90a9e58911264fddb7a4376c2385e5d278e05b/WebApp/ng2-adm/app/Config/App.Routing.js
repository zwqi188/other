"use strict";
var router_1 = require('@angular/router');
//自定义页面
var Profile_1 = require('../Setting/Profile');
var Reset_1 = require('../Setting/Reset');
var List_1 = require('../Articles/List');
var Create_1 = require('../Articles/Create');
var Update_1 = require('../Articles/Update');
var List_2 = require('../AdmGroup/List');
var Create_2 = require('../AdmGroup/Create');
var Update_2 = require('../AdmGroup/Update');
var Login_1 = require('../AdmAccount/Login');
var List_3 = require('../AdmAccount/List');
var Create_3 = require('../AdmAccount/Create');
var Update_3 = require('../AdmAccount/Update');
var List_4 = require('../AdmMenu/List');
var Create_4 = require('../AdmMenu/Create');
var Update_4 = require('../AdmMenu/Update');
//路由
var appRoutes = [
    //默认
    { path: '', redirectTo: 'Setting/Profile', pathMatch: 'full' },
    //登陆
    { path: 'Login', component: Login_1.AdmAccountLogin },
    //个人设置
    { path: 'Setting/Profile', component: Profile_1.Profile },
    { path: 'Setting/Reset', component: Reset_1.Reset },
    //文章
    { path: 'Articles/List', component: List_1.ArticlesList },
    { path: 'Articles/Create', component: Create_1.ArticlesCreate },
    { path: 'Articles/Update/:id', component: Update_1.ArticlesUpdate },
    //管理员分组
    { path: 'Group/List', component: List_2.AdmGroupList },
    { path: 'Group/Create', component: Create_2.AdmGroupCreate },
    { path: 'Group/Update/:id', component: Update_2.AdmGroupUpdate },
    //管理员
    { path: 'Account/List', component: List_3.AdmAccountList },
    { path: 'Account/Create', component: Create_3.AdmAccountCreate },
    { path: 'Account/Update/:id', component: Update_3.AdmAccountUpdate },
    //权限菜单
    { path: 'Menu/List', component: List_4.AdmMenuList },
    { path: 'Menu/Create', component: Create_4.AdmMenuCreate },
    { path: 'Menu/Update/:id', component: Update_4.AdmMenuUpdate },
    //错误地址
    { path: '**', redirectTo: 'Setting/Profile' },
];
exports.RoutingModule = router_1.RouterModule.forRoot(appRoutes);
//# sourceMappingURL=App.Routing.js.map