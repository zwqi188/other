"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var platform_browser_1 = require('@angular/platform-browser');
var forms_1 = require('@angular/forms');
var http_1 = require('@angular/http');
//程序根入口
var App_Component_1 = require('./App.Component');
//自定义部件
var Header_1 = require('../Parts/Header');
var LeftMenu_1 = require('../Parts/LeftMenu');
var TableFooter_1 = require("../Parts/TableFooter");
//自定义服务
var HttpServices_1 = require('../Common/HttpServices');
var DataServices_1 = require('../Common/DataServices');
var TableServices_1 = require('../Common/TableServices');
var UEditorInputImage_1 = require('../Common/UEditorInputImage');
var UEditorInputAttachment_1 = require('../Common/UEditorInputAttachment');
var UEditorInputHtml_1 = require('../Common/UEditorInputHtml');
//自定义路由
var App_Routing_1 = require('./App.Routing');
//自定义页面
var Profile_1 = require('../Setting/Profile');
var Reset_1 = require('../Setting/Reset');
var List_1 = require('../Articles/List');
var Create_1 = require('../Articles/Create');
var Update_1 = require('../Articles/Update');
var List_2 = require('../AdmGroup/List');
var Create_2 = require('../AdmGroup/Create');
var Update_2 = require('../AdmGroup/Update');
var Login_1 = require('../AdmAccount/Login');
var List_3 = require('../AdmAccount/List');
var Create_3 = require('../AdmAccount/Create');
var Update_3 = require('../AdmAccount/Update');
var List_4 = require('../AdmMenu/List');
var Create_4 = require('../AdmMenu/Create');
var Update_4 = require('../AdmMenu/Update');
var AppModule = (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        core_1.NgModule({
            imports: [
                platform_browser_1.BrowserModule,
                forms_1.FormsModule,
                http_1.HttpModule,
                App_Routing_1.RoutingModule
            ],
            declarations: [
                App_Component_1.AppComponent,
                Header_1.PartsHeader,
                LeftMenu_1.PartsLeftMenu,
                TableFooter_1.TableFooter,
                UEditorInputImage_1.UEditorInputImage,
                UEditorInputAttachment_1.UEditorInputAttachment,
                UEditorInputHtml_1.UEditorInputHtml,
                Profile_1.Profile,
                Reset_1.Reset,
                List_1.ArticlesList,
                Create_1.ArticlesCreate,
                Update_1.ArticlesUpdate,
                List_2.AdmGroupList,
                Create_2.AdmGroupCreate,
                Update_2.AdmGroupUpdate,
                Login_1.AdmAccountLogin,
                List_3.AdmAccountList,
                Create_3.AdmAccountCreate,
                Update_3.AdmAccountUpdate,
                List_4.AdmMenuList,
                Create_4.AdmMenuCreate,
                Update_4.AdmMenuUpdate
            ],
            providers: [
                core_1.ChangeDetectorRef,
                HttpServices_1.HttpServices,
                DataServices_1.LeftMenuSelectServices,
                DataServices_1.MenuAccessServices,
                TableServices_1.TableServices
            ],
            bootstrap: [App_Component_1.AppComponent]
        }), 
        __metadata('design:paramtypes', [])
    ], AppModule);
    return AppModule;
}());
exports.AppModule = AppModule;
/*
 Copyright 2016 Google Inc. All Rights Reserved.
 Use of this source code is governed by an MIT-style license that
 can be found in the LICENSE file at http://angular.io/license
 */ 
//# sourceMappingURL=App.Module.js.map