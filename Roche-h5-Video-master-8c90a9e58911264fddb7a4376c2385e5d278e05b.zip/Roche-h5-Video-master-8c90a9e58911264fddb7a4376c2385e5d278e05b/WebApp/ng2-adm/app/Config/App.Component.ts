/**
 * Created by QingLiang.TAN on 2016/8/30.
 */
import {Component} from '@angular/core';

// 自定义服务
import {LeftMenuSelectServices, MenuAccessServices} from  '../Common/DataServices';


@Component({
    selector: 'my-app',
    template: `<parts-header></parts-header>
     <div [ngClass]="{'app-main':leftMenuSelect.selected!='Login','login-part vertical-center':leftMenuSelect.selected=='Login'}">
        <parts-leftmenu *ngIf="leftMenuSelect.selected && leftMenuSelect.selected!='Login'"></parts-leftmenu>
        <div class="app-content">
            <router-outlet></router-outlet>
        </div>
     </div>        
    `,
})
export class AppComponent {

    constructor(private leftMenuSelect:LeftMenuSelectServices) {
        console.log('new myApp')
    }

}

