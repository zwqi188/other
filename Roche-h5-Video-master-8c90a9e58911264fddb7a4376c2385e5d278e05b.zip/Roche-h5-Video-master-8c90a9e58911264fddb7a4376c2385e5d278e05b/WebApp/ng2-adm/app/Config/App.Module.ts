import {NgModule, ChangeDetectorRef}       from '@angular/core';
import {BrowserModule}  from '@angular/platform-browser';
import {FormsModule}    from '@angular/forms';
import {HttpModule}    from '@angular/http';

//程序根入口
import {AppComponent}  from './App.Component';

//自定义部件
import {PartsHeader} from '../Parts/Header';
import {PartsLeftMenu} from '../Parts/LeftMenu';
import {TableFooter} from "../Parts/TableFooter";

//自定义服务
import {HttpServices}   from '../Common/HttpServices';
import {LeftMenuSelectServices, MenuAccessServices} from  '../Common/DataServices';
import {TableServices} from  '../Common/TableServices';
import {UEditorInputImage} from '../Common/UEditorInputImage';
import {UEditorInputAttachment} from '../Common/UEditorInputAttachment';
import {UEditorInputHtml} from '../Common/UEditorInputHtml';


//自定义路由
import {RoutingModule} from './App.Routing';


//自定义页面
import {Profile} from  '../Setting/Profile';
import {Reset} from  '../Setting/Reset';
import {ArticlesList} from  '../Articles/List';
import {ArticlesCreate} from  '../Articles/Create';
import {ArticlesUpdate} from  '../Articles/Update';
import {AdmGroupList} from  '../AdmGroup/List';
import {AdmGroupCreate} from  '../AdmGroup/Create';
import {AdmGroupUpdate} from  '../AdmGroup/Update';
import {AdmAccountLogin} from  '../AdmAccount/Login';
import {AdmAccountList} from  '../AdmAccount/List';
import {AdmAccountCreate} from  '../AdmAccount/Create';
import {AdmAccountUpdate} from  '../AdmAccount/Update';
import {AdmMenuList} from  '../AdmMenu/List';
import {AdmMenuCreate} from  '../AdmMenu/Create';
import {AdmMenuUpdate} from  '../AdmMenu/Update';


@NgModule({
    imports: [
        BrowserModule,
        FormsModule,
        HttpModule,
        RoutingModule
    ],
    declarations: [
        AppComponent,
        PartsHeader,
        PartsLeftMenu,
        TableFooter,
        UEditorInputImage,
        UEditorInputAttachment,
        UEditorInputHtml,

        Profile,
        Reset,
        ArticlesList,
        ArticlesCreate,
        ArticlesUpdate,
        AdmGroupList,
        AdmGroupCreate,
        AdmGroupUpdate,
        AdmAccountLogin,
        AdmAccountList,
        AdmAccountCreate,
        AdmAccountUpdate,
        AdmMenuList,
        AdmMenuCreate,
        AdmMenuUpdate
    ],
    providers: [
        ChangeDetectorRef,
        HttpServices,
        LeftMenuSelectServices,
        MenuAccessServices,
        TableServices
    ],
    bootstrap: [AppComponent]
})
export class AppModule {
}


/*
 Copyright 2016 Google Inc. All Rights Reserved.
 Use of this source code is governed by an MIT-style license that
 can be found in the LICENSE file at http://angular.io/license
 */