/**
 * Created by QingLiang.TAN on 2016/8/30.
 */
import {ModuleWithProviders}  from '@angular/core';
import {Routes, RouterModule} from '@angular/router';


//自定义页面
import {Profile} from  '../Setting/Profile';
import {Reset} from  '../Setting/Reset';

import {ArticlesList} from  '../Articles/List';
import {ArticlesCreate} from  '../Articles/Create';
import {ArticlesUpdate} from  '../Articles/Update';

import {AdmGroupList} from  '../AdmGroup/List';
import {AdmGroupCreate} from  '../AdmGroup/Create';
import {AdmGroupUpdate} from  '../AdmGroup/Update';

import {AdmAccountLogin} from  '../AdmAccount/Login';
import {AdmAccountList} from  '../AdmAccount/List';
import {AdmAccountCreate} from  '../AdmAccount/Create';
import {AdmAccountUpdate} from  '../AdmAccount/Update';

import {AdmMenuList} from  '../AdmMenu/List';
import {AdmMenuCreate} from  '../AdmMenu/Create';
import {AdmMenuUpdate} from  '../AdmMenu/Update';

//路由
const appRoutes:Routes = [
    //默认
    {path: '', redirectTo: 'Setting/Profile', pathMatch: 'full'},

    //登陆
    {path: 'Login', component: AdmAccountLogin},

    //个人设置
    {path: 'Setting/Profile', component: Profile},
    {path: 'Setting/Reset', component: Reset},

    //文章
    {path: 'Articles/List', component: ArticlesList},
    {path: 'Articles/Create', component: ArticlesCreate},
    {path: 'Articles/Update/:id', component: ArticlesUpdate},

    //管理员分组
    {path: 'Group/List', component: AdmGroupList},
    {path: 'Group/Create', component: AdmGroupCreate},
    {path: 'Group/Update/:id', component: AdmGroupUpdate},

    //管理员
    {path: 'Account/List', component: AdmAccountList},
    {path: 'Account/Create', component: AdmAccountCreate},
    {path: 'Account/Update/:id', component: AdmAccountUpdate},

    //权限菜单
    {path: 'Menu/List', component: AdmMenuList},
    {path: 'Menu/Create', component: AdmMenuCreate},
    {path: 'Menu/Update/:id', component: AdmMenuUpdate},

    //错误地址
    {path: '**', redirectTo: 'Setting/Profile'},
];

export const RoutingModule:ModuleWithProviders = RouterModule.forRoot(appRoutes);