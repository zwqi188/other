/**
 * Created by QingLiang.TAN on 2016/9/5.
 */
import {Component, forwardRef, ChangeDetectorRef} from '@angular/core';
import {NG_VALUE_ACCESSOR, ControlValueAccessor} from '@angular/forms';

const nooptextarea = () => {
};

export const CUSTOM_INPUT_HTML_CONTROL_VALUE_ACCESSOR:any = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => UEditorInputHtml),
    multi: true
};

@Component({
    selector: 'ueditor-input-html',
    template: `
        <textarea [id]="id" style="width:100%;resize:none;" rows="3" readonly="readonly" [(ngModel)]="value" [name]="this.id"></textarea>              
        `,
    providers: [CUSTOM_INPUT_HTML_CONTROL_VALUE_ACCESSOR]
})
export class UEditorInputHtml implements ControlValueAccessor {


    //输入内容
    private id:string;
    public constructor(private ref:ChangeDetectorRef) {
        this.id = this.generateUUID(); //'editor' + (Date.now())
    }
    generateUUID() {
        var d = new Date().getTime();
        var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
        return uuid;
    };

    //The internal data model
    private innerValue:any = '';

    //Placeholders for the callbacks which are later providesd
    //by the Control Value Accessor
    private onTouchedCallback:() => void = nooptextarea;
    private onChangeCallback:(_:any) => void = nooptextarea;

    //get accessor
    get value():any {
        return this.innerValue;
    };

    //set accessor including call the onchange callback
    set value(v:any) {
        if (v !== this.innerValue) {
            this.innerValue = v;
            this.onChangeCallback(v);
        }
    }

    //Set touched on blur
    onBlur() {
        this.onTouchedCallback();
    }

    //From ControlValueAccessor interface
    writeValue(value:any) {
        if (value !== this.innerValue) {
            this.innerValue = value;
        }
    }

    //From ControlValueAccessor interface
    registerOnChange(fn:any) {
        this.onChangeCallback = fn;
    }

    //From ControlValueAccessor interface
    registerOnTouched(fn:any) {
        this.onTouchedCallback = fn;
    }

    //输入内容
    // private id:string = 'editor' + (Date.now());
    private config:any = {
        // isShow: false,
        initialFrameWidth: null,
        initialFrameHeight: 350,
        toolbars: [
            [
                'fullscreen', 'source', '|', 'undo', 'redo', 'bold', 'italic', 'underline', 'fontborder', 'strikethrough', 'superscript', 'subscript',
                'removeformat', 'formatmatch', 'autotypeset', 'blockquote', 'pasteplain', 'forecolor',
                'backcolor', 'insertorderedlist', 'insertunorderedlist', 'selectall', 'cleardoc',
                'fontfamily', 'fontsize', 'simpleupload', 'insertimage', 'emotion', /*'scrawl',*/
                /*'music',*/ 'insertvideo', 'insertaudio', 'attachment', /*'map',*/
                'rowspacingtop', 'rowspacingbottom', 'lineheight', 'link', 'unlink'
            ]
        ]
    };
    private editor:any = {};


    //页面内容加载完成
    ngAfterViewInit() {
        //初始化
        this.editor = window.UE.getEditor(this.id, this.config);
        this.editor.ready(res=> {
            this.editor.setContent(this.value || '');
        });
        //侦听文件上传，取上传文件列表中第一个上传的文件的路径
        this.editor.addListener("contentChange", (res=> {
            this.value = this.editor.getContent();
            this.onChangeCallback(this.value);
            this.ref.detectChanges();
        }));
    }

}