"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by QingLiang.TAN on 2016/8/1.
 */
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
require('rxjs/add/observable/throw');
require('rxjs/add/operator/catch');
require('rxjs/add/operator/debounceTime');
require('rxjs/add/operator/distinctUntilChanged');
require('rxjs/add/operator/map');
require('rxjs/add/operator/switchMap');
require('rxjs/add/operator/toPromise');
//自定义封装http请求服务
var HttpServices = (function () {
    function HttpServices(http) {
        this.http = http;
    }
    //http get请求
    HttpServices.prototype.get = function (url) {
        var headers = new http_1.Headers({
            'Content-Type': 'application/json;charset=utf-8'
        });
        return this.http.get(url, { headers: headers })
            .toPromise()
            .catch(this.handleError);
    };
    //http post请求
    HttpServices.prototype.post = function (url, data) {
        var headers = new http_1.Headers({
            'Content-Type': 'application/json;charset=utf-8'
        });
        return this.http.post(url, JSON.stringify(data), { headers: headers })
            .toPromise()
            .catch(this.handleError);
    };
    //错误请求
    HttpServices.prototype.handleError = function (error) {
        error._body = "{\"errmsg\":\"" + error.status + " " + error.statusText + "\"}";
        return error;
    };
    HttpServices = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_1.Http])
    ], HttpServices);
    return HttpServices;
}());
exports.HttpServices = HttpServices;
//# sourceMappingURL=HttpServices.js.map