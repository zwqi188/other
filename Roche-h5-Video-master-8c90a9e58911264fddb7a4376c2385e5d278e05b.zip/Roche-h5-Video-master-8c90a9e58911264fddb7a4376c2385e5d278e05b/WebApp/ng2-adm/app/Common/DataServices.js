"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by QingLiang.TAN on 2016/8/1.
 */
var core_1 = require('@angular/core');
// 自定义服务
var HttpServices_1 = require('../Common/HttpServices');
//页面左部导航选中服务
var LeftMenuSelectServices = (function () {
    function LeftMenuSelectServices() {
    }
    LeftMenuSelectServices = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], LeftMenuSelectServices);
    return LeftMenuSelectServices;
}());
exports.LeftMenuSelectServices = LeftMenuSelectServices;
//菜单权限
var MenuAccessServices = (function () {
    function MenuAccessServices(http, ref) {
        this.http = http;
        this.ref = ref;
        this.data = [];
        this.myAccess();
    }
    //判断是有否有此权限
    MenuAccessServices.prototype.isAccess = function (v) {
        var index = this.data.indexOf(v);
        return index > -1;
    };
    // 获取权限
    MenuAccessServices.prototype.myAccess = function () {
        var _this = this;
        // 请求用户权限数据
        this.http.post('/Admin/My/GetMyAccess').then(function (body) {
            var res = body.json();
            if (res.errmsg) {
                _this.data = [];
            }
            else {
                _this.data = body.json();
            }
        });
    };
    MenuAccessServices = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [HttpServices_1.HttpServices, core_1.ChangeDetectorRef])
    ], MenuAccessServices);
    return MenuAccessServices;
}());
exports.MenuAccessServices = MenuAccessServices;
//# sourceMappingURL=DataServices.js.map