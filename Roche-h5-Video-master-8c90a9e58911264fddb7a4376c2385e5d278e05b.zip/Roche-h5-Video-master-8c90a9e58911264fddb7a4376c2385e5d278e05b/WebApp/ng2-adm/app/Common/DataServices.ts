/**
 * Created by QingLiang.TAN on 2016/8/1.
 */
import {Component, Injectable, ChangeDetectorRef} from '@angular/core';

// 自定义服务
import {HttpServices} from  '../Common/HttpServices';

//页面左部导航选中服务
@Injectable()
export class LeftMenuSelectServices {
    public selected:string;
}


//菜单权限
@Injectable()
export class MenuAccessServices {
    private data:any = [];

    //判断是有否有此权限
    public isAccess(v) {
        let index = this.data.indexOf(v);
        return index > -1;
    }

    constructor(private http:HttpServices, private ref:ChangeDetectorRef) {
        this.myAccess();
    }

    // 获取权限
    public myAccess() {
        // 请求用户权限数据
        this.http.post('/Admin/My/GetMyAccess').then(body => {
            var res = body.json();
            if (res.errmsg) {
                this.data = [];
            } else {
                this.data = body.json();
            }
        });
    }


}