"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by QingLiang.TAN on 2016/8/4.
 */
var core_1 = require('@angular/core');
// 自定义服务
var HttpServices_1 = require('../Common/HttpServices');
//表格操作服务
var TableServices = (function () {
    function TableServices(http) {
        this.http = http;
        //接口地址
        this.url = { list: undefined, del: undefined, exp: undefined };
        //所有字段
        this.keys = [];
        //显示字段
        this.showKeys = [];
        //筛选字段
        this.searchKeys = [];
        //筛选条件
        this.searchWhere = {};
        //分页信息
        this.page = { pageIndex: 1, pageSize: 50, totalItemCount: undefined, totalPageCount: undefined, loading: true };
        //数据
        this.model = [];
        //显示标签
        this.showTag = undefined;
        //表格选项
        this.ids = [];
        //表格全选
        this.allSelected = false;
    }
    //设置表字段,搜索字段,显示字段  前2个参数必填
    TableServices.prototype.keysInit = function (keywords, searchkeywords, showkeywords) {
        this.keys = window._.pairs(keywords);
        if (arguments[2]) {
            this.showKeys = window._.keys(showkeywords);
        }
        else {
            this.showKeys = window._.keys(keywords);
        }
        this.searchKeys = window._.pairs(searchkeywords);
    };
    //点击标签(显示/关闭)
    TableServices.prototype.onClickTag = function (v) {
        event.preventDefault();
        event.stopPropagation();
        console.log(v);
        if (this.showTag == v) {
            this.showTag = null;
        }
        else {
            this.showTag = v;
        }
    };
    ;
    //点击显示字段
    TableServices.prototype.onClickShowKeys = function (v) {
        var index = this.showKeys.indexOf(v);
        if (index > -1) {
            this.showKeys.splice(index, 1);
        }
        else {
            this.showKeys.push(v);
        }
    };
    //判断是否显示字段
    TableServices.prototype.isShowKeys = function (v) {
        var index = this.showKeys.indexOf(v);
        return index > -1;
    };
    //点击排序字段
    TableServices.prototype.onClickOrder = function (v) {
        if (this.searchWhere.orderKey == v && this.searchWhere.orderDes == 1) {
            this.searchWhere.orderDes = 0;
        }
        else if (this.searchWhere.orderKey == v && this.searchWhere.orderDes == 0) {
            this.searchWhere.orderDes = 1;
        }
        else {
            this.searchWhere.orderKey = v;
            this.searchWhere.orderDes = 0;
        }
        this.goPage(1);
    };
    //排序字段显示样式
    TableServices.prototype.showOrderClass = function (v) {
        if (this.searchWhere.orderKey == v && this.searchWhere.orderDes == 1) {
            return 'up';
        }
        else if (this.searchWhere.orderKey == v && this.searchWhere.orderDes == 0) {
            return 'dowm';
        }
        else {
            return '';
        }
    };
    //表格选项选择
    TableServices.prototype.onClickIds = function (v) {
        var index = this.ids.indexOf(v);
        if (index > -1) {
            this.ids.splice(index, 1);
        }
        else {
            this.ids.push(v);
        }
    };
    ;
    //请求分页
    TableServices.prototype.goPage = function (index) {
        var _this = this;
        //判断请求页码是否正常
        if (index <= 0 || index > this.page.totalPageCount) {
            window.swal("请求页码错误", "", "error");
            return;
        }
        //判断请求地址是否为空
        if (!this.url.list) {
            return;
        }
        //添加请求页码参数
        if (index) {
            this.searchWhere.pageIndex = index;
        }
        //加载Load
        this.page.loading = true;
        this.model = [];
        // 请求数据
        this.http.post(this.url.list, this.searchWhere).then(function (body) {
            var res = body.json();
            if (res.errmsg) {
                window.swal(res.errmsg, "", "error");
                return;
            }
            // 数据
            _this.model = res.PageList;
            //表格选项
            _this.ids = [];
            //计算分页信息
            _this.computePage(res);
            //请求完数据回调
            _this.goPageCallBack(res);
        });
    };
    //请求分页数据回调----
    TableServices.prototype.goPageCallBack = function (res) {
    };
    //计算分页信息
    TableServices.prototype.computePage = function (res) {
        this.page = {
            pageIndex: res.PageIndex,
            pageSize: res.PageSize,
            totalItemCount: res.TotalItemCount,
            totalPageCount: (res.TotalItemCount % res.PageSize == 0 ? (res.TotalItemCount / res.PageSize == 0 ? 1 : res.TotalItemCount / res.PageSize) : Math.ceil(res.TotalItemCount / res.PageSize)),
            loading: false,
        };
    };
    //重置筛选
    TableServices.prototype.resetSearch = function () {
        this.searchWhere = {};
        this.goPage(1);
    };
    ;
    //表格全选择
    TableServices.prototype.onClickAll = function () {
        if (!this.allSelected) {
            for (var _i = 0, _a = this.model; _i < _a.length; _i++) {
                var item = _a[_i];
                this.ids.push(item.ID);
            }
        }
        else {
            this.ids = [];
        }
    };
    ;
    //删除数据
    TableServices.prototype.onClickDel = function () {
        var _this = this;
        //判断是否有选择删除项
        if (!this.ids.length) {
            return;
        }
        //判断删除数据地址
        if (!this.url.del) {
            return;
        }
        window.swal({
            title: "你确认要删除选定的数据吗？",
            text: "",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "确 认",
            cancelButtonText: "取 消",
            closeOnConfirm: false,
            closeOnCancel: true
        }, (function (isConfirm) {
            if (isConfirm) {
                // 请求数据
                _this.http.post(_this.url.del, { ids: _this.ids }).then(function (body) {
                    var res = body.json();
                    if (res.result) {
                        _this.goPage(1);
                        window.swal("删除成功", "", "success");
                    }
                    else if (res.errmsg) {
                        window.swal(res.errmsg, "", "error");
                    }
                    else {
                        window.swal("删除失败，请重试...", "", "error");
                    }
                });
            }
        }));
    };
    //导出数据
    TableServices.prototype.onClickExport = function () {
        //判断导出数据地址
        if (!this.url.exp) {
            return;
        }
        // 请求数据
        this.http.post(this.url.exp, this.searchWhere).then(function (body) {
            var res = body.json();
            if (res.result) {
                window.location.href = res.result;
            }
            else if (res.errmsg) {
                window.swal(res.errmsg, "", "error");
            }
            else {
                window.swal("导出失败，请重试...", "", "error");
            }
        });
    };
    TableServices = __decorate([
        core_1.Component({}), 
        __metadata('design:paramtypes', [HttpServices_1.HttpServices])
    ], TableServices);
    return TableServices;
}());
exports.TableServices = TableServices;
//# sourceMappingURL=TableServices.js.map