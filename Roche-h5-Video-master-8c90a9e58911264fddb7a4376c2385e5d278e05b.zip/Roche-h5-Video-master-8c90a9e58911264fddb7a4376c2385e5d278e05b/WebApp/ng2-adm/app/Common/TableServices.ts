/**
 * Created by QingLiang.TAN on 2016/8/4.
 */
import {Component} from '@angular/core';

// 自定义服务
import {HttpServices} from  '../Common/HttpServices';

//表格操作服务
@Component({})
export class TableServices {

    constructor(private http:HttpServices) {
    }

    //接口地址
    public url:any = {list: undefined, del: undefined, exp: undefined};

    //所有字段
    public keys:any = [];

    //显示字段
    private showKeys:any = [];

    //筛选字段
    public searchKeys:any = [];

    //筛选条件
    public searchWhere:any = {};

    //分页信息
    public page:any = {pageIndex: 1, pageSize: 50, totalItemCount: undefined, totalPageCount: undefined, loading: true};

    //数据
    public model:any = [];

    //显示标签
    public showTag:string = undefined;

    //设置表字段,搜索字段,显示字段  前2个参数必填
    public keysInit(keywords, searchkeywords, showkeywords) {
        this.keys = window._.pairs(keywords);
        if (arguments[2]) {
            this.showKeys = window._.keys(showkeywords);
        } else {
            this.showKeys = window._.keys(keywords);
        }
        this.searchKeys = window._.pairs(searchkeywords);
    }

    //点击标签(显示/关闭)
    public onClickTag(v) {
        event.preventDefault();
        event.stopPropagation();
        console.log(v);
        if (this.showTag == v) {
            this.showTag = null;
        } else {
            this.showTag = v;
        }
    };

    //点击显示字段
    public onClickShowKeys(v) {
        let index = this.showKeys.indexOf(v);
        if (index > -1) {
            this.showKeys.splice(index, 1)
        } else {
            this.showKeys.push(v);
        }
    }

    //判断是否显示字段
    public isShowKeys(v) {
        let index = this.showKeys.indexOf(v);
        return index > -1;
    }

    //点击排序字段
    public onClickOrder(v) {
        if (this.searchWhere.orderKey == v && this.searchWhere.orderDes == 1) {
            this.searchWhere.orderDes = 0;
        } else if (this.searchWhere.orderKey == v && this.searchWhere.orderDes == 0) {
            this.searchWhere.orderDes = 1;
        } else {
            this.searchWhere.orderKey = v;
            this.searchWhere.orderDes = 0;
        }
        this.goPage(1);
    }

    //排序字段显示样式
    public showOrderClass(v) {
        if (this.searchWhere.orderKey == v && this.searchWhere.orderDes == 1) {
            return 'up';
        } else if (this.searchWhere.orderKey == v && this.searchWhere.orderDes == 0) {
            return 'dowm';
        } else {
            return '';
        }
    }


    //表格选项
    public ids:any = [];
    //表格选项选择
    public onClickIds(v) {
        let index = this.ids.indexOf(v);
        if (index > -1) {
            this.ids.splice(index, 1)
        } else {
            this.ids.push(v);
        }
    };


    //请求分页
    public goPage(index) {
        //判断请求页码是否正常
        if (index <= 0 || index > this.page.totalPageCount) {
            window.swal("请求页码错误", "", "error");
            return;
        }

        //判断请求地址是否为空
        if (!this.url.list) {
            return;
        }

        //添加请求页码参数
        if (index) {
            this.searchWhere.pageIndex = index;
        }

        //加载Load
        this.page.loading = true;
        this.model = [];

        // 请求数据
        this.http.post(this.url.list, this.searchWhere).then(body => {
            var res = body.json();
            if (res.errmsg) {
                window.swal(res.errmsg, "", "error");
                return;
            }
            // 数据
            this.model = res.PageList;

            //表格选项
            this.ids = [];

            //计算分页信息
            this.computePage(res);

            //请求完数据回调
            this.goPageCallBack(res);
        });
    }

    //请求分页数据回调----
    public goPageCallBack(res) {

    }

    //计算分页信息
    public computePage(res) {
        this.page = {
            pageIndex: res.PageIndex,
            pageSize: res.PageSize,
            totalItemCount: res.TotalItemCount,
            totalPageCount: (res.TotalItemCount % res.PageSize == 0 ? (res.TotalItemCount / res.PageSize == 0 ? 1 : res.TotalItemCount / res.PageSize) : Math.ceil(res.TotalItemCount / res.PageSize)),
            loading: false,
        };
    }

    //重置筛选
    public resetSearch() {
        this.searchWhere = {};
        this.goPage(1);
    };

    //表格全选
    public allSelected:boolean = false;

    //表格全选择
    public onClickAll() {
        if (!this.allSelected) {
            for (let item of this.model) {
                this.ids.push(item.ID);
            }
        } else {
            this.ids = [];
        }
    };

    //删除数据
    public onClickDel() {
        //判断是否有选择删除项
        if (!this.ids.length) {
            return;
        }
        //判断删除数据地址
        if (!this.url.del) {
            return;
        }

        window.swal({
            title: "你确认要删除选定的数据吗？",
            text: "",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "确 认",
            cancelButtonText: "取 消",
            closeOnConfirm: false,
            closeOnCancel: true
        }, (isConfirm=> {
            if (isConfirm) {
                // 请求数据
                this.http.post(this.url.del, {ids: this.ids}).then(body => {
                    var res = body.json();
                    if (res.result) {
                        this.goPage(1);
                        window.swal("删除成功", "", "success");
                    } else if (res.errmsg) {
                        window.swal(res.errmsg, "", "error");
                    } else {
                        window.swal("删除失败，请重试...", "", "error");
                    }
                });
            }
        }));
    }


    //导出数据
    public onClickExport() {
        //判断导出数据地址
        if (!this.url.exp) {
            return;
        }

        // 请求数据
        this.http.post(this.url.exp, this.searchWhere).then(body => {
            var res = body.json();
            if (res.result) {
                window.location.href = res.result;
                // window.open(res.result);
            } else if (res.errmsg) {
                window.swal(res.errmsg, "", "error");
            } else {
                window.swal("导出失败，请重试...", "", "error");
            }
        });

    }
}