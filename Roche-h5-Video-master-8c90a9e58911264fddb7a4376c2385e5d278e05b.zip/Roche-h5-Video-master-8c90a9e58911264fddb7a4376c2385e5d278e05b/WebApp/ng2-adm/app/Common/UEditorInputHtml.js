"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by QingLiang.TAN on 2016/9/5.
 */
var core_1 = require('@angular/core');
var forms_1 = require('@angular/forms');
var nooptextarea = function () {
};
exports.CUSTOM_INPUT_HTML_CONTROL_VALUE_ACCESSOR = {
    provide: forms_1.NG_VALUE_ACCESSOR,
    useExisting: core_1.forwardRef(function () { return UEditorInputHtml; }),
    multi: true
};
var UEditorInputHtml = (function () {
    function UEditorInputHtml(ref) {
        this.ref = ref;
        //The internal data model
        this.innerValue = '';
        //Placeholders for the callbacks which are later providesd
        //by the Control Value Accessor
        this.onTouchedCallback = nooptextarea;
        this.onChangeCallback = nooptextarea;
        //输入内容
        // private id:string = 'editor' + (Date.now());
        this.config = {
            // isShow: false,
            initialFrameWidth: null,
            initialFrameHeight: 350,
            toolbars: [
                [
                    'fullscreen', 'source', '|', 'undo', 'redo', 'bold', 'italic', 'underline', 'fontborder', 'strikethrough', 'superscript', 'subscript',
                    'removeformat', 'formatmatch', 'autotypeset', 'blockquote', 'pasteplain', 'forecolor',
                    'backcolor', 'insertorderedlist', 'insertunorderedlist', 'selectall', 'cleardoc',
                    'fontfamily', 'fontsize', 'simpleupload', 'insertimage', 'emotion',
                    /*'music',*/ 'insertvideo', 'insertaudio', 'attachment',
                    'rowspacingtop', 'rowspacingbottom', 'lineheight', 'link', 'unlink'
                ]
            ]
        };
        this.editor = {};
        this.id = this.generateUUID(); //'editor' + (Date.now())
    }
    UEditorInputHtml.prototype.generateUUID = function () {
        var d = new Date().getTime();
        var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
        return uuid;
    };
    ;
    Object.defineProperty(UEditorInputHtml.prototype, "value", {
        //get accessor
        get: function () {
            return this.innerValue;
        },
        //set accessor including call the onchange callback
        set: function (v) {
            if (v !== this.innerValue) {
                this.innerValue = v;
                this.onChangeCallback(v);
            }
        },
        enumerable: true,
        configurable: true
    });
    ;
    //Set touched on blur
    UEditorInputHtml.prototype.onBlur = function () {
        this.onTouchedCallback();
    };
    //From ControlValueAccessor interface
    UEditorInputHtml.prototype.writeValue = function (value) {
        if (value !== this.innerValue) {
            this.innerValue = value;
        }
    };
    //From ControlValueAccessor interface
    UEditorInputHtml.prototype.registerOnChange = function (fn) {
        this.onChangeCallback = fn;
    };
    //From ControlValueAccessor interface
    UEditorInputHtml.prototype.registerOnTouched = function (fn) {
        this.onTouchedCallback = fn;
    };
    //页面内容加载完成
    UEditorInputHtml.prototype.ngAfterViewInit = function () {
        var _this = this;
        //初始化
        this.editor = window.UE.getEditor(this.id, this.config);
        this.editor.ready(function (res) {
            _this.editor.setContent(_this.value || '');
        });
        //侦听文件上传，取上传文件列表中第一个上传的文件的路径
        this.editor.addListener("contentChange", (function (res) {
            _this.value = _this.editor.getContent();
            _this.onChangeCallback(_this.value);
            _this.ref.detectChanges();
        }));
    };
    UEditorInputHtml = __decorate([
        core_1.Component({
            selector: 'ueditor-input-html',
            template: "\n        <textarea [id]=\"id\" style=\"width:100%;resize:none;\" rows=\"3\" readonly=\"readonly\" [(ngModel)]=\"value\" [name]=\"this.id\"></textarea>              \n        ",
            providers: [exports.CUSTOM_INPUT_HTML_CONTROL_VALUE_ACCESSOR]
        }), 
        __metadata('design:paramtypes', [core_1.ChangeDetectorRef])
    ], UEditorInputHtml);
    return UEditorInputHtml;
}());
exports.UEditorInputHtml = UEditorInputHtml;
//# sourceMappingURL=UEditorInputHtml.js.map