/**
 * Created by QingLiang.TAN on 2016/9/5.
 */
import {Component, forwardRef, ChangeDetectorRef} from '@angular/core';
import {NG_VALUE_ACCESSOR, ControlValueAccessor} from '@angular/forms';

const noopattachment = () => {
};

export const CUSTOM_INPUT_ATTACHMENT_CONTROL_VALUE_ACCESSOR:any = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => UEditorInputAttachment),
    multi: true
};

//上传附件
@Component({
    selector: 'ueditor-input-attachment',
    template: `
        <div class="input-group">
            <input type="text" class="form-control not-valid" [(ngModel)]="value" (blur)="onBlur()" [name]="this.id"/>
            <!--<span class="input-group-addon" *ngIf="value" (click)="onPreview(value)"><i class="fa fa-image"></i> 预览</span>-->
            <span class="input-group-addon">
                <span (click)="onClickOpen()" *ngIf="editor"><i class="fa fa-upload"></i>&nbsp;上传</span>
                <span style="width:1px;height:1px;position:relative;overflow:hidden;display:none;">
                    <textarea [id]="id" style="position:absolute;"></textarea>
                 </span>
            </span>
        </div>              
        `,
    providers: [CUSTOM_INPUT_ATTACHMENT_CONTROL_VALUE_ACCESSOR]
})
export class UEditorInputAttachment implements ControlValueAccessor {


    //输入内容
    private id:string;
    public constructor(private ref:ChangeDetectorRef) {
        this.id = this.generateUUID(); //'editor' + (Date.now())
    }
    generateUUID() {
        var d = new Date().getTime();
        var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
        return uuid;
    };

    //The internal data model
    private innerValue:any = '';

    //Placeholders for the callbacks which are later providesd
    //by the Control Value Accessor
    private onTouchedCallback:() => void = noopattachment;
    private onChangeCallback:(_:any) => void = noopattachment;

    //get accessor
    get value():any {
        return this.innerValue;
    };

    //set accessor including call the onchange callback
    set value(v:any) {
        if (v !== this.innerValue) {
            this.innerValue = v;
            this.onChangeCallback(v);
        }
    }

    //Set touched on blur
    onBlur() {
        this.onTouchedCallback();
    }

    //From ControlValueAccessor interface
    writeValue(value:any) {
        if (value !== this.innerValue) {
            this.innerValue = value;
        }
    }

    //From ControlValueAccessor interface
    registerOnChange(fn:any) {
        this.onChangeCallback = fn;
    }

    //From ControlValueAccessor interface
    registerOnTouched(fn:any) {
        this.onTouchedCallback = fn;
    }

    //输入内容
    // private id:string = 'editor' + (Date.now());
    private config:any = {
        // isShow: false,
        textarea: '',//不上传编辑器内容
        initialFrameWidth: null,
        initialFrameHeight: null,
        toolbars: [['attachment']]
    };
    private editor:any = {};


    //打开图片上传
    onClickOpen() {
        this.editor.getDialog("attachment").open();
    }


    //页面内容加载完成
    ngAfterViewInit() {
        // 初始化
        this.editor = window.UE.getEditor(this.id, this.config);
        //侦听文件上传，取上传文件列表中第一个上传的文件的路径
        this.editor.addListener('afterUpfile', ((res, filelist)=> {
            if (filelist && filelist.length) {
                this.value = filelist[0].url;
                this.onChangeCallback(this.value);
                this.ref.detectChanges();
            }
        }));
    }

}