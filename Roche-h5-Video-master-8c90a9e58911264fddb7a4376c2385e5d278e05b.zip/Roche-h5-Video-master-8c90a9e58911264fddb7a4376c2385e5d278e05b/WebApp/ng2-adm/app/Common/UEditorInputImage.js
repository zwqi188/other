"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/**
 * Created by QingLiang.TAN on 2016/9/5.
 */
var core_1 = require('@angular/core');
var forms_1 = require('@angular/forms');
var noop = function () {
};
exports.CUSTOM_INPUT_IMAGE_CONTROL_VALUE_ACCESSOR = {
    provide: forms_1.NG_VALUE_ACCESSOR,
    useExisting: core_1.forwardRef(function () { return UEditorInputImage; }),
    multi: true
};
var UEditorInputImage = (function () {
    function UEditorInputImage(ref) {
        this.ref = ref;
        //The internal data model
        this.innerValue = '';
        //Placeholders for the callbacks which are later providesd
        //by the Control Value Accessor
        this.onTouchedCallback = noop;
        this.onChangeCallback = noop;
        //输入内容
        // private id:string = 'editor' + (Date.now());
        this.config = {
            // isShow: false,
            textarea: '',
            initialFrameWidth: null,
            initialFrameHeight: null,
            toolbars: [['insertimage']]
        };
        this.editor = {};
        this.id = this.generateUUID(); //'editor' + (Date.now())
    }
    UEditorInputImage.prototype.generateUUID = function () {
        var d = new Date().getTime();
        var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = (d + Math.random() * 16) % 16 | 0;
            d = Math.floor(d / 16);
            return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
        return uuid;
    };
    ;
    Object.defineProperty(UEditorInputImage.prototype, "value", {
        //get accessor
        get: function () {
            return this.innerValue;
        },
        //set accessor including call the onchange callback
        set: function (v) {
            if (v !== this.innerValue) {
                this.innerValue = v;
                this.onChangeCallback(v);
            }
        },
        enumerable: true,
        configurable: true
    });
    ;
    //Set touched on blur
    UEditorInputImage.prototype.onBlur = function () {
        this.onTouchedCallback();
    };
    //From ControlValueAccessor interface
    UEditorInputImage.prototype.writeValue = function (value) {
        if (value !== this.innerValue) {
            this.innerValue = value;
        }
    };
    //From ControlValueAccessor interface
    UEditorInputImage.prototype.registerOnChange = function (fn) {
        this.onChangeCallback = fn;
    };
    //From ControlValueAccessor interface
    UEditorInputImage.prototype.registerOnTouched = function (fn) {
        this.onTouchedCallback = fn;
    };
    //预览图片
    UEditorInputImage.prototype.onPreview = function (img) {
        window.swal({
            title: '<img src=' + img + ' style="max-width:400px;min-height:150px;max-height:350px;" />',
            html: true,
            confirmButtonText: '关闭'
        });
    };
    //打开图片上传
    UEditorInputImage.prototype.onClickOpen = function () {
        this.editor.getDialog("insertimage").open();
    };
    //页面内容加载完成
    UEditorInputImage.prototype.ngAfterViewInit = function () {
        var _this = this;
        // 初始化
        this.editor = window.UE.getEditor(this.id, this.config);
        //侦听文件上传，取上传文件列表中第一个上传的文件的路径
        this.editor.addListener('beforeinsertimage', (function (res, images) {
            if (images && images.length) {
                _this.value = images[0].src;
                _this.onChangeCallback(_this.value);
                _this.ref.detectChanges();
            }
        }));
    };
    UEditorInputImage = __decorate([
        core_1.Component({
            selector: 'ueditor-input-image',
            template: "\n        <div class=\"input-group\">\n            <input type=\"text\" class=\"form-control not-valid\" [(ngModel)]=\"value\" (blur)=\"onBlur()\" [name]=\"this.id\"/>\n            <span class=\"input-group-addon\" *ngIf=\"value\" (click)=\"onPreview(value)\"><i class=\"fa fa-image\"></i> \u9884\u89C8</span>\n            <span class=\"input-group-addon\">\n                <span (click)=\"onClickOpen()\" *ngIf=\"editor\"><i class=\"fa fa-upload\"></i>&nbsp;\u4E0A\u4F20</span>\n                <span style=\"width:1px;height:1px;position:relative;overflow:hidden;display:none;\">\n                    <textarea [id]=\"id\" style=\"position:absolute;\"></textarea>\n                 </span>\n            </span>\n        </div>              \n        ",
            providers: [exports.CUSTOM_INPUT_IMAGE_CONTROL_VALUE_ACCESSOR]
        }), 
        __metadata('design:paramtypes', [core_1.ChangeDetectorRef])
    ], UEditorInputImage);
    return UEditorInputImage;
}());
exports.UEditorInputImage = UEditorInputImage;
//# sourceMappingURL=UEditorInputImage.js.map