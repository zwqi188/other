/**
 * Created by QingLiang.TAN on 2016/8/3.
 */
import {Component} from '@angular/core';

// 自定义服务
import {LeftMenuSelectServices, MenuAccessServices} from  '../Common/DataServices';
import {HttpServices} from  '../Common/HttpServices';
import {TableServices} from  '../Common/TableServices';


//管理员分组列表
@Component({
    selector: 'AdmMenuList',
    templateUrl: '../ng2-adm/app/AdmMenu/List.html?v=' + window.versions,

})
export class AdmMenuList {


    private table:TableServices;

    constructor(private leftMenuSelect:LeftMenuSelectServices, private menuAccess:MenuAccessServices, private http:HttpServices) {
        //设置左侧菜单选择
        this.leftMenuSelect.selected = 'Menu';

        //初始化表格服务类
        this.table = new TableServices(http);

        //设置接口地址
        this.table.url.list = '/admin/AdmMenu/List';
        this.table.url.del = '/admin/AdmMenu/Delete';
        this.table.url.exp = '/admin/AdmMenu/Export';

        //设置字段初始化
        this.table.keysInit({ID: '#', MenuName: '菜单名称', RouteName: '前端路由名', RouteUrl: '后端路由地址'},{MenuName: '菜单名称', RouteName: '前端路由名', RouteUrl: '后端路由地址'});


        //初始加载
        this.table.goPage(1);
    }


}


