//移动端
module.exports = require('./ng2-mob/webpack.config.js');

//后台PC端
// module.exports = require('./ng2-adm/webpack.config.js');