﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace eDoctor.SDK.WeChat.WebPage.Enum
{
    internal class WebOAuthAPIUrl
    {
        /// <summary>
        /// 服务器地址
        /// </summary>
        private const string _ServerUrl = "https://api.weixin.qq.com";
        /// <summary>
        /// 用户同意授权，获取code
        /// </summary>
        internal const string authorize = "https://open.weixin.qq.com/connect/oauth2/authorize";

        /// <summary>
        /// 网站应用授权登录-请求CODE
        /// </summary>
        internal const string qrconnect = "https://open.weixin.qq.com/connect/qrconnect";



        /// <summary>
        /// 通过code换取网页授权access_token
        /// </summary>
        internal const string access_token = _ServerUrl + "/sns/oauth2/access_token";
        /// <summary>
        /// 刷新access_token（如果需要）
        /// </summary>
        internal const string refresh_token = _ServerUrl + "/sns/oauth2/refresh_token";
        /// <summary>
        /// 拉取用户信息(需scope为 snsapi_userinfo)
        /// </summary>
        internal const string userinfo = _ServerUrl + "/sns/userinfo";
        /// <summary>
        /// 检验授权凭证（access_token）是否有效
        /// </summary>
        internal const string auth = _ServerUrl + "/sns/auth";
    }
}
