﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Script.Serialization;
using eDoctor.SDK.Http;

namespace eDoctor.SDK.WeChat.WebPage
{
    /// <summary>
    /// 微信网页OAuth所有接口方法调用 
    /// </summary>
    public class Call
    {
        /// <summary>
        /// 用户同意授权，获取code
        /// </summary>
        /// <param name="appid">公众号的唯一标识</param>
        /// <param name="redirect_uri">授权后重定向的回调链接地址，请使用urlencode对链接进行处理</param>
        /// <param name="state">重定向后会带上state参数，开发者可以填写a-zA-Z0-9的参数值</param>        
        /// <param name="scope">应用授权作用域，snsapi_base （不弹出授权页面，直接跳转，只能获取用户openid），snsapi_userinfo （弹出授权页面，可通过openid拿到昵称、性别、所在地。并且，即使在未关注的情况下，只要用户授权，也能获取其信息）</param>
        /// <param name="response_type">返回类型，请填写code</param>
        /// <returns></returns>
        public static string authorize(string appid, string redirect_uri, string state = "", string scope = "snsapi_base", string response_type = "code")
        {
            var req = new Http.HttpGet(Enum.WebOAuthAPIUrl.authorize);            
            req.Params.Add("appid", appid);
            req.Params.Add("redirect_uri", redirect_uri);
            req.Params.Add("response_type", response_type);
            req.Params.Add("scope", scope);
            req.Params.Add("state", state);

            return req.GetConstructedUri() + "#wechat_redirect";
        }
        /// <summary>
        /// 通过code换取网页授权access_token
        /// </summary>
        /// <param name="appid">公众号的唯一标识</param>
        /// <param name="appsecret">公众号的appsecret</param>
        /// <param name="code">填写第一步获取的code参数</param>
        /// <param name="grant_type">填写为authorization_code</param>
        /// <returns></returns>
        public static Response.WebToken access_token(string appid, string appsecret, string code, string grant_type = "authorization_code")
        {
            try
            {
                var req = new Http.HttpPost(Enum.WebOAuthAPIUrl.access_token);                
                req.Params.Add("appid", appid);
                req.Params.Add("secret", appsecret);
                req.Params.Add("code", code);
                req.Params.Add("grant_type", grant_type);
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls;
                var data = req.Request();
                var t = new JavaScriptSerializer().Deserialize<Response.WebToken>(data);

                System.Web.HttpCookie token = new System.Web.HttpCookie(appid + "-token");
                token.Value = t.access_token;
                token.Expires = DateTime.Now.AddSeconds(t.expires_in);
                System.Web.HttpContext.Current.Response.AppendCookie(token);

                System.Web.HttpCookie openid = new System.Web.HttpCookie(appid + "-openid");
                openid.Value = t.openid;
                openid.Expires = DateTime.Now.AddSeconds(t.expires_in);
                System.Web.HttpContext.Current.Response.AppendCookie(openid);


                return t;
            }
            catch (Exception ex)
            {
                throw new Exception("access_token:" + ex.Message);
                return null;
            }
        }
        /// <summary>
        /// 获取保存在cooke中的授权信息
        /// </summary>
        /// <returns></returns>
        public static Response.WebToken gettoken(string appid)
        {
            if (System.Web.HttpContext.Current.Request.Cookies[appid + "-token"] != null && !string.IsNullOrEmpty(System.Web.HttpContext.Current.Request.Cookies[appid + "-token"].Value) &&
                System.Web.HttpContext.Current.Request.Cookies[appid + "-openid"] != null && !string.IsNullOrEmpty(System.Web.HttpContext.Current.Request.Cookies[appid + "-openid"].Value))
            {
                return new Response.WebToken()
                {
                    access_token = System.Web.HttpContext.Current.Request.Cookies[appid + "-token"].Value,
                    openid = System.Web.HttpContext.Current.Request.Cookies[appid + "-openid"].Value,
                };
            }
            return null;
        }
        /// <summary>
        /// 拉取用户信息(需scope为 snsapi_userinfo)
        /// </summary>
        /// <param name="access_token">网页授权接口调用凭证,注意：此access_token与基础支持的access_token不同</param>
        /// <param name="openid">用户的唯一标识</param>
        /// <param name="lang">返回国家地区语言版本，zh_CN 简体，zh_TW 繁体，en 英语</param>
        /// <returns></returns>
        public static Response.WebUserinfo userinfo(string access_token, string openid, string lang = "zh_CN")
        {
            try
            {
                var req = new Http.HttpPost(Enum.WebOAuthAPIUrl.userinfo);
                req.Params.Add("access_token", access_token);
                req.Params.Add("openid", openid);
                req.Params.Add("lang", lang);
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls;
                var data = req.Request();
                //return data;
                return new JavaScriptSerializer().Deserialize<Response.WebUserinfo>(data);
            }
            catch (Exception ex)
            {
                //throw new Exception("access_token:" + ex.Message);
                return null;
            }
        }


        //开方平台
        /// <summary>
        /// 网站应用授权登录-请求CODE
        /// </summary>
        /// <param name="appid"></param>
        /// <param name="redirect_uri"></param>
        /// <param name="state"></param>
        /// <param name="scope"></param>
        /// <param name="response_type"></param>
        /// <returns></returns>
        public static string qrconnect(string appid, string redirect_uri, string state = "", string scope = "snsapi_login", string response_type = "code")
        {
            var req = new Http.HttpGet(Enum.WebOAuthAPIUrl.qrconnect);
            req.Params.Add("appid", appid);
            req.Params.Add("redirect_uri", redirect_uri);
            req.Params.Add("response_type", response_type);
            req.Params.Add("scope", scope);
            req.Params.Add("state", state);

            return req.GetConstructedUri() + "#wechat_redirect";
        }
    }
}
