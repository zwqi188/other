﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace webApp.Models
{
    public class AppConfig
    {
        public string AppID { set; get; }

        public string AppSecret { set; get; }
    }
}