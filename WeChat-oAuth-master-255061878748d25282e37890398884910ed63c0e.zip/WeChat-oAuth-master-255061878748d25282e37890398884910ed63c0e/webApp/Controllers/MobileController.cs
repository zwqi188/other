﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace webApp.Controllers
{
    /// <summary>
    /// 微信移动端
    /// </summary>
    public class MobileController : Controller
    {

        #region 属性

        /// <summary>
        /// 当前域名
        /// </summary>
        public string HostUrl
        {
            get
            {
                if (Request.Url.ToString().ToLower().IndexOf("https:") != -1)
                    return "https://" + Request.Url.Authority;
                else
                    return "http://" + Request.Url.Authority;
            }
        }

        /// <summary>
        /// 微信配置
        /// </summary>
        public Models.AppConfig Config
        {
            get
            {
                return new Models.AppConfig()
                {
                    AppID = System.Configuration.ConfigurationManager.AppSettings["AppID"].ToString(),
                    AppSecret = System.Configuration.ConfigurationManager.AppSettings["AppSecret"].ToString(),
                };
            }
        }

        #endregion

        /// <summary>
        /// 微信授权
        /// </summary>
        /// <param name="state">回调传递</param>
        /// <returns></returns>
        public ActionResult OAuth(string state)
        {
            return Redirect(eDoctor.SDK.WeChat.WebPage.Call.authorize(this.Config.AppID, this.HostUrl + "/Mobile/Authorize", state, "snsapi_userinfo"));
        }

        /// <summary>
        /// 微信授权
        /// </summary>
        /// <param name="callback"></param>
        /// <returns></returns>
        public ActionResult OAuth2(string callback)
        {
            return Redirect(eDoctor.SDK.WeChat.WebPage.Call.authorize(this.Config.AppID, this.HostUrl + "/Mobile/Authorize", "http://" + callback + (string.IsNullOrEmpty(Request.QueryString.ToString()) ? "" : ("?" + Request.QueryString.ToString())), "snsapi_userinfo"));
        }

        /// <summary>
        /// 微信授权回调
        /// </summary>
        /// <param name="code"></param>
        /// <param name="state"></param>
        /// <returns></returns>
        public ActionResult Authorize(string code, string state)
        {
            //获取微信Web token
            var webtoken = eDoctor.SDK.WeChat.WebPage.Call.access_token(this.Config.AppID, this.Config.AppSecret, code);


            if (!string.IsNullOrEmpty(webtoken.unionid))
            {
                //保存至数据库
                if (new Lib.UserInfo().Exist(webtoken.unionid))
                {
                    new Lib.UserInfo().UpdateMobileAuth(webtoken.unionid, webtoken.openid, webtoken.access_token, webtoken.expires_in);
                }
                else
                {
                    new Lib.UserInfo().CreateMobileAuth(webtoken.unionid, webtoken.openid, webtoken.access_token, webtoken.expires_in);
                }
            }


            //回跳至授权地址
            return Redirect(state + (state.IndexOf("?") < 0 ? "?" : "&") + "eid=" + webtoken.unionid);

        }

    }
}
