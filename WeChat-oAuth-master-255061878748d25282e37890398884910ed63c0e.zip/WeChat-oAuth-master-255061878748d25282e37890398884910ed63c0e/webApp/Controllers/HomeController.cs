﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace webApp.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return Redirect("https://git.edoctor.cn/qingliang.tan/WeChat-oAuth/blob/master/README.md");
            //return View();
        }

    }
}
