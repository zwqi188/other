﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace webApp.Controllers
{
    public class APIController : Controller
    {

        public ActionResult getuserinfo(string eid)
        {
            var user = new Lib.UserInfo().GetUserInfo(eid);

            if (user == null)
            {
                return Json(new Dictionary<string, string>() { { "errmsg", "eid错误" } }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(user, JsonRequestBehavior.AllowGet);
            }
        }

    }
}
