﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace webApp.Lib
{
    public class UserInfo
    {
        /// <summary>
        /// 判断eID，是否存在
        /// </summary>
        /// <param name="eid"></param>
        /// <returns></returns>
        public bool Exist(string eid)
        {
            var dt = new DbUtility.DBContext().ExecuteDataTableSql("SELECT 1 FROM [userinfo] where [eid]=@eid;", new List<System.Data.Common.DbParameter>()
            {
                new System.Data.SqlClient.SqlParameter("@eid",eid){SqlDbType=System.Data.SqlDbType.NVarChar},
            });

            return (dt.Rows.Count > 0);
        }

        /// <summary>
        /// 创建Mobile端微信授权
        /// </summary>
        /// <param name="eid"></param>
        /// <param name="m_openid"></param>
        /// <param name="access_token"></param>
        /// <param name="expires_in"></param>
        /// <returns></returns>
        public bool CreateMobileAuth(string eid, string m_openid, string access_token, int expires_in)
        {
            return new DbUtility.DBContext().ExecuteNonQuerySql(@"
                INSERT INTO [userinfo]
                    ([eid]
                    ,[m_openid]
                    ,[access_token]
                    ,[expires_in]
                    ,[oauth_type]
                    ,[is_userinfo]           
                    ,[create_date]
                    )
                VALUES
                    (@eid
                    ,@m_openid
                    ,@access_token
                    ,@expires_in
                    ,@oauth_type
                    ,0           
                    ,@create_date
                    )
            ", new List<System.Data.Common.DbParameter>()
            {
                 new System.Data.SqlClient.SqlParameter("@eid",eid),
                 new System.Data.SqlClient.SqlParameter("@m_openid",m_openid),
                 new System.Data.SqlClient.SqlParameter("@access_token",access_token),
                 new System.Data.SqlClient.SqlParameter("@expires_in",DateTime.Now.AddSeconds(expires_in)){SqlDbType=System.Data.SqlDbType.DateTime},
                 new System.Data.SqlClient.SqlParameter("@oauth_type","mobile"),
                 new System.Data.SqlClient.SqlParameter("@create_date",DateTime.Now){SqlDbType=System.Data.SqlDbType.DateTime},
            }) > 0;
        }

        /// <summary>
        /// 创建PC端微信授权
        /// </summary>
        /// <param name="eid"></param>
        /// <param name="p_openid"></param>
        /// <param name="access_token"></param>
        /// <param name="expires_in"></param>
        /// <returns></returns>
        public bool CreatePCAuth(string eid, string p_openid, string access_token, int expires_in)
        {
            return new DbUtility.DBContext().ExecuteNonQuerySql(@"
                INSERT INTO [userinfo]
                    ([eid]
                    ,[p_openid]
                    ,[access_token]
                    ,[expires_in]
                    ,[oauth_type]
                    ,[is_userinfo]           
                    ,[create_date]
                    )
                VALUES
                    (@eid
                    ,@p_openid
                    ,@access_token
                    ,@expires_in
                    ,@oauth_type
                    ,0           
                    ,@create_date
                    )
            ", new List<System.Data.Common.DbParameter>()
            {
                 new System.Data.SqlClient.SqlParameter("@eid",eid),
                 new System.Data.SqlClient.SqlParameter("@p_openid",p_openid),
                 new System.Data.SqlClient.SqlParameter("@access_token",access_token),
                 new System.Data.SqlClient.SqlParameter("@expires_in",DateTime.Now.AddSeconds(expires_in)){SqlDbType=System.Data.SqlDbType.DateTime},
                 new System.Data.SqlClient.SqlParameter("@oauth_type","pc"),
                 new System.Data.SqlClient.SqlParameter("@create_date",DateTime.Now){SqlDbType=System.Data.SqlDbType.DateTime},
            }) > 0;
        }

        /// <summary>
        /// 更新Mobile端微信授权
        /// </summary>
        /// <param name="eid"></param>
        /// <param name="m_openid"></param>
        /// <param name="access_token"></param>
        /// <param name="expires_in"></param>
        /// <returns></returns>
        public bool UpdateMobileAuth(string eid, string m_openid, string access_token, int expires_in)
        {
            return new DbUtility.DBContext().ExecuteNonQuerySql(@"
                UPDATE [userinfo] SET [m_openid]=@m_openid,[access_token]=@access_token,[expires_in]=@expires_in,[oauth_type]=@oauth_type,[update_date]=@update_date WHERE [eid]=@eid;
            ", new List<System.Data.Common.DbParameter>()
            {
                 new System.Data.SqlClient.SqlParameter("@eid",eid),
                 new System.Data.SqlClient.SqlParameter("@m_openid",m_openid),
                 new System.Data.SqlClient.SqlParameter("@access_token",access_token),
                 new System.Data.SqlClient.SqlParameter("@expires_in",DateTime.Now.AddSeconds(expires_in)){SqlDbType=System.Data.SqlDbType.DateTime},
                 new System.Data.SqlClient.SqlParameter("@oauth_type","mobile"),                 
                 new System.Data.SqlClient.SqlParameter("@update_date",DateTime.Now){SqlDbType=System.Data.SqlDbType.DateTime},
            }) > 0;
        }

        /// <summary>
        /// 更新PC端微信授权
        /// </summary>
        /// <param name="eid"></param>
        /// <param name="p_openid"></param>
        /// <param name="access_token"></param>
        /// <param name="expires_in"></param>
        /// <returns></returns>
        public bool UpdatePCAuth(string eid, string p_openid, string access_token, int expires_in)
        {
            return new DbUtility.DBContext().ExecuteNonQuerySql(@"
                UPDATE [userinfo] SET [p_openid]=@p_openid,[access_token]=@access_token,[expires_in]=@expires_in,[oauth_type]=@oauth_type,[update_date]=@update_date WHERE [eid]=@eid;
            ", new List<System.Data.Common.DbParameter>()
            {
                 new System.Data.SqlClient.SqlParameter("@eid",eid),
                 new System.Data.SqlClient.SqlParameter("@p_openid",p_openid),
                 new System.Data.SqlClient.SqlParameter("@access_token",access_token),
                 new System.Data.SqlClient.SqlParameter("@expires_in",DateTime.Now.AddSeconds(expires_in)){SqlDbType=System.Data.SqlDbType.DateTime},
                 new System.Data.SqlClient.SqlParameter("@oauth_type","pc"),
                 new System.Data.SqlClient.SqlParameter("@update_date",DateTime.Now){SqlDbType=System.Data.SqlDbType.DateTime},
            }) > 0;
        }

        /// <summary>
        /// 获取用户信息
        /// </summary>
        /// <param name="eid"></param>
        /// <returns></returns>
        public Respone.UserInfo GetUserInfo(string eid)
        {
            var dt = new DbUtility.DBContext().ExecuteDataTableSql("SELECT * FROM [userinfo] where [eid]=@eid;", new List<System.Data.Common.DbParameter>()
            {
                new System.Data.SqlClient.SqlParameter("@eid",eid){SqlDbType=System.Data.SqlDbType.NVarChar},
            });

            if (dt.Rows.Count < 1)
            {
                return null;
            }

            var row = dt.Rows[0];

            //判断是否已经完成信息获取
            if (row["is_userinfo"].ToString() == "0")
            {
                if (string.IsNullOrEmpty(row["expires_in"].ToString()) || Convert.ToDateTime(row["expires_in"]).CompareTo(DateTime.Now) <=0)
                {
                    return null;
                }

                string openid;
                if (row["oauth_type"].ToString() == "pc")
                {
                    openid = row["p_openid"].ToString();
                }
                else
                {
                    openid = row["m_openid"].ToString();
                }

                var u = eDoctor.SDK.WeChat.WebPage.Call.userinfo(row["access_token"].ToString(), openid);
                if (u == null)
                {
                    return null;
                }

                //保存至数据库
                if (this.CreateUserInfo(eid, u))
                {
                    return this.GetUserInfo(eid);
                }
                else
                {
                    return null;
                }


            }
            else
            {
                return new Respone.UserInfo()
                {
                    eid = eid,
                    nickname = row["nickname"].ToString(),
                    province = row["province"].ToString(),
                    city = row["city"].ToString(),
                    country = row["country"].ToString(),
                    sex = Convert.ToInt16(row["sex"]),
                    headimgurl = row["headimgurl"].ToString(),
                };
            }

        }

        /// <summary>
        /// 创建用户信息
        /// </summary>
        /// <param name="eid"></param>
        /// <param name="user"></param>
        /// <returns></returns>
        public bool CreateUserInfo(string eid, eDoctor.SDK.WeChat.WebPage.Response.WebUserinfo user)
        {
            return new DbUtility.DBContext().ExecuteNonQuerySql(@"
                UPDATE [userinfo] SET [nickname]=@nickname,[sex]=@sex,[province]=@province,[city]=@city,[country]=@country,[headimgurl]=@headimgurl,[is_userinfo]=1,[update_date]=@update_date WHERE [eid]=@eid;
            ", new List<System.Data.Common.DbParameter>()
            {
                 new System.Data.SqlClient.SqlParameter("@eid",eid),
                 new System.Data.SqlClient.SqlParameter("@nickname",user.nickname),
                 new System.Data.SqlClient.SqlParameter("@sex",user.sex),
                 new System.Data.SqlClient.SqlParameter("@province",user.province),
                 new System.Data.SqlClient.SqlParameter("@city",user.city),                 
                 new System.Data.SqlClient.SqlParameter("@country",user.country),       
                 new System.Data.SqlClient.SqlParameter("@headimgurl",user.headimgurl),       
                 new System.Data.SqlClient.SqlParameter("@update_date",DateTime.Now){SqlDbType=System.Data.SqlDbType.DateTime},
            }) > 0;
        }
    }
}