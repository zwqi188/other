﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Routing;

namespace webApp
{

    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();

            this.RegisterRoutes(RouteTable.Routes);
        }

        void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");


            routes.MapRoute(
                "MobileHttp",
                url: "mh/{*callback}",
                defaults: new { controller = "Mobile", action = "OAuth2" }
            );


            routes.MapRoute(
                "Mobile",
                url: "m/{action}",
                defaults: new { controller = "Mobile" }
            );


            routes.MapRoute(
                "PCWebHttp",
                url: "ph/{*callback}",
                defaults: new { controller = "PCWeb", action = "OAuth2" }
            );

            routes.MapRoute(
                "PCWeb",
                url: "p/{action}",
                defaults: new { controller = "PCWeb" }
            );


            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}",
                defaults: new { controller = "Home", action = "Index" }
            );
        }
    }
}