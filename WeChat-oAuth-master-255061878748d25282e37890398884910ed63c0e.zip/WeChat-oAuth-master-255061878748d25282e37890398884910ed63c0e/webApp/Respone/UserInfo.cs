﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace webApp.Respone
{
    public class UserInfo
    {
        public string eid { set; get; }

        public string nickname { set; get; }

        public int sex { set; get; }

        public string province { set; get; }

        public string city { set; get; }

        public string country { set; get; }

        public string headimgurl { set; get; }
    }
}