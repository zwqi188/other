#微信公众号登陆&授权平台

##1、微信移动客户端授权

###1.1、第一种接口方式

    地址： https://owx.vhdong.com/m/oauth?state=
    参数： /// <param name="state">回调地址（请URL编码）</param>
    请求实例：https://owx.vhdong.com/m/oauth?state=http%3a%2f%2fwww.baidu.com
    回调实例： https://www.baidu.com/?eid=oKCg7xD9NfpLTiBR_JPsCIj2ev4E



###1.2、第二种接口方式

    地址：https://owx.vhdong.com/mh/{*callback}
    参数：/// <param name="callback">回调地址（不带HTTP协议）</param>
    请求实例：https://owx.vhdong.com/mh/www.baidu.com
    回调实例： https://www.baidu.com/?eid=oKCg7xD9NfpLTiBR_JPsCIj2ev4E



##2、PC浏览器登陆

###2.1、第一种接口方式

    地址： https://owx.vhdong.com/p/oauth?state=
    参数： /// <param name="state">回调地址（请URL编码）</param>
    请求实例：https://owx.vhdong.com/p/oauth?state=http%3a%2f%2fwww.baidu.com
    回调实例： https://www.baidu.com/?eid=oKCg7xD9NfpLTiBR_JPsCIj2ev4E

###2.2、第二种接口方式

    地址：https://owx.vhdong.com/ph/{*callback}
    参数：/// <param name="callback">回调地址（不带HTTP协议）</param>
    请求实例：https://owx.vhdong.com/ph/www.baidu.com
    回调实例： https://www.baidu.com/?eid=oKCg7xD9NfpLTiBR_JPsCIj2ev4E


##3、获取微信用户信息

    地址：https://owx.vhdong.com/API/getuserinfo
    参数：/// <param name="eid">用户ID</param>
    正确返回（JSON）模型：
        public string eid { set; get; }
        public string nickname { set; get; }
        public int sex { set; get; }
        public string province { set; get; }
        public string city { set; get; }
        public string country { set; get; }
        public string headimgurl { set; get; }
    错误返回（JSON）模型：
        public string errmsg { set; get; }