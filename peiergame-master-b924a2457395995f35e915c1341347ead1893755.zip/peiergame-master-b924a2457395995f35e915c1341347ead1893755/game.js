(function (lib, img, cjs, ss, an) {

var p; // shortcut to reference prototypes
lib.webFontTxtInst = {}; 
var loadedTypekitCount = 0;
var loadedGoogleCount = 0;
var gFontsUpdateCacheList = [];
var tFontsUpdateCacheList = [];
lib.ssMetadata = [
		{name:"game_atlas_P_", frames: [[910,0,92,153],[0,0,892,901],[475,1373,196,68],[673,1432,205,41],[990,634,29,33],[956,634,28,33],[910,479,76,83],[910,396,88,81],[910,564,44,143],[894,789,73,78],[910,308,87,86],[910,709,78,78],[696,1248,185,182],[969,789,44,47],[0,1334,158,176],[554,903,354,343],[910,869,69,71],[363,1215,38,30],[981,838,39,34],[0,1215,361,117],[956,564,66,68],[910,155,91,151],[160,1373,313,88],[363,1248,331,123],[0,903,552,310]]},
		{name:"game_atlas_NP_", frames: [[0,0,640,1136],[642,0,640,1009]]}
];



lib.updateListCache = function (cacheList) {		
	for(var i = 0; i < cacheList.length; i++) {		
		if(cacheList[i].cacheCanvas)		
			cacheList[i].updateCache();		
	}		
};		

lib.addElementsToCache = function (textInst, cacheList) {		
	var cur = textInst;		
	while(cur != exportRoot) {		
		if(cacheList.indexOf(cur) != -1)		
			break;		
		cur = cur.parent;		
	}		
	if(cur != exportRoot) {		
		var cur2 = textInst;		
		var index = cacheList.indexOf(cur);		
		while(cur2 != cur) {		
			cacheList.splice(index, 0, cur2);		
			cur2 = cur2.parent;		
			index++;		
		}		
	}		
	else {		
		cur = textInst;		
		while(cur != exportRoot) {		
			cacheList.push(cur);		
			cur = cur.parent;		
		}		
	}		
};		

lib.gfontAvailable = function(family, totalGoogleCount) {		
	lib.properties.webfonts[family] = true;		
	var txtInst = lib.webFontTxtInst && lib.webFontTxtInst[family] || [];		
	for(var f = 0; f < txtInst.length; ++f)		
		lib.addElementsToCache(txtInst[f], gFontsUpdateCacheList);		

	loadedGoogleCount++;		
	if(loadedGoogleCount == totalGoogleCount) {		
		lib.updateListCache(gFontsUpdateCacheList);		
	}		
};		

lib.tfontAvailable = function(family, totalTypekitCount) {		
	lib.properties.webfonts[family] = true;		
	var txtInst = lib.webFontTxtInst && lib.webFontTxtInst[family] || [];		
	for(var f = 0; f < txtInst.length; ++f)		
		lib.addElementsToCache(txtInst[f], tFontsUpdateCacheList);		

	loadedTypekitCount++;		
	if(loadedTypekitCount == totalTypekitCount) {		
		lib.updateListCache(tFontsUpdateCacheList);		
	}		
};
// symbols:



(lib.bbs = function() {
	this.spriteSheet = ss["game_atlas_P_"];
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.dq = function() {
	this.spriteSheet = ss["game_atlas_P_"];
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.gameback = function() {
	this.spriteSheet = ss["game_atlas_NP_"];
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.jinbi = function() {
	this.spriteSheet = ss["game_atlas_P_"];
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.outtime = function() {
	this.spriteSheet = ss["game_atlas_P_"];
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.p1bg_02 = function() {
	this.spriteSheet = ss["game_atlas_NP_"];
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.pause = function() {
	this.spriteSheet = ss["game_atlas_P_"];
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.play = function() {
	this.spriteSheet = ss["game_atlas_P_"];
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.q1 = function() {
	this.spriteSheet = ss["game_atlas_P_"];
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.q2 = function() {
	this.spriteSheet = ss["game_atlas_P_"];
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.q3 = function() {
	this.spriteSheet = ss["game_atlas_P_"];
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.q4 = function() {
	this.spriteSheet = ss["game_atlas_P_"];
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.q5 = function() {
	this.spriteSheet = ss["game_atlas_P_"];
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.q6 = function() {
	this.spriteSheet = ss["game_atlas_P_"];
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.q7 = function() {
	this.spriteSheet = ss["game_atlas_P_"];
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.q8 = function() {
	this.spriteSheet = ss["game_atlas_P_"];
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.renwu = function() {
	this.spriteSheet = ss["game_atlas_P_"];
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.rwm = function() {
	this.spriteSheet = ss["game_atlas_P_"];
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.sound = function() {
	this.spriteSheet = ss["game_atlas_P_"];
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.sound_m1 = function() {
	this.spriteSheet = ss["game_atlas_P_"];
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.sound_m2 = function() {
	this.spriteSheet = ss["game_atlas_P_"];
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.startbtn = function() {
	this.spriteSheet = ss["game_atlas_P_"];
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.strt = function() {
	this.spriteSheet = ss["game_atlas_P_"];
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.texiao = function() {
	this.spriteSheet = ss["game_atlas_P_"];
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.timer = function() {
	this.spriteSheet = ss["game_atlas_P_"];
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.wz1 = function() {
	this.spriteSheet = ss["game_atlas_P_"];
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.wz2 = function() {
	this.spriteSheet = ss["game_atlas_P_"];
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.startbtn_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.startbtn();
	this.instance.parent = this;
	this.instance.setTransform(-180.5,-58.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A8MJJIAAyRMA4ZAAAIAASRg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance,p:{scaleX:1,scaleY:1,x:-180.5,y:-58.5}}]}).to({state:[{t:this.instance,p:{scaleX:0.95,scaleY:0.95,x:-171,y:-56}}]},2).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-180.5,-58.5,361,117);


(lib.q8_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.rotationNumber = 1;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// 图层 1
	this.instance = new lib.q8();
	this.instance.parent = this;
	this.instance.setTransform(-22,-23.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.q8_1, new cjs.Rectangle(-22,-23.5,44,47), null);


(lib.q7_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.rotationNumber = 1;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// 图层 1
	this.instance = new lib.q7();
	this.instance.parent = this;
	this.instance.setTransform(-92.5,-91);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.q7_1, new cjs.Rectangle(-92.5,-91,185,182), null);


(lib.q6_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.rotationNumber = 1;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// 图层 1
	this.instance = new lib.q6();
	this.instance.parent = this;
	this.instance.setTransform(-39,-39);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.q6_1, new cjs.Rectangle(-39,-39,78,78), null);


(lib.q5_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.rotationNumber = 1;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// 图层 1
	this.instance = new lib.q5();
	this.instance.parent = this;
	this.instance.setTransform(-43.5,-43);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.q5_1, new cjs.Rectangle(-43.5,-43,87,86), null);


(lib.q4_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.q4();
	this.instance.parent = this;
	this.instance.setTransform(-36.5,-39);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.q4_1, new cjs.Rectangle(-36.5,-39,73,78), null);


(lib.q3_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.rotationNumber = 0;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// 图层 1
	this.instance = new lib.q3();
	this.instance.parent = this;
	this.instance.setTransform(-22,-71.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.q3_1, new cjs.Rectangle(-22,-71.5,44,143), null);


(lib.q2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.rotationNumber = 1;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// 图层 1
	this.instance = new lib.q2();
	this.instance.parent = this;
	this.instance.setTransform(-44,-40.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.q2_1, new cjs.Rectangle(-44,-40.5,88,81), null);


(lib.q1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.rotationNumber = 1;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// 图层 1
	this.instance = new lib.q1();
	this.instance.parent = this;
	this.instance.setTransform(-38,-41.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.q1_1, new cjs.Rectangle(-38,-41.5,76,83), null);


(lib.outtimer = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(31));

	// 图层 2
	this.text = new cjs.Text("30s", "bold 22px 'Microsoft YaHei'", "#A40808");
	this.text.name = "text";
	this.text.textAlign = "center";
	this.text.lineHeight = 31;
	this.text.lineWidth = 38;
	this.text.parent = this;
	this.text.setTransform(-116.4,-15);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(31));

	// 图层 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_1 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_2 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_3 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_4 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_5 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_6 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_7 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_8 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_9 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_10 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_11 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_12 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_13 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_14 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_15 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_16 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_17 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_18 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_19 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_20 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_21 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_22 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_23 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_24 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_25 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_26 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_27 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_28 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_29 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");
	var mask_graphics_30 = new cjs.Graphics().p("AwSEYIAAovMAglAAAIAAIvg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:41.3,y:1.2}).wait(1).to({graphics:mask_graphics_1,x:41.3,y:1.2}).wait(1).to({graphics:mask_graphics_2,x:34.2,y:1.2}).wait(1).to({graphics:mask_graphics_3,x:27.1,y:1.2}).wait(1).to({graphics:mask_graphics_4,x:20,y:1.2}).wait(1).to({graphics:mask_graphics_5,x:12.9,y:1.2}).wait(1).to({graphics:mask_graphics_6,x:5.8,y:1.2}).wait(1).to({graphics:mask_graphics_7,x:-1.3,y:1.2}).wait(1).to({graphics:mask_graphics_8,x:-8.4,y:1.2}).wait(1).to({graphics:mask_graphics_9,x:-15.5,y:1.2}).wait(1).to({graphics:mask_graphics_10,x:-22.6,y:1.2}).wait(1).to({graphics:mask_graphics_11,x:-29.7,y:1.2}).wait(1).to({graphics:mask_graphics_12,x:-36.8,y:1.2}).wait(1).to({graphics:mask_graphics_13,x:-44,y:1.2}).wait(1).to({graphics:mask_graphics_14,x:-51.1,y:1.2}).wait(1).to({graphics:mask_graphics_15,x:-58.2,y:1.2}).wait(1).to({graphics:mask_graphics_16,x:-65.3,y:1.2}).wait(1).to({graphics:mask_graphics_17,x:-72.4,y:1.2}).wait(1).to({graphics:mask_graphics_18,x:-79.5,y:1.2}).wait(1).to({graphics:mask_graphics_19,x:-86.6,y:1.2}).wait(1).to({graphics:mask_graphics_20,x:-93.7,y:1.2}).wait(1).to({graphics:mask_graphics_21,x:-100.8,y:1.2}).wait(1).to({graphics:mask_graphics_22,x:-107.9,y:1.2}).wait(1).to({graphics:mask_graphics_23,x:-115,y:1.2}).wait(1).to({graphics:mask_graphics_24,x:-122.1,y:1.2}).wait(1).to({graphics:mask_graphics_25,x:-129.2,y:1.2}).wait(1).to({graphics:mask_graphics_26,x:-136.3,y:1.2}).wait(1).to({graphics:mask_graphics_27,x:-143.5,y:1.2}).wait(1).to({graphics:mask_graphics_28,x:-150.6,y:1.2}).wait(1).to({graphics:mask_graphics_29,x:-157.7,y:1.2}).wait(1).to({graphics:mask_graphics_30,x:-164.8,y:1.2}).wait(1));

	// outtime.png
	this.instance = new lib.outtime();
	this.instance.parent = this;
	this.instance.setTransform(-60.5,-20);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(31));

	// timer.png
	this.instance_1 = new lib.timer();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-156.5,-44);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(31));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-156.5,-44,313,88);


(lib.gamestage = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = getMCSymbolPrototype(lib.gamestage, null, null);


(lib.元件15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.strt();
	this.instance.parent = this;
	this.instance.setTransform(-33,-34);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-33,-34,66,68);


(lib.元件14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.renwu();
	this.instance.parent = this;
	this.instance.setTransform(-79,-88);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79,-88,158,176);


(lib.元件13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.texiao();
	this.instance.parent = this;
	this.instance.setTransform(-45.5,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-45.5,0,91,151);


(lib.元件10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 2
	this.score = new cjs.Text("0", "bold 30px 'Cambria'", "#FFFFFF");
	this.score.name = "score";
	this.score.textAlign = "center";
	this.score.lineHeight = 37;
	this.score.lineWidth = 109;
	this.score.parent = this;
	this.score.setTransform(130.5,22);

	this.timeline.addTween(cjs.Tween.get(this.score).wait(1));

	// 图层 1
	this.instance = new lib.jinbi();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.元件10, new cjs.Rectangle(0,0,196,68), null);


(lib.元件8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.sound();
	this.instance.parent = this;
	this.instance.setTransform(-34.5,-35.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({scaleX:0.95,scaleY:0.95,x:-33,y:-34},0).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.5,-35.5,69,71);


(lib.元件7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.rwm();
	this.instance.parent = this;
	this.instance.setTransform(-187.5,-171.5);

	this.instance_1 = new lib.bbs();
	this.instance_1.parent = this;
	this.instance_1.setTransform(95.5,-91.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-187.5,-171.5,375,343);


(lib.元件6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.wz1();
	this.instance.parent = this;
	this.instance.setTransform(-165.5,-61.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-165.5,-61.5,331,123);


(lib.元件5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.wz2();
	this.instance.parent = this;
	this.instance.setTransform(-276,-155);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-276,-155,552,310);


(lib.元件2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.dq();
	this.instance.parent = this;
	this.instance.setTransform(-446,-450.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-446,-450.5,892,901);


(lib.soundView = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var _self = this;
		_self.addEventListener("click",check);
		
		function check(e)
		{
			_self.gotoAndStop(_self.currentFrame==1?2:1);
			
			
			soundControl(_self.currentFrame==2?false:true);
		}
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(2));

	// sound_m2.png
	this.instance = new lib.sound_m2();
	this.instance.parent = this;
	this.instance.setTransform(-19,-19);

	this.instance_1 = new lib.sound_m1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-19,-16);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},2).wait(1));

	// 元件 8
	this.instance_2 = new lib.元件8();
	this.instance_2.parent = this;
	new cjs.ButtonHelper(this.instance_2, 0, 1, 2, false, new lib.元件8(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.5,-35.5,69,71);


(lib.playpuase = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var _self = this;
		_self.addEventListener("click",check);
		
		function check(e)
		{
			_self.gotoAndStop(_self.currentFrame==1?2:1);
			
			if(_self.currentFrame==2)
			{
				pauseGame();
			}else{
				startGame();
			}
			
		}
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(2));

	// pause.png
	this.instance = new lib.pause();
	this.instance.parent = this;
	this.instance.setTransform(-14.2,-16);

	this.instance_1 = new lib.play();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-13,-16);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},2).wait(1));

	// 元件 8
	this.instance_2 = new lib.元件8();
	this.instance_2.parent = this;
	new cjs.ButtonHelper(this.instance_2, 0, 1, 2, false, new lib.元件8(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.5,-35.5,69,71);


(lib.jiafen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		playSound("ascore");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(30));

	// 图层 1
	this.instance = new lib.元件15("synched",0);
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({rotation:360},29).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-33,-34,66,68);


(lib.元件12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(25));

	// 图层 1
	this.instance = new lib.元件13("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0,15.5,0.473,0.473,0,0,0,0,75.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({scaleX:1,scaleY:1,y:75.5},9,cjs.Ease.get(1)).to({regY:75.4,scaleY:1.23,y:101.9,alpha:0},14,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.元件11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.元件14("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0,88);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:94},29).to({y:88},30).wait(1));

	// 图层 2
	this.instance_1 = new lib.元件12();
	this.instance_1.parent = this;
	this.instance_1.setTransform(11.5,215.5,1,1,0,0,0,0,75.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(60));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79,0,158,176);


(lib.元件9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.timer = new lib.outtimer();
	this.timer.parent = this;
	this.timer.setTransform(3.5,-44);

	this.rightbtn = new lib.playpuase();
	this.rightbtn.parent = this;
	this.rightbtn.setTransform(254,-42.5);

	this.instance = new lib.soundView();
	this.instance.parent = this;
	this.instance.setTransform(-254,-42.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.rightbtn},{t:this.timer}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.元件9, new cjs.Rectangle(-288.5,-88,577,88), null);


(lib.元件4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// wz1.png
	this.instance = new lib.元件6("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-477.1,110.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(21).to({_off:false},0).to({x:-111},20,cjs.Ease.get(1)).wait(12));

	// 元件 5
	this.instance_1 = new lib.元件5("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(241.6,-17,0.458,0.458,0,0,0,241.1,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regY:-0.1,scaleX:1,scaleY:1},24,cjs.Ease.get(1)).wait(29));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(4.9,-87.9,252.7,141.9);


(lib.元件3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.元件7("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0.5,96.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:0.95,scaleY:0.95},9,cjs.Ease.get(1)).to({scaleX:1,scaleY:1},10,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-187,-74.9,375,343);


(lib.元件1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 图层 1
	this.instance = new lib.元件2("synched",0);
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({rotation:360},799).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-446,-450.5,892,901);


(lib.page1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.note.y = window.innerHeight*0.5;
	}
	this.frame_65 = function() {
		this.stop();
		
		
		var _self = this;
		
		this.startbtn.addEventListener("click",playGame);
		
		function playGame()
		{
			_self.parent.gotoAndStop(2);
		}
		this.startbtn.y = window.innerHeight;
		this.startbtn.alpha =0;
		createjs.Tween.get(this.startbtn).to({y:window.innerHeight-110,alpha:1},200,cjs.Ease.get(1));
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(65).call(this.frame_65).wait(1));

	// wz1.png
	this.instance = new lib.元件4("synched",0,false);
	this.instance.parent = this;
	this.instance.setTransform(325,207);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(66));

	// startbtn.png
	this.startbtn = new lib.startbtn_1();
	this.startbtn.parent = this;
	this.startbtn.setTransform(320,889.5);
	this.startbtn._off = true;
	new cjs.ButtonHelper(this.startbtn, 0, 1, 2, false, new lib.startbtn_1(), 3);

	this.timeline.addTween(cjs.Tween.get(this.startbtn).wait(65).to({_off:false},0).wait(1));

	// rwm.png
	this.note = new lib.元件3();
	this.note.parent = this;
	this.note.setTransform(320,504.5);

	this.timeline.addTween(cjs.Tween.get(this.note).wait(66));

	// dq.png
	this.xqview = new lib.元件1();
	this.xqview.parent = this;
	this.xqview.setTransform(330,1280);

	this.timeline.addTween(cjs.Tween.get(this.xqview).wait(19).to({y:1188},43,cjs.Ease.get(1)).wait(4));

	// p1bg_02.jpg
	this.instance_1 = new lib.p1bg_02();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(66));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-116,0,892,1730.5);


(lib.gameview = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var _self = this;
		
		_self.endview.y = window.innerHeight - 32;
		
		
		var gameview = _self.gameview;
		var yhyview = _self.yhyview;
		yhyview.width = yhyview.nominalBounds.width;
		yhyview.height = yhyview.nominalBounds.height;
		
		var renY = window.innerHeight - 320;
		
		cjs.Tween.get(_self.xqview).wait(500).to({
			y: window.innerHeight + 220,
			alpha: 1
		}, 1000, cjs.Ease.get(1));
		
		
		_self.yhyview.y = window.innerHeight+200;
		cjs.Tween.get(_self.yhyview).wait(500).to({
			y: renY
		}, 1000, cjs.Ease.get(1));
		
		
		var isPlayGame = false;
		
		var ClothingArray;
		//添加杂物的速度
		var EnemySpeed;
		var upPaddV = EnemySpeed-2;
		
		//不同得分
		var GameScoreArray = [1, 1, 1, 1,1,1,0,1];
		//最小移动速度
		var GameStartSpeed;
		//最大随机移动速度
		var GameMaxSpeed;
		//添加炸弹的概率
		var YFMAX;
		//多少余数添加一个炸弹概率
		var BOMRemainder = 30;
		var GameTime,startTimer,GameTimeCache;
		//重力
		var Gravity = 0.09;
		var GravitySpeed = 0.04;
		
		var GameScore;
		function initConfig()
		{
			CacheEnemySpeed = EnemySpeed= 36;
			upPaddV = EnemySpeed-20;
			GameTime = GameTimeCache = 30;
			CacheYFMAX = YFMAX = GameScoreArray.length;
			CacheGameStartSpeed=GameStartSpeed = 6;
			CacheGameMaxSpeed = GameMaxSpeed = 8;
			ClothingArray=[];
			GameScore = 0;
			
			QLength = 0;
		}
		initConfig();
		
		
		
		
		startGame = function () 
		{
			startTimer = (new Date()).getTime();
			stage.addEventListener("tick", tickGame);
			
			isPlayGame = true;
		}
		startGame();
		pauseGame = function (overBool) {
		
			stage.removeEventListener("tick", tickGame);
			
			if (typeof overBool != "boolean") {
				GameTime = GameTime - (((new Date()).getTime() - startTimer) / 1000 ^ 0);
			}
			isPlayGame = false;
		}
		overGame = function () {
			pauseGame(true);
			
			openOverGame(GameScore);
		}
		
		
		///
		stage.addEventListener("mousedown",stagedown);
		function stagedown(e)
		{
			stage.addEventListener("pressmove",stagemove);
			stage.addEventListener("mouseup",stageup);
		}
		function stageup(e)
		{
			stage.removeEventListener("pressmove",stagemove);
			stage.removeEventListener("mouseup",stageup);
		}
		
		function stagemove(e)
		{
			if(isPlayGame&&_self.yhyview.y==renY)
			{
				cjs.Tween.removeTweens(_self.yhyview);
				cjs.Tween.get(_self.yhyview).to({
					x: e.stageX
				}, 200);
			}
		}
		
		
		function tickGame(evt) {
		
			var outTimer = GameTime - (((new Date()).getTime() - startTimer) / 1000 ^ 0);
			//gameScore.timetxt.text = "TIME:" + outTimer + "s";
			_self.endview.timer.gotoAndStop(Math.abs(GameTimeCache-outTimer));
			_self.endview.timer.text.text = outTimer+"s";
			
			if(outTimer==0)
			{
				overGame();
			}
			
			
			if (++upPaddV % EnemySpeed == 0) {
				upPaddV = 0;
				addClothingView();
			}
			
			if (ClothingArray.length) {
				for (i = 0; i < ClothingArray.length; i++) {
		
					var getMc = ClothingArray[i];
					
					//getMc.rotation +=getMc.rotationNumber;			
					getMc.y += getMc.speed+(++getMc.gravity*GravitySpeed);
					
					
					
					if(getMc.y+getMc.height*0.5>yhyview.y && getMc.y+getMc.height<yhyview.y+yhyview.height)
					{
						if (getMc.x + getMc.width*0.5 > yhyview.x-yhyview.width*0.5 && getMc.x-getMc.width*0.5 < yhyview.x + yhyview.width * .5) {
							
							getMc.parent.removeChild(getMc);
							ClothingArray.splice(i, 1);
							///
							GameScore += getMc.score;
							tickScore();
		
							if(getMc.score>0)
							{
								addTXfen();
							}
							
							if(getMc.score==0)
							{
								pauseGame();
								openQuestion();
							}
						}
					}
					
					if (getMc.y > lib.properties.height + 200) {
						getMc.parent.removeChild(getMc);
						ClothingArray.splice(i, 1);
					}
					
				}
			}
		}
		function addTXfen()
		{
			var tx = new lib['jiafen'];
			_self.addChild(tx);
			tx.x = yhyview.x;
			tx.y = yhyview.y;
			
			cjs.Tween.get(tx).to({
				y: 50,x:60
			}, 500, cjs.Ease.get(1)).call(handleComplete,[tx]);	
		}
		function handleComplete(value)
		{
			value.parent.removeChild(value);
		}
		
		function tickScore() {
			GameScore = GameScore<0?0:GameScore;
			
			/////////////////////////////////////////////////////////////
			var yS = GameScore/BOMRemainder^0;
			YFMAX = CacheYFMAX+ yS*2;
			GameMaxSpeed = CacheGameMaxSpeed + yS*2;
			//GameStartSpeed = CacheGameStartSpeed+yS;
			EnemySpeed = CacheEnemySpeed-yS*3;
			EnemySpeed = EnemySpeed<20?20:EnemySpeed;
			GameMaxSpeed = GameMaxSpeed>20?20:GameMaxSpeed;
			////
			//root.FpsText.text = yS+"---"+(YFMAX-8);
			/////////////////////////////////////////////////////////////////
			_self.scoreview.score.text = GameScore;
			console.log("GameScore:"+GameScore+"   GameMaxSpeed:"+GameMaxSpeed);
			
		}
		
		addScore = function(value)
		{
			GameScore += value;
			tickScore();
		}
		
		function randRange(min, max) {
			var randomNum = Math.floor(Math.random() * (max - min + 1)) + min;
			return randomNum;
		}
		
		function addClothingView() {
			var RNumber = randRange(1, YFMAX);
			
			//root.FpsText.text = "YFMAX:"+YFMAX+"  -- RNumber:"+RNumber;
			
			RNumber = RNumber>GameScoreArray.length?GameScoreArray.length:RNumber;
			
			if("q" + RNumber=="q7"){
				QLength++;	
				if(QLength>3)return;
			}
			
			var clothimgObject = lib["q" + RNumber];
			
			var yfView = new clothimgObject();
			
		
			yfView.rotationNumber = RNumber==3?0:randRange(-4,4);
			
			yfView.y = -yfView.getBounds().height;
			var width_2 = yfView.getBounds().width;
			yfView.x = randRange(0, lib.properties.width - width_2);
			
			yfView.speed = randRange(0, GameMaxSpeed) + GameStartSpeed;
			var xsNumber = ((YFMAX-(GameScoreArray.length-1))*0.5);
			xsNumber = xsNumber<1?1:xsNumber;
			yfView.score = Number(GameScoreArray[Number(RNumber) - 1]);
			yfView.gravity = Gravity;
			
			yfView.width = yfView.getBounds().width;
			yfView.height = yfView.getBounds().height;
			
			yfView.type = RNumber;
		
			//yfView.cache(0,0,yfView.width,yfView.height);
		
			ClothingArray.push(yfView);
			
			gameview.addChild(yfView);
			//root.gameview.addChildAt(yfView, 0);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// 图层 4
	this.yhyview = new lib.元件11();
	this.yhyview.parent = this;
	this.yhyview.setTransform(320,644.2,1,1,0,0,0,0,88);

	this.timeline.addTween(cjs.Tween.get(this.yhyview).wait(1));

	// 图层 2
	this.scoreview = new lib.元件10();
	this.scoreview.parent = this;
	this.scoreview.setTransform(130,66,1,1,0,0,0,98,34);

	this.endview = new lib.元件9();
	this.endview.parent = this;
	this.endview.setTransform(320,977);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.endview},{t:this.scoreview}]}).wait(1));

	// 图层 6
	this.gameview = new lib.gamestage();
	this.gameview.parent = this;
	this.gameview.setTransform(24,24,1,1,0,0,0,24,24);

	this.timeline.addTween(cjs.Tween.get(this.gameview).wait(1));

	// 图层 1
	this.xqview = new lib.元件1();
	this.xqview.parent = this;
	this.xqview.setTransform(330,1188);

	this.instance = new lib.gameback();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1,1.144);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.xqview}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.gameview, new cjs.Rectangle(-116,0,1038,1638.5), null);


// stage content:
(lib.game = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		
		AndroidScaleY = isAndroid?(1009-window.innerHeight):0;
	}
	this.frame_2 = function() {
		playBackSound("sounds/game.mp3");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2).call(this.frame_2).wait(1));

	// 图层 1
	this.instance = new lib.page1();
	this.instance.parent = this;
	this.instance.setTransform(36,36,1,1,0,0,0,36,36);

	this.instance_1 = new lib.gameview();
	this.instance_1.parent = this;
	this.instance_1.setTransform(320,568,1,1,0,0,0,320,568);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[]},1).to({state:[{t:this.instance_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(204,504.5,892,1730.5);
// library properties:
lib.properties = {
	width: 640,
	height: 1009,
	fps: 60,
	color: "#FFFFFF",
	opacity: 1.00,
	webfonts: {},
	manifest: [
		{src:"images/game_atlas_P_.png", id:"game_atlas_P_"},
		{src:"images/game_atlas_NP_.jpg", id:"game_atlas_NP_"},
		{src:"sounds/ascore.mp3", id:"ascore"}
	],
	preloads: []
};




})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{}, AdobeAn = AdobeAn||{});
var lib, images, createjs, ss, AdobeAn;