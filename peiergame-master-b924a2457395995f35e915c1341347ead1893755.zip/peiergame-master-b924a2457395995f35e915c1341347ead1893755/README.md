PeiErGame-HTML5

安装地址：http://oauth.wechat.vhdong.com/mh/h5.dsn.ecloudmt.com/game/pe/

VERSION【当前最新版本】

```
Version 1.0:
完成游戏
```



