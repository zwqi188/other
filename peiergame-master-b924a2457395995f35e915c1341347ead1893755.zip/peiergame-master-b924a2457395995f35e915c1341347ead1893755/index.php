<?php
/**
 * Created by PhpStorm.
 * User: rayle
 * Date: 2017/02/27
 * Time: 17:23
 */

include_once 'config.php';


session_start();
date_default_timezone_set('Asia/Shanghai');
//if (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') === true) {
//{
    try{
        $pdo=new PDO(DB_DSN,DB_USER,DB_PASS);
    }catch(PDOException $e){
        echo '数据库连接失败'.$e->getMessage();
    }
    function insert($table,$arrData) {
        global $pdo;
        $name = $values = '';
        $flag = $flagV = 1;
        $true = is_array( current($arrData) );//判断是否一次插入多条数据
        if($true) {
            //构建插入多条数据的sql语句
            foreach($arrData as $arr) {
                $values .= $flag ? '(' : ',(';
                foreach($arr as $key => $value) {
                    if($flagV) {
                        if($flag) $name .= "$key";
                        $values .= "'$value'";
                        $flagV = 0;
                    } else {
                        if($flag) $name .= ",$key";
                        $values .= ",'$value'";
                    }
                }
                $values .= ') ';
                $flag = 0;
                $flagV = 1;
            }
        } else {
            //构建插入单条数据的sql语句
            foreach($arrData as $key => $value) {
                if($flagV) {
                    $name = "$key";
                    $values = "('$value'";
                    $flagV = 0;
                } else {
                    $name .= ",$key";
                    $values .= ",'$value'";
                }
            }
            $values .= ") ";
        }

        $strSql = "insert into $table ($name) values $values";
        if( ($pdo->exec($strSql) ) > 0 ) {
            return true;
        }
        return false;
    }


    $err_msg = array("201"=>"非法提交数据","202"=>"保存数据失败，请重试","200"=>"保存成功");
    if(!empty($_POST['_token']))
    {
        $return = [];

        if($_SESSION['csrftoken']==$_POST['_token'])
        {
            $return['code']=200;
        }else{
            $return['code']=201;
        }

        if(!empty($_POST['uid'])&&!empty($_POST['score']))
        {
            $data = array('uid'=>$_POST['uid'],'score'=>$_POST['score'],'ctime'=>time());
            if(insert('scorelist',$data)==true)
            {

            }else{
                $return['code']=202;
            }
        }else{
            $return['code']=202;
        }
        $_SESSION['csrftoken'] = null;
        $return['msg']=$err_msg[$return['code']];
        die(json_encode($return));
    }
    if(!empty($_GET['toplist'])=='true')
    {
        $return = [];
        $return['code']=200;

        $sql = 'select score.*,userlist.* from (SELECT * from scorelist ORDER BY score desc) score left JOIN userlist ON userlist.id=score.uid group by score.uid ORDER BY score.score desc LIMIT 10';
        $return['data']=$pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        die(json_encode($return));
    }


    $eid = $_GET['eid'];
    $sql = "select * from userlist where eid='$eid'";
    $res=$pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    if(!count($res))
    {
        $userinfo = json_decode(Post('http://oauth.wechat.vhdong.com/Api/getuserinfo?eid=',array('eid'=>$eid)),true);
        $userinfo['ctime'] = time();
        if(insert('userlist',$userinfo)==true)
        {
            $userinfo['id']=$pdo->lastInsertId();
        }
    }else{
        $userinfo = $res[0];
    }
//}

function Post($url,$post_data)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    // post数据
    curl_setopt($ch, CURLOPT_POST, 1);
    // post的变量
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
    $output = curl_exec($ch);
    curl_close($ch);
    return $output;
}

//创建不重复guid
function CreateGuid($namespace = '')
{
    static $guid = '';
    $uid = uniqid("", true);
    $data = $namespace;
    $data .= $_SERVER['REQUEST_TIME'];
    $data .= $_SERVER['HTTP_USER_AGENT'];
    $data .= $_SERVER['LOCAL_ADDR'];
    $data .= $_SERVER['LOCAL_PORT'];
    $data .= $_SERVER['REMOTE_ADDR'];
    $data .= $_SERVER['REMOTE_PORT'];
    $hash = strtoupper(hash('ripemd128', $uid . $guid . md5($data)));
    $guid = substr($hash,  0,  8) .
        substr($hash,  8,  4) .
        substr($hash, 12,  4) .
        substr($hash, 16,  4).
        substr($hash, 20, 12);
    return $guid;
}



$csrftoken =CreateGuid();
$_SESSION['csrftoken']=$csrftoken;
?>

<?php
require_once "jssdk.php";
$jssdk = new JSSDK("wx5cf9bb976599c71a", "edab39adc2a3f9973241711077f30f99");
$signPackage = $jssdk->GetSignPackage();
?>


<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="authoring-tool" content="Adobe_Animate_CC">
    <title>消灭飞沫</title>
    <meta name="format-detection" content="telephone=no">
    <meta name="csrf-token" content="<?php echo $csrftoken;?>"/>
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">
    <link href="style/animate.min.css" rel="stylesheet"/>
    <link href="style/global.css" rel="stylesheet"/>
    <script src="libs/createjs-2015.11.26.min.js"></script>
    <script src="libs/zepto/zepto.min.js"></script>
    <script src="libs/zepto/fx.js"></script>
    <script src="libs/zepto/touch.js"></script>
    <script src="script/component.js"></script>
    <script src="script/questiondb.js"></script>
    <script type="text/javascript">
        isAndroid = false;
       /* if(navigator.userAgent.indexOf("Android")>-1){
            var scaleNumber =0.5;// window.innerWidth/640;
            isAndroid = true;
            //document.write('<meta name="viewport" content="width=device-width, height=device-height, user-scalable=no, minimum-scale='+scaleNumber+', maximum-scale='+scaleNumber+', initial-scale='+scaleNumber+', target-densitydpi=device-dpi">');
            document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');
        }else{
            document.write('<meta name="viewport" content="width=640, user-scalable=no, target-densitydpi=device-dpi">');
        }*/

        document.addEventListener(touchstart, startMoveCanvas, false);
        document.addEventListener(touchend, startMoveCanvas, false);

        needScrollBar = false;
        function startMoveCanvas(e)
        {
            if(e.type==touchend)
            {
                needScrollBar = false;
            }
            console.log(e.target.className+"===="+e.currentTarget.className);
            document.addEventListener(touchmove, function (e) {
                if(!needScrollBar)e.preventDefault();
            }, false);
        }
        function is_weixn(){
            var ua = navigator.userAgent.toLowerCase();
            if(ua.match(/MicroMessenger/i)=="micromessenger") {
                return true;
            } else {
                return false;
            }
        }
        if(!is_weixn())
        {
            //document.location = "error.html";
        }
        var openid  = '<?php echo $_GET["eid"];?>';
    </script>
    <!-- write your code here -->
    <script src="game.min.js?r=20170301"></script>
    <script>
        var canvas, stage, exportRoot, anim_container, dom_overlay_container, fnStartAnimation;
        function init() {
            canvas = document.getElementById("canvas");
            anim_container = document.getElementById("animation_container");
            dom_overlay_container = document.getElementById("dom_overlay_container");
            images = images||{};
            ss = ss||{};
            var loader = new createjs.LoadQueue(false);
            loader.installPlugin(createjs.Sound);
            loader.addEventListener("fileload", handleFileLoad);
            loader.addEventListener("complete", handleComplete);
            loader.loadManifest(lib.properties.manifest);
        }
        function handleFileLoad(evt) {
            if (evt.item.type == "image") { images[evt.item.id] = evt.result; }
        }
        function handleComplete(evt) {

            $("#startView .nextbutton").addClass("active");



            //This function is always called, irrespective of the content. You can use the variable "stage" after it is created in token create_stage.
            var queue = evt.target;
            var ssMetadata = lib.ssMetadata;
            for(i=0; i<ssMetadata.length; i++) {
                ss[ssMetadata[i].name] = new createjs.SpriteSheet( {"images": [queue.getResult(ssMetadata[i].name)], "frames": ssMetadata[i].frames} )
            }
            exportRoot = new lib.game();
            if(isAndroid){
                //exportRoot.scaleX =  (window.innerWidth*0.5)/320;
                //exportRoot.scaleY =
            }
            stage = new createjs.Stage(canvas);
            if(StringUtils.getQueryString("restart")=="1")
            {
                addGame()
            }
            createjs.Touch.enable(stage);
            //Registers the "tick" event listener.
            fnStartAnimation = function() {
                createjs.Ticker.setFPS(lib.properties.fps);
                createjs.Ticker.addEventListener("tick", stage);
            }
            //Code to support hidpi screens and responsive scaling.
            function makeResponsive(isResp, respDim, isScale, scaleType) {
                var lastW, lastH, lastS=1;
                window.addEventListener('resize', resizeCanvas);
                resizeCanvas();
                function resizeCanvas() {
                    var iw = window.innerWidth, ih=window.innerHeight;
                    lib.properties.width=canvas.width = iw;
                    lib.properties.height=canvas.height = ih;
                    canvas.style.width = dom_overlay_container.style.width = anim_container.style.width =  iw+'px';
                    canvas.style.height = anim_container.style.height = dom_overlay_container.style.height = ih+'px';
                }
            }

            makeResponsive(false,'both',false,1);
            fnStartAnimation();
        }

        isSound = true;
        function playSound(id, loop) {
            return isSound?createjs.Sound.play(id, createjs.Sound.INTERRUPT_EARLY, 0, 0, loop):null;
        }
    </script>
    <!-- write your code here -->

    <style>
        body, html {
            background-color: #000;
            -webkit-text-size-adjust: none;
            overflow-y: hidden;
            overflow-x: hidden;
            -moz-user-select: none;
            -webkit-touch-callout: none; -webkit-text-size-adjust: none; -webkit-user-select: none; -webkit-highlight: none; -webkit-tap-highlight-color: rgba(0,0,0,0);
        }
        body, html,h2,li,p{
            margin: 0;
            padding: 0;
            list-style: none;
        }
        #animation_container{
            poasition:flex;
            width: 100%;
            height:100%;
        }
        #startView{
            position: absolute;
            top:0;
            left:0;
            width: 100%;
            height:100%;
            background: url("images/startback.jpg") no-repeat center;
            background-size: cover;
            display: none;
        }
        #startView .title{
            text-align: center;
            padding-top: 14px;
        }
        #startView .text{
            font-size: 28px;
            color:#fff;
            padding: 0 40px;
        }
        #startView .text p{
            padding-top: 30px;
            text-indent: 4rem;
            line-height: 3rem;
        }
        #startView .text img{
            width: 100%;
        }
        #startView .nextbutton{
            background: url("images/nextbtn.png") no-repeat center;
            background-size: contain;
            width: 269px;
            height:87px;
            position: absolute;
            left: 50%;
            margin-left: -134px;
            bottom: 80px;
            opacity: 0;
            -webkit-transition: opacity 0.5s ease;
            -moz-transition: opacity 0.5s ease;
            -o-transition: opacity 0.5s ease;
            transition: opacity 0.5s ease;
        }
        #startView .nextbutton{
            opacity: 1;
        }
        #startView .nextbutton:active{
            transform: scale(0.95,0.95);
        }

        #question{
            display: none;
        }
        #question .poppanel{
            background: url("images/qback.png") no-repeat left;
            width: 613px;
            height:612px;
            left:50%;
            top:50%;
            margin: -306px 0 0 -306px;
        }
        #question .poppanel.win{

            background: url("images/zque.png") no-repeat left;
            height:567px;
        }
        #question .poppanel .closebtn{
            width: 80px;
            height:80px;
            position: absolute;
            right: -10px;
            top:20px;
            background: url("images/closeback.png") no-repeat  center;
            display: none;
        }
        #question .poppanel .qsview{
            padding: 110px 30px 20px 30px;
            font-size: 1.5rem;
            color: #3a230a;
        }
        #question .poppanel .qsview .title{
            font-size: 1.8rem;
            padding-bottom: 16px;
        }
        #question .poppanel .qsview li div{
            background: url("images/kuang.png") no-repeat center;
            background-size: cover;
            width: 42px;
            height:43px;
            float: left;
            margin-right: 10px;
            margin-top: -5px;
        }
        #question .poppanel .qsview li{
            padding: 10px 0;
            min-height: 43px;
        }
        #question .poppanel .qsview li div img{
            display: none;
        }
        #question .poppanel .qsview li.active div img{
            display: block;
        }
        .enterbtn{
            position: absolute;
            background: url("images/enter.png") no-repeat;
            width: 210px;
            height: 69px;
            bottom: 36px;
            left: 50%;
            margin-left: -105px;
        }
        .poppanel.win .enterbtn{
            background: url("images/jixu.png") no-repeat;
            background-size: cover;
        }
        .poppanel .answer{
            display: none;
        }
        .answer .red{
            color: #a8150b;
            font-weight: bold;
            padding: 10px 0;
        }
        .answer .ref{
            font-size: 1.4rem;
        }
        #gameover{
            display: none;
        }
        #gameover .poppanel,#toplist .poppanel{
            width: 100%;
            width: 618px;
            top:50%;
            left:50%;
            margin: -410px 0 0 -309px;
        }
        #toplist .poppanel{
            height:823px;
        }
        #toplist{
            display: none;
        }

        #gameover .poppanel .over,#toplist .poppanel .over{
            position: relative;
            background: url("images/gameover.png") no-repeat center;
            background-size: contain;
            width: 100%;
            height:718px;
        }
        #toplist .poppanel .over{
            background: url("images/toplistback.png") no-repeat center;
            background-size: contain;
        }
        #gameover .restart,#toplist .closebtn{
            background: url("images/restart.png") no-repeat center;
            background-size: contain;
            padding-top: 20px;
            width: 262px;
            height:85px;
            margin: 0 auto;
        }
        #toplist .closebtn{
            background: url("images/closebtn.png") no-repeat center;
            background-size: contain;
            position: absolute;
            left: 50%;
            margin-left: -131px;
            bottom: 0;
        }
        #gameover .restart:active,#gameover .sharebtn:active,.toplistbtn:active,#toplist .closebtn:active{
            transform: scale(0.95,0.95);
        }
        #gameover .sharebtn{
            background: url("images/sharebtn.png") no-repeat center;
            background-size: contain;
            width: 450px;
            height:95px;
            position: absolute;
            bottom: 30px;
            left:50%;
            margin-left: -239px;
        }
        .toplistbtn{
            background: url("images/paihb.png") no-repeat center;
            background-size: contain;
            width: 69px;
            height:71px;
            position: absolute;
            right: 30px;
            bottom: -88px;
        }
        #toplist .poppanel .over .nativescrollbar{
            position: absolute;
            top:200px;
            left:68px;
            height: 480px;
            overflow-y:auto;
            -webkit-overflow-scrolling: touch;
        }
        #toplist ul li{
            background: url("images/itembak.png") no-repeat center;
            background-size: contain;
            width: 481px;
            height: 100px;
            color: #fff;
            margin-bottom: 8px;
        }
        #toplist ul li:last-child{
            margin: 0;
        }
        #toplist li span{
            width: 22%;
            text-align: center;
            float: left;
            height: 100px;
            line-height: 100px;
            display: block;
            font-size: 1.8rem;
        }
        #toplist li span:nth-child(1){
            background: url("images/quan.png") no-repeat center;
            width: 17%;
        }
        #toplist li span:nth-child(2){
            width: 23%;
        }
        #toplist li span:nth-child(3){
            width: 38%;
        }
        #toplist li span img{
            border: 3px solid #f9eecd;
            width: 70%;
            height:70%;
            margin: 8% auto 0;
            background-color: #fff;
            border-radius: 10%;
        }
        .over div.score{
            position: absolute;
            left: 50%;
            top: 196px;
            font-size: 3rem;
            text-align: center;
            width: 140px;
            margin-left: -40px;
            text-shadow: -3px 0 black, 0 3px black, 3px 0 black, 0 -3px black;
            color: white;
        }
        #toplist .over div.score{
            left: 50%;
            top: 117px;
            font-size: 2.1rem;
            text-align: center;
            width: 140px;
            margin-left: 20px;
            text-shadow: -3px 0 #4ba015, 0 3px #4ba015, 3px 0 #090, 0 -3px #090;
        }

        #startsmView .poppanel{
            background: url("images/shuom.png") no-repeat center;
            background-size: cover;
            width: 587px;
            height: 544px;
            left: 50%;
            top:50%;
            margin: -277px 0 0 -298px;
        }
        #startsmView{
            display: none;
        }
        #startsmView .poppanel .text{
            padding: 120px 40px 0 40px;
            font-size: 28px;
            color: #186718;
            line-height: 48px;
        }
        #startsmView .poppanel .text p{
            padding-top: 14px;
        }

        audio{
            display: none;
        }
    </style>
</head>
<body>
<div id="animation_container">
    <canvas id="canvas" width="640" height="1009"></canvas>
    <div id="dom_overlay_container" style="pointer-events:none; overflow:hidden; position: absolute; left: 0px; top: 0px; display: block;">
    </div>
</div>
<div id="startView" class="animated fa">
    <div class="title"><img src="images/zdm.png"></div>
    <div class="text animated fadeIn"><p>肺炎球菌可以在儿童鼻咽部携带，并通过呼吸道飞沫喷出来的细小的小沫进行传播。年龄越小，感染率越高。一般2岁以下的婴幼儿是肺炎球菌侵袭性疾病的高发年龄。</p>
        <p>6岁以下儿童鼻咽部肺炎球菌携带率为30-50%，而成人携带率为4-12%，青少年携带率为8.2%。</p>
        <img src="images/syt.png"></img>
    </div>
    <div class="nextbutton"></div>
</div>
<div id="startsmView" class="popview animated">
    <div class="popmask"></div>
    <div class="poppanel animated zoomIn">
        <div class="text">
            <p>沛宝超人保护地球不受外星物体撞击，左右移动沛宝宝，迎击外星障碍物吧！</p>
            <p>1、每撞一个加1分，错过或漏掉不加分</p>
            <p>2、撞击“闪光障碍物”获得加分问题：答对+5分，答错不加分</p>
            <p>游戏限时30秒，开始您的挑战之旅吧</p>
        </div>


        <div class="nextbutton"></div>
    </div>
</div>

<div id="question" class="popview animated">
    <div class="popmask"></div>
    <div class="poppanel qusit">
        <div class="closebtn"></div>

        <div class="qsview">
            <ul>
                <li class="title">范德萨范德萨分是</li>
                <li><div><img src="images/dui.png"/></div><p>范德萨范德萨分是范德萨范德萨分是范德萨范德萨分是范德萨范德萨分是</p></li>
                <li><div><img src="images/dui.png"/></div><p>范德萨范德萨分是范德萨范德萨分是范德萨范德萨分是范德萨范德萨分是</p></li>
            </ul>
            <div class="answer">
                <p class="red">很遗憾，答错了。正确答案：<span>D</span></p>
                <p class="ref"></p>
            </div>
        </div>

        <div class="enterbtn">

        </div>
    </div>
    <div class="poppanel win animated zoomIn">        <div class="enterbtn">
        </div>
    </div>
</div>
<div id="gameover" class="popview animated">
    <div class="popmask"></div>
    <div class="poppanel">
        <div class="over">
            <div class="score">10</div>
            <div class="sharebtn">
            </div>
            <div class="toplistbtn"></div>
        </div>
        <div class="restart"></div>
    </div>
</div>


<div id="toplist" class="popview animated">
    <div class="popmask"></div>
    <div class="poppanel animated zoomIn">
        <div class="over">
            <div class="score">10</div>
            <div class="nativescrollbar">
                <ul>

                </ul>

            </div>
        </div>
        <div class="closebtn"></div>
    </div>
</div>
<audio id="audiodom" loop></audio>
<script>

    if(window.innerWidth!=640)
    {
        window.location.href = document.location.origin+document.location.pathname+"?eid=<?php echo $_GET['eid'];?>&r="+Math.random();
    }


    var userinfo = null;
    <?php
        if(!empty($userinfo))
        {
           echo "var userinfojson = '".json_encode($userinfo)."'";
        }
    ?>

    if(window['userinfojson'])
    {
        userinfo = JSON.parse(userinfojson);
    }

    function playBackSound(value)
    {
        var sound = document.getElementById("audiodom");
        sound.src = value;
        sound.play();
    }
    function soundControl(value) {
        var sound = document.getElementById("audiodom");

        isSound = value;
        if(value)
        {
            sound.play();
        }else{
            sound.pause();
        }
    }

    function addGame() {
        stage.addChild(exportRoot);

        playBackSound("sounds/start.mp3");
    }
    if(StringUtils.getQueryString("restart")!="1")
    {
        document.getElementById("startView").style.display = "block";
    }
    $(function(){
        $("#startView .nextbutton").on(touchclick,function(){
            if(!$(this).hasClass("active"))return;

            $("#startView").addClass("fadeOut");
            setTimeout(function(){
                $("#startView").hide();
            },600);

            $("#startsmView").removeClass("fadeOut").show();
            addGame();
        });

        $("#startsmView").on(touchclick,function () {
            $(this).addClass("fadeOut");
            setTimeout(function(){
                $("#startsmView").hide();
            },600);
        })


        init();
    });


    var questionRond = [];
    function initQuestionConfig()
    {
        var il = questionArray.length;
        for(i=0;i<il;i++){
            questionRond.push(i);
        }
    }
    initQuestionConfig();

    function openQuestion() {
        $("#question").show().removeClass("fadeOut").addClass("fadeIn");


        $("#question .poppanel").hide();
        $("#question .poppanel.qusit").show();
        $("#question .poppanel .closebtn").hide();
        $(".poppanel .answer").hide();
        $("#question .poppanel.qusit .enterbtn").show();


        if(!questionRond.length)
        {
            initQuestionConfig();
        }
        var rid = randRange(1,questionRond.length);
        var qid = questionRond[rid-1];
        questionRond.splice(rid-1,1);
        questionData = questionArray[qid];

        console.log("答案："+questionData.answer);

        $("#question div.answer p span").html(String.fromCharCode(64 + parseInt(questionData.answer)+1));
        $("#question div.answer p.ref").html(questionData.ref);

        $("#question li").each(function (index,item) {
            if(!$(item).hasClass("title"))
            {
                $(item).remove();
            }
        })
        
        $("#question li.title").html(questionData.title);

        for(i=0;i<questionData.option.length;i++){
            $("#question ul").append('<li data-id="'+i+'"><div><img src="images/dui.png"/></div><p>'+questionData.option[i].label+'</p></li>');
        }

        $("#question li").on(touchclick,function (e) {
            if(!$(this).hasClass("title"))
            {
                $("#question li").removeClass("active");
                $(this).addClass("active");
            }
        })
    }
    function openQwin() {
        $("#question .poppanel").hide();
        $("#question .poppanel.win").show();
    }
    $("#question .poppanel.qusit .enterbtn").on(touchclick,function () {
        if($("#question li.active").length)
        {
            var answer = parseInt($("#question li.active").data("id"));
            if(answer==questionData.answer){
                openQwin();
                addScore(5);
            }
            else{
                $(this).hide();
                $(".poppanel .answer").show();
                $(".poppanel .closebtn").show();
            }
            $("#question li").unbind(touchclick);
        }else{
            new eDoctorUI.popToast("请选择答案");
        }
    })
    $("#question .poppanel.win .enterbtn , #question .closebtn").on(touchclick,function () {

        $("#question").addClass("fadeOut");
        setTimeout(function () {
            $("#question").hide();
            startGame();
        },600);
    });

    
    function  openOverGame(GameScore) {
        $("#gameover").show().removeClass("fadeOut").addClass("fadeIn");

        $('.over .score').html(GameScore);
        if(userinfo)
        {
            new ajaxLoading(document.location.origin+document.location.pathname,function (data) {
                if(data.code==200)
                {

                }else{
                   new eDoctorUI.popToast(data.msg);
                }
            },{score:GameScore,uid:userinfo.id},"POST");
        }
    }

    $("#toplist .closebtn").on(touchclick,function () {
        $("#toplist").hide();
        $("#gameover").show().removeClass("fadeOut").addClass("fadeIn");
    });

    $("#gameover .toplistbtn").on(touchclick,function () {
        $("#gameover").hide();
        $("#toplist").show();

        ///
        ajaxLoading(document.location.origin+document.location.pathname+"?toplist=true",function(data){
            console.log(data);
            if(data.code==200)
            {
                var il = data.data.length;
                $("#toplist ul").html('');
                for(i=0;i<il;i++)
                {
                    var item = '<li><span>'+(i+1)+'</span>  <span>              <img src="'+data.data[i]["headimgurl"]+'"/>                </span>';
                     item+='<span>'+data.data[i]["nickname"]+'</span>                <span>'+data.data[i]["score"]+'</span>                </li>';

                    $("#toplist ul").append(item);
                }
            }
        });
    });
    $("#gameover .restart").on(touchclick,function () {
        window.location.href = document.location.origin+document.location.pathname+"?eid=<?php echo $_GET['eid'];?>&restart=1&r="+Math.random();
    });


    $(".nativescrollbar").on(touchstart,function () {
        needScrollBar = true;
    })
    

    function randRange(min, max) {
        var randomNum = Math.floor(Math.random() * (max - min + 1)) + min;
        return randomNum;
    }

</script>
<script src="//res.wx.qq.com/open/js/jweixin-1.0.0.js"></script>
<script>
    wx.config({
        debug: false,
        appId: '<?php echo $signPackage["appId"];?>',
        timestamp: <?php echo $signPackage["timestamp"];?>,
        nonceStr: '<?php echo $signPackage["nonceStr"];?>',
        signature: '<?php echo $signPackage["signature"];?>',
        jsApiList: [
            'checkJsApi', 'onMenuShareTimeline', 'onMenuShareAppMessage', 'hideMenuItems', 'showMenuItems'
        ]
    });

    ShareTitle = '消灭飞沫，迎击外来入侵！';
    ShareDesc = "和沛宝超人一起保护地球宝宝，勇敢迎击外形障碍物！";
    ShareLink = "http://oauth.wechat.vhdong.com/mh/h5.dsn.ecloudmt.com/game/pe/";
    ShareimgUrl ='http://h5.dsn.ecloudmt.com/game/pe/shareicon.jpg';

</script>
<script src="script/wxjssdk.js" type="text/javascript" charset="utf-8"></script>
</body>
</html>