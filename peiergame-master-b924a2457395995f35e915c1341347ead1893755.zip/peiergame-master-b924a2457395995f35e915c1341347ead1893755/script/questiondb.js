/**
 * Created by rayle on 2017/02/28.
 */

var questionArray = [
    {
        title:"肺炎球菌传播的主要途径为?",
        option:[
            {
                label:"身体接触"
            },{
                label:"饮水"
            },{
                label:"呼吸道飞沫或定植菌自体感染"
            },{
                label:"食物"
            }
        ],
        answer:2,
        ref:"Ref：肺炎球菌性疾病相关疫苗应用技术指南 (2012版)"
    }
    ,
    {
        title:"下面哪一类人群是肺炎球菌的主要宿主?",
        option:[
            {
                label:"婴幼儿"
            },{
                label:"青少年"
            },{
                label:"成人"
            },{
                label:"老年人"
            }
        ],
        answer:0,
        ref:"Ref：肺炎球菌性疾病相关疫苗应用技术指南 (2012版)"
    }
    ,
    {
        title:"6岁以下儿童鼻咽部肺炎球菌的携带率为?",
        option:[
            {
                label:"4%~12%"
            },{
                label:"8.2%"
            },{
                label:"20%~30%"
            },{
                label:"30%~50%"
            }
        ],
        answer:3,
        ref:"Ref：Lynch JP 3rd,et al.Semin Respir Crit Care Med. 2009;30(2)189-209"
    }
    ,
    {
        title:"肺炎球菌感染常继发于___?",
        option:[
            {
                label:"流行性感冒"
            },{
                label:"哮喘"
            },{
                label:"腹泻"
            },{
                label:"牙周炎"
            }
        ],
        answer:0,
        ref:"Ref：姚开虎,等.中国实用儿科杂志.2009;24(12)964-967"
    }
    ,
    {
        title:"肺炎球菌感染的高发季节是?",
        option:[
            {
                label:"春季和夏季"
            },{
                label:"夏季和秋季"
            },{
                label:"秋季和冬季"
            },{
                label:"冬季和春季"
            }
        ],
        answer:3,
        ref:"Ref：赵国静,等.中国误诊学杂志.2011;11(36)8928-8929"
    }

    ,
    {
        title:"肺炎球菌性肺炎常见的症状不包括?",
        option:[
            {
                label:"畏寒"
            },{
                label:"发热、咳嗽"
            },{
                label:"呼吸增快甚至呼吸困难"
            },{
                label:"便秘"
            }
        ],
        answer:3,
        ref:"Ref：儿童社区获得性肺炎管理指南(2013修订)(上)"
    }


    ,
    {
        title:"肺炎球菌______已成为全球性、严峻而急剧发展的问题?",
        option:[
            {
                label:"发病率低"
            },{
                label:"无法预防"
            },{
                label:"抗生素耐药"
            },{
                label:"家长重视程度不够"
            }
        ],
        answer:2,
        ref:"Ref：肺炎球菌性疾病相关疫苗应用技术指南 (2012版)"
    }
    ,
    {
        title:"为什么6月龄~2岁是儿童肺炎球菌侵袭性疾病发病率最高的时期?",
        option:[
            {
                label:"母乳摄入减少"
            },{
                label:"宝宝发育加快"
            },{
                label:"未接种麻疹疫苗"
            },{
                label:"母传抗体逐渐消失"
            }
        ],
        answer:3,
        ref:"Ref：肺炎球菌性疾病相关疫苗应用技术指南 (2012版)"
    }



];