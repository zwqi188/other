﻿// JavaScript Document
eDoctorUI = window.eDoctorUI||{};
eDoctorUI.popList = function(_style) {
	var _self = this;
	this.style = _style;

	var layout = this.style&&this.style.layout?this.style.layout:"down";

	layout = "triangle-"+layout;

	//blurfilter
	this.html = '<div class="popview"><div class="popmask"></div><div class="poppanel">	<div class="content">    	    	 	          </div>    <div class="'+layout+'"></div></div></div>';

	_self.htmldom = $(_self.html);
	$(document.body).append(this.htmldom);
	///////////////////////////////////////////////////////////
	_self.panel = _self.htmldom.find(".poppanel");
	_self.closepanel = _self.htmldom.find(".popmask");
	_self.content = _self.htmldom.find(".content");

	if(this.style.close!=false)
	{
		_self.closepanel.on(touchclick,function(e) {
			remove();
		});
	}

	for(key in this.style)
	{
		_self.panel.css(key,_self.style[key]);
	}
	function loadpath(path) {

		if(StringUtils.isHttp(path))
		{
			_self.content.load(path);
		}else{
			_self.content.html(path);
		}
		//
	}
	function remove()
	{
		_self.htmldom.remove();
	}
	return { load: loadpath,close:remove,target:_self};
}

eDoctorUI.popLoading = function()
{
	var _self = this;
	_self.data = null;
	//blurfilter
	_self.html = '<div class="popview animation bounceIn"><div class="popmask hide"></div>   <div class="poploading"><img src="images/loading.gif"/> </div></div>';
	_self.htmldom = $(_self.html);

	_self.updateText = function(value)
	{
		if(!_self.labelview){
			_self.labelview = $("<p class='label'>"+value+"</p>");
			_self.htmldom.find(".poploading").addClass("label").append(_self.labelview);
		}
		_self.labelview.html(value);
	}

	$(document.body).append(_self.htmldom);
	return _self;
}

eDoctorUI.popToast = function(value,outtime)
{
	if(!outtime)outtime = 1000;

	var _self = this;
	_self.data = value;
	_self.html = '<div class="poptoast animation fadeIn">'+value+'</div>';
	_self.htmldom = $(_self.html);
	$(document.body).append(_self.htmldom);
	_self.htmldom.attr("style","margin-left:-"+(_self.htmldom.width()*0.5)+"px");
	setTimeout(function () {
		_self.htmldom.remove();
	},outtime);
	return _self;
}
///
eDoctorUI.popAlert = function(_content,_rightbtn,_leftbtn,_title) {
	var _self = this;
	_self.data = null;
	_self._content = _content;
	_self._title = _title || "提示";
	_self._rightbtn = _rightbtn || {label:"确定",callback:null};
	_self._leftbtn = _leftbtn || null;
	//blurfilter
	_self.html = '<div class="popview animation"><div class="popmask animation fadeIn"></div>  <div class="animation dialog-outer">    <h3 class="dialog-title border-bottom"></h3>    <div class="dialog-content tc"></div>    <div class="dialog-btn-group border-top clearfix">      </div>  </div></div>';

	_self.htmldom = $(_self.html);
	$(document.body).append(this.htmldom);
	///////////////////////////////////////////////////////////
	_self.title = _self.htmldom.find(".dialog-title");
	_self.title.html(_self._title);


	_self.content = _self.htmldom.find(".dialog-content");
	/*_self.closepanel.tap(function(e) {
	 _self.htmldom.remove();
	 });*/
	var extname = StringUtils.getExtName(_self._content);
	if(_self._content.substring(0,4)=="http" || extname==".html" || extname==".php" || extname==".aspx" || extname==".jsp")
	{
		try{_self.content.html("loading...");_self.content.load(_self._content,function(data){
			_self.resize();
		});_self.content.addClass("load");}catch(e){_self.content.html("load error:"+_self._content);}
	}else
	{
		_self.content.html(_self._content);
	}

	_self.btngroup = _self.htmldom.find(".dialog-btn-group");
	if(_self._leftbtn){
		_self.btngroup.append('<button class="dialog-cancel-btn">'+_self._leftbtn.label+'</button>');
		_self.htmldom.find(".dialog-cancel-btn").on(touchclick,function(e) {
			if(_self._leftbtn.callback)_self._leftbtn.callback(_self);

			_self.remove();
		});
	}else
	{
		_self.btngroup.addClass("single");
	}
	if(_self._rightbtn){
		_self.btngroup.append('<button class="dialog-confirm-btn">'+_self._rightbtn.label+'</button>');
		_self.htmldom.find(".dialog-confirm-btn").on(touchclick,function(e) {
			if(_self._rightbtn.callback)_self._rightbtn.callback(_self);
			_self.remove();
		});
	}
	_self.dialogpanel = _self.htmldom.find(".dialog-outer");
	_self.resize = function()
	{
		_self.dialogpanel.css("margin-top",-_self.dialogpanel.height()*0.5);
	}
	_self.resize();

	_self.remove = function()
	{
		_self.htmldom.addClass("fadeOut");
		setTimeout(function(){_self.htmldom.remove();},600);
	}
	return _self;
	//return { title: _self.title,content:_self._content,data:_self._data};
}




//导航菜单
eDoctorUI.tabListView = function(_menuid,_listid,_reflist,_index)
{
	if((typeof _menuid) != "string" || (typeof _listid)!="string")return;
	var _self = this;
	_self._refcallback = _reflist;
	var menuroot = $(_menuid);
	var listroot = $(_listid);

	_self.cacheScrollXY = false;

	this.bindevent = function()
	{
		$(menuroot).find(".tabmenu").unbind(touchclick).bind(touchclick,function(e){
			_self.show($(this).data("view"));
		});
	}
	_self.bindevent();

	var parentIndex = -1;
	var scrollbarObject = {};
	_self.show = function(value){
		if(parentIndex!=-1)
		{
			scrollbarObject[parentIndex] = {y:document.body.scrollTop,x:document.body.scrollLeft};
		}
		$(menuroot).find(".tabmenu").removeClass("active");
		$($(menuroot).find(".tabmenu")[value]).addClass("active");
		$(listroot).find(".tabitem").removeClass("active");
		$($(listroot).find(".tabitem")[value]).addClass("active");
		if(_self._refcallback)_self._refcallback(value,$($(listroot).find(".tabitem")[value]));

		parentIndex = value;
		if(_self.cacheScrollXY && scrollbarObject[value])
		{
			document.body.scrollTop = scrollbarObject[value]["y"];
		}
	}
	_self.show(_index!=undefined?_index:0);
	return _self;
}


///////////////

//取得一个数组中某个键值是 isvalue
getKeytoValue = function (arr,key,isvalue)
{
	var il = arr.length;
	while(--il>-1)
	{
		if(String(arr[il][key])==String(isvalue))return arr[il];
	}
	return null;
}

///插入一个对象到一个多维数组，使用key作为多维数组查找对象
//rootarr  参照的原始多维数�?
inEwtoDwArray = function(rootarr,arr,value,key)
{
	var il = arr.length;
	var copyobject = null;
	if(!il)
	{
		for(i=0;i<rootarr.length;i++)
		{

			if(rootarr[i][key]==value[key]){
				copyobject = {};

				for(k in rootarr[i])
				{
					copyobject[k] = rootarr[i][k];
				}
				copyobject["item"]= [];
				break;
			}
		}
		console.log("new:",copyobject);

	}else
	{
		for(i=0;i<il;i++)
		{
			if(arr[i][key]==value[key]){
				copyobject = arr[i];
				break;
			}
		}
	}
	if(copyobject)
	{
		copyobject["item"].push(value);
		if(!il)arr.push(copyobject);
	}
	console.log(arr);
	return arr;
}


//loading json
ajaxLoading = function(path,callback,data,type,isloading,callbcakerror) {
	var _csrf = $('meta[name="csrf-token"]').attr("content");
	if (_csrf && _csrf.length) {
		if (data == null)data = {};
		if ((typeof data) == "object") {
			data["_csrf"] = _csrf;
			data["_token"] = _csrf;
		}
	}

	if (isloading == undefined)isloading = true;

	if (isloading) {
		var loading = new eDoctorUI.popLoading();
	}

	if (type == undefined)type = "GET";


	if (window["ajaxLoadingParam"])
	{
		for(key in ajaxLoadingParam)
		{
			data[key] = ajaxLoadingParam[key];
		}
	}

	//  console.log(type);
	$.ajax({
		type: type,
		url: path,
		dataType: 'json',
		data:data,
		//timeout: 500,
		success: function(data){
			if(isloading){
				loading.htmldom.addClass("bounceOut");
				setTimeout(function(){loading.htmldom.remove();},600);
			}
			callback(data);
		},
		error: function(xhr, type){
			if(callbcakerror)callbcakerror(xhr);
			if(isloading){
				loading.htmldom.addClass("bounceOut");
				setTimeout(function(){loading.htmldom.remove();},600);
			}
		}

	})
}
createXmlHttpRequest = function (){
	if(window.ActiveXObject){
		return new ActiveXObject("Microsoft.XMLHTTP");
	}
	return new XMLHttpRequest();
}

//判断手机号码
StringUtils = window.StringUtils||{};
StringUtils.isMobile = function (value)
{
	var re = /^1\d{10}$/
	if (re.test(value)) {
		return true;
	}
	return false;
}
StringUtils.isNull = function(value)
{
	return !value || !String(value).length?false:true;
}

StringUtils.isEmail = function(str){
	var reg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
	return reg.test(str);
}

StringUtils.isHttp = function(str){
	return str.indexOf("http://")==0 | str.indexOf("https://")==0;
}

StringUtils.isURL = function(str)
{
	return!!str.match(/(((^https?:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)$/g);
}

StringUtils.getQueryString = function (name) {
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
	var r = window.location.search.substr(1).match(reg);
	if (r != null) return unescape(r[2]);
	return null;
}
StringUtils.getQueryHashString = function(name)
{
	var reg = new RegExp("(^|#)" + name + "=([^&]*)(&|$)", "i");
	var r = window.location.hash.match(reg);
	var string = window.location.hash;
	if (r != null) return unescape(r[2]);
	return null;
}

StringUtils.replaceParamValue = function(paramName,value,url,addend) {
	var oUrl = url==undefined?document.location.href.toString():url;
	var re=eval('/('+ paramName+'=)([^&]*)/gi');
	var nUrl = oUrl.replace(re,paramName+'='+value);
	if(!StringUtils.getQueryString("view")&&addend==undefined)
	{
		nUrl += "&"+paramName+'='+value;
	}
	return nUrl;
}

StringUtils.getExtName = function(file_name){
	var result =/\.[^\.]+/.exec(file_name);
	return result;
}

StringUtils.SplitString = function(value,sp)
{
	return value.split(sp);
}

StringUtils.urlProtocolString = function(value)
{
	//return value;
	if(value.indexOf("http:")!=-1)
	{
		value = value.substring(5,value.length);
	}else if(value.indexOf("https:")!=-1)
	{
		value = value.substring(6,value.length);
	}
	return value;
}

StringUtils.StringDate = function(vole)
{
	var arr1 = StringUtils.SplitString(vole, " ")[0];
	var arr2 = StringUtils.SplitString(vole, " ")[1];
	var yearmonthdate = StringUtils.SplitString(arr1, "-");
	var hourminutesecond = StringUtils.SplitString(arr2, ":");
	return new Date(yearmonthdate[0], yearmonthdate[1] - 1, yearmonthdate[2], hourminutesecond[0], hourminutesecond.length>=2?hourminutesecond[1]:null, hourminutesecond.length>=3?hourminutesecond[2]:null);
}

StringUtils.checkKeyWord = function (inputString, keyWord)
{
	var checker=new RegExp(keyWord);
	return checker.test(inputString);
}

StringUtils.secondsToTimeString = function(seconds)
{
	var isNegative = seconds < 0;
	if(isNegative)
	{
		seconds = -seconds;
	}
	var hours = Math.floor(seconds / 3600);
	seconds = Math.floor(seconds - (hours * 3600));
	var minutes = Math.floor(seconds / 60);
	seconds = Math.floor(seconds - (minutes * 60));
	var time = (minutes<10?"0"+minutes:minutes) + ":" + (seconds < 10 ? "0" : "") + seconds;
	if(hours > 0)
	{
		if(minutes < 10)
		{
			time = "0" + time;
		}
		time = hours + ":" + time;
	}
	if(isNegative)
	{
		time = "-" + time;
	}
	return time;
}

StringUtils.TimelineString = function (time)
{
	var result = "火星时间";
	var minute = 1000 * 60;
	var hour = minute * 60;
	var day = hour * 24;
	var month = day * 30;
	var year = month * 12;

	var diffValue = (new Date()).getTime() - StringUtils.StringDate(time).getTime();
	if (diffValue < 0)
	{
		return result;
	}
	var yearC = diffValue / year;
	var monthC =diffValue/month;
	var weekC =diffValue/(7*day);
	var dayC =diffValue/day;
	var hourC =diffValue/hour;
	var minC = diffValue / minute;

	if (yearC>=1)
	{
		result = parseInt(yearC) + "年前";
	}else if(monthC>=1){
		result=parseInt(monthC) + "月前";
	}
	else if(weekC>=1){
		result=parseInt(weekC) + "周前";
	}
	else if(dayC>=1){
		result=parseInt(dayC) +"天前";
	}
	else if(hourC>=1){
		result=parseInt(hourC) +"小时前";
	}
	else if(minC>=1){
		result=parseInt(minC) +"分钟前";
	}else{
		result="刚刚";
	}
	return result;
}



SystemUtils = window.SystemUtils||{};
SystemUtils.addCookie = function (name,value,expiresHours){
	var cookieString=name+"="+escape(value);
	//判断是否设置过期时间
	if(expiresHours>0){
		var date=new Date();
		date.setTime(date.getTime+expiresHours*3600*1000);
		cookieString=cookieString+"; expires="+date.toGMTString();
	}
	try{
		document.cookie=cookieString;
		return true;
	}catch(e){}
	return false;
}
SystemUtils.getCookie = function (name){
	try
	{
		var strCookie=document.cookie;
		var arrCookie=strCookie.split("; ");
		for(var i=0;i<arrCookie.length;i++)
		{
			var arr=arrCookie[i].split("=");
			if(arr[0]==name)return arr[1];
		}
	}catch(e){}
	return null;
}
SystemUtils.deleteCookie = function (name){
	var date=new Date();
	date.setTime(date.getTime()-10000);
	try
	{
		document.cookie=name+"=v; expires="+date.toGMTString();
		return true;
	}catch(e){}
	return false;
}

SystemUtils.isDesktop  = function()
{
	//平台、设备和操作系统
	var system ={
		win : false,
		mac : false,
		xll : false
	};
	//检测平台
	var p = navigator.platform;
	system.win = p.indexOf("Win") == 0;
	system.mac = p.indexOf("Mac") == 0;
	system.x11 = (p == "X11") || (p.indexOf("Linux") == 0);

	if(system.win||system.mac||system.xll){
		return true;
	}
	return false;
}
SystemUtils.isWeChat =  function () {
	if (navigator.userAgent.match(/MicroMessenger/))
	{
		return true;
	}
	return false;
}
SystemUtils.isAndroid = function()
{
	var p = navigator.userAgent;
	if(p.indexOf("Android") != -1){
		return true;
	}
	return false;
}
SystemUtils.isIOS = function()
{
	var p = navigator.userAgent;
	if(p.indexOf("iPad") != -1||p.indexOf("iPhone") != -1||p.indexOf("iPod") != -1){
		return true;
	}
	return false;
}

SystemUtils.loadJs = function (url, onLoadCB, onErrorCB) {
	var el = document.createElement("script");
	el.setAttribute("type", "text/javascript")
		el.setAttribute("src", url)
		el.setAttribute("async", !0)
	onLoadCB && (el.onload = onLoadCB)
	onErrorCB && (el.onerror = onErrorCB)
		document.getElementsByTagName("head")[0].appendChild(el)
}

SystemUtils.aspectRatio = function ()
{
    return window.orientation==180||window.orientation==0?"portrait":"landscape";
}


var istouch = "ontouchstart" in document && !SystemUtils.isDesktop() ? true : false;
var touchclick = istouch?"tap":"click";
var touchstart = istouch ? "touchstart" : "mousedown";
var touchmove = istouch ? "touchmove" : "mousemove";
var touchend = istouch ? "touchend" : "mouseup";


//console.log(StringUtils)
/////
/////



// Namespace UTF8
var UTF8 = (function() {
	return {
		// Encodes UCS2 into UTF8
		// Returns an array of numbers (bytes)
		encode : function(str) {
			var len = str.length;
			var result = [];
			var code;
			var i;
			for (i = 0; i < len; i++) {
				code = str.charCodeAt(i);
				if (code <= 0x7f) {
					result.push(code);
				} else if (code <= 0x7ff) {                         // 2 bytes
					result.push(0xc0 | (code >>> 6 & 0x1f),
						0x80 | (code & 0x3f));
				} else if (code <= 0xd700 || code >= 0xe000) {      // 3 bytes
					result.push(0xe0 | (code >>> 12 & 0x0f),
						0x80 | (code >>> 6 & 0x3f),
						0x80 | (code & 0x3f));
				} else {                                            // 4 bytes, surrogate pair
					code = (((code - 0xd800) << 10) | (str.charCodeAt(++i) - 0xdc00)) + 0x10000;
					result.push(0xf0 | (code >>> 18 & 0x07),
						0x80 | (code >>> 12 & 0x3f),
						0x80 | (code >>> 6 & 0x3f),
						0x80 | (code & 0x3f));
				}
			}
			return result;
		},

		// Decodes UTF8 into UCS2
		// Returns a string
		decode : function(bytes) {
			var len = bytes.length;
			var result = "";
			var code;
			var i;
			for (i = 0; i < len; i++) {
				if (bytes[i] <= 0x7f) {
					result += String.fromCharCode(bytes[i]);
				} else if (bytes[i] >= 0xc0) {                                   // Mutlibytes
					if (bytes[i] < 0xe0) {                                       // 2 bytes
						code = ((bytes[i++] & 0x1f) << 6) |
							(bytes[i] & 0x3f);
					} else if (bytes[i] < 0xf0) {                                // 3 bytes
						code = ((bytes[i++] & 0x0f) << 12) |
							((bytes[i++] & 0x3f) << 6)  |
							(bytes[i] & 0x3f);
					} else {                                                     // 4 bytes
						// turned into two characters in JS as surrogate pair
						code = (((bytes[i++] & 0x07) << 18) |
							((bytes[i++] & 0x3f) << 12) |
							((bytes[i++] & 0x3f) << 6) |
							(bytes[i] & 0x3f)) - 0x10000;
						// High surrogate
						result += String.fromCharCode(((code & 0xffc00) >>> 10) + 0xd800);
						// Low surrogate
						code = (code & 0x3ff) + 0xdc00;
					}
					result += String.fromCharCode(code);
				} // Otherwise it's an invalid UTF-8, skipped.
			}
			return result;
		}
	};
}());