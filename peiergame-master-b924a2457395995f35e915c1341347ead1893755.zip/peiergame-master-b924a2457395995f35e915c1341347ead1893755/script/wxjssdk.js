
wx.ready(function () {
  // 6 设备信息接口
  // 6.1 获取当前网络状态
  wx.getNetworkType({
      success: function (res) {
        if(res.networkType!="wifi")
        {
            //alert("由于游戏资源较多，建议您在wifi下进行浏览");
        }
      },
      fail: function (res) {
        //alert(JSON.stringify(res));
      }
    });

  // 8.5 隐藏所有非基本菜单项
  // wx.hideAllNonBaseMenuItem({    
  //     success: function () {
  //   //    alert('已隐藏所有非基本菜单项');
  //     }
  //   });
    

      
      if(window["hideShare"])
      {
          hideOptionMenu();
      }else{
          showShare();
      }

      refWechatShare();
});

function showShare()
{
    wx.showMenuItems({
        menuList: [
            'menuItem:share:appMessage',
            'menuItem:share:timeline'
        ] // 要显示的菜单项，所有menu项见附录3
    });
    // 8.3 批量隐藏菜单项
    wx.hideMenuItems({
        menuList: [
            'menuItem:readMode', // 阅读模式
            // 'menuItem:copyUrl', // 复制链接
            'menuItem:exposeArticle',
            'menuItem:setFont',
            'menuItem:share:qq',
            'menuItem:share:weiboApp',
            'menuItem:share:QZone',
            'menuItem:openWithQQBrowser',
            'menuItem:openWithSafari',
            'menuItem:share:email'
        ],
        success: function (res) {
            // alert('已隐藏“阅读模式””，“复制链接”等按钮');
        },
        fail: function (res) {
            //  alert(JSON.stringify(res));
        }
    });
}
function hideOptionMenu()
{
    wx.hideOptionMenu();
}

//扫描二维码
function showQRCode(callback)
{
    wx.scanQRCode({
        needResult: 1, // 默认为0，扫描结果由微信处理，1则直接返回扫描结果，
        scanType: ["qrCode"], // 可以指定扫二维码还是一维码，默认二者都有
        success: function (res) {
          callback(res);
        }
    });
}
function refWechatShare()
{
    if(!window['ShareTitle'])return;
    // 2. 分享接口
    // 2.1 监听“分享给朋友”，按钮点击、自定义分享内容及分享结果接口  
    wx.onMenuShareAppMessage({

        title: ShareTitle,
        link:ShareLink,
        imgUrl: ShareimgUrl,
        desc: ShareDesc,
      trigger: function (res) {
       // alert('用户点击发送给朋友');
      },
      success: function (res) {
      //  alert('已分享');
        addSharescore("friends");
      },
      cancel: function (res) {
      //  alert('已取消');
      },
      fail: function (res) {
       // alert(JSON.stringify(res));
      }
    });

  // 2.2 监听“分享到朋友圈”按钮点击、自定义分享内容及分享结果接口
   wx.onMenuShareTimeline({
      title: ShareTitle,
      link:ShareLink,
      imgUrl: ShareimgUrl,
      desc: ShareDesc,
      trigger: function (res) {
      //  alert('用户点击分享到朋友圈');
      },
      success: function (res) {
       
        addSharescore("timeline");
      },
      cancel: function (res) {
       // alert('已取消');
      // alert('cansole');
      },
      fail: function (res) {
       // alert(JSON.stringify(res));
      }
    });
}
wx.error(function (res) {
  //alert(res.errMsg);
});
