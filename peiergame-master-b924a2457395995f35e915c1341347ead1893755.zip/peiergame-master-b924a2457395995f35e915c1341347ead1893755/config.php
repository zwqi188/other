<?php
/**
 * Created by PhpStorm.
 * User: rayle
 * Date: 2017/02/27
 * Time: 19:25
 */

if(!defined("DB_DSN")) {
    define("DB_DSN", 'mysql:host=rds5od0g8l3j187l4474o.mysql.rds.aliyuncs.com;dbname=peiergamedb');
    define("DB_USER", 'peiergamedb');
    define("DB_PASS", 'Sh51699890peiergamedb');
}