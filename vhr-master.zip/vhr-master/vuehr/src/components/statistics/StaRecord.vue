<template>
  <div>
    <h1>
      人事记录统计
    </h1>
  </div>
</template>
