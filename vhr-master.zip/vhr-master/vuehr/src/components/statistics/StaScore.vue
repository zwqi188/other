<template>
  <div>
    <h1>
      员工积分统计
    </h1>
  </div>
</template>
