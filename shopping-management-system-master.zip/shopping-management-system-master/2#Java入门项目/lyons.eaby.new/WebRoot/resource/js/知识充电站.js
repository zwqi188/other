﻿/**
*1.变量为 "" null undefined 0(数字) 这四种情况时if(condition)为false。加上!代表true
*
*****
*2.       $.ajax({
	        dataType : "text",                                      //后台相应的数据类型
	        timeout : 10000,                                        //超时时间
	        data : {"content":content},                             //发送给的key-value
	        success : function (data) {                             //成功回调函数 data为参数
	            $("#content").val("");//清空key=content的内容信息
	            render();
	        }
	    });
*****
*3. $(function(){}  页面加载时就调用此函数
**
*
*/
 

function f()
{


}