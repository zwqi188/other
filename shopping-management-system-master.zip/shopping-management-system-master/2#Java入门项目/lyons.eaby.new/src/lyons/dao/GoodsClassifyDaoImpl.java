package lyons.dao;

public class GoodsClassifyDaoImpl
{
    
}
